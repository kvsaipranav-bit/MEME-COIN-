# 📡 API Documentation

## Overview

This document provides comprehensive documentation for the Team 11 SolMeme Factory Backend API.

**Base URL**: `http://localhost:3001/api` (development)  
**Authentication**: JWT Bearer Token

---

## 🔐 Authentication

### How it works

1. **Get Nonce**: Request a unique nonce for your wallet address
2. **Sign Message**: Sign the nonce message with your Phantom wallet
3. **Verify**: Submit the signature to receive a JWT token
4. **Use Token**: Include the JWT in the `Authorization` header for protected endpoints

### Headers for Protected Routes

```
Authorization: Bearer <your_jwt_token>
```

---

## 📚 Endpoints

### Health Check

#### `GET /health`

Check API and service health status.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2026-01-11T12:00:00Z",
  "services": {
    "database": "connected",
    "solana": "connected"
  }
}
```

---

### 🪙 Tokens

#### `GET /api/tokens`

Get all tokens with pagination.

**Query Parameters:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page | number | 1 | Page number |
| limit | number | 20 | Items per page |

**Response:**
```json
{
  "tokens": [
    {
      "id": "uuid",
      "mint_address": "9x4K...",
      "name": "Pepe Classic",
      "symbol": "PEPEC",
      "description": "Description here",
      "logo_url": "https://...",
      "initial_supply": "1000000000",
      "decimals": 9,
      "creator_wallet": "7xKX...",
      "creator_fee_bps": 100,
      "is_active": true,
      "created_at": "2026-01-11T12:00:00Z"
    }
  ],
  "total": 100
}
```

---

#### `GET /api/tokens/:address`

Get a specific token by mint address.

**Response:**
```json
{
  "id": "uuid",
  "mint_address": "9x4K...",
  "name": "Pepe Classic",
  "symbol": "PEPEC",
  "description": "Description here",
  "logo_url": "https://...",
  "initial_supply": "1000000000",
  "decimals": 9,
  "creator_wallet": "7xKX...",
  "creator_fee_bps": 100,
  "is_active": true,
  "created_at": "2026-01-11T12:00:00Z"
}
```

---

#### `GET /api/tokens/creator/:wallet`

Get all tokens created by a specific wallet.

**Response:**
```json
{
  "tokens": [...]
}
```

---

#### `POST /api/tokens` 🔒

Create a new token (requires authentication).

**Request Body:**
```json
{
  "name": "Pepe Classic",
  "symbol": "PEPEC",
  "description": "The best meme coin",
  "initial_supply": "1000000000",
  "decimals": 9,
  "creator_fee_bps": 100,
  "mint_address": "9x4K..."
}
```

**Response:**
```json
{
  "id": "uuid",
  "mint_address": "9x4K...",
  "name": "Pepe Classic",
  "...": "..."
}
```

---

#### `PUT /api/tokens/:address/fees` 🔒

Update creator fees for a token (creator only).

**Request Body:**
```json
{
  "creator_fee_bps": 200
}
```

---

### 🔐 Liquidity Locks

#### `GET /api/liquidity/all`

Get all liquidity locks.

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| status | string | Filter by status: locked, unlocked, claimed |

**Response:**
```json
{
  "locks": [
    {
      "id": "uuid",
      "token_id": "token_uuid",
      "owner_wallet": "7xKX...",
      "amount_sol": 10.5,
      "lock_date": "2026-01-11T12:00:00Z",
      "unlock_date": "2026-04-11T12:00:00Z",
      "status": "locked"
    }
  ]
}
```

---

#### `GET /api/liquidity/:tokenAddress`

Get liquidity lock for a specific token.

---

#### `POST /api/liquidity/lock` 🔒

Create a new liquidity lock.

**Request Body:**
```json
{
  "token_address": "9x4K...",
  "amount_sol": 10.5,
  "lock_duration_days": 90
}
```

---

#### `POST /api/liquidity/claim/:lockId` 🔒

Claim unlocked liquidity (owner only, after unlock date).

---

### 👤 Users

#### `POST /api/users/nonce`

Request a nonce for wallet authentication.

**Request Body:**
```json
{
  "wallet": "7xKX..."
}
```

**Response:**
```json
{
  "nonce": "abc123...",
  "message": "Sign this message to verify your wallet: abc123..."
}
```

---

#### `POST /api/users/verify`

Verify wallet signature and get JWT token.

**Request Body:**
```json
{
  "wallet": "7xKX...",
  "signature": "base64_signature..."
}
```

**Response:**
```json
{
  "token": "jwt_token...",
  "user": {
    "wallet_address": "7xKX...",
    "is_admin": false
  }
}
```

---

#### `GET /api/users/profile` 🔒

Get current user's profile.

---

### 🛡️ Admin

All admin endpoints require authentication + admin privileges.

#### `GET /api/admin/stats` 🔒👑

Get platform statistics.

**Response:**
```json
{
  "totalTokens": 142,
  "activeLocks": 89,
  "totalLockedSol": 1247.5,
  "totalUsers": 456,
  "recentTokens": 12,
  "timestamp": "2026-01-11T12:00:00Z"
}
```

---

#### `GET /api/admin/config` 🔒👑

Get platform configuration.

**Response:**
```json
{
  "platform_fee_percentage": 0.5,
  "min_lock_period_days": 90,
  "is_maintenance": false
}
```

---

#### `PUT /api/admin/config` 🔒👑

Update platform configuration.

**Request Body:**
```json
{
  "platform_fee_percentage": 0.5,
  "min_lock_period_days": 90,
  "is_maintenance": false
}
```

---

#### `GET /api/admin/tokens` 🔒👑

Get all tokens (including inactive).

---

#### `PUT /api/admin/tokens/:address/status` 🔒👑

Update token active status.

**Request Body:**
```json
{
  "is_active": false
}
```

---

#### `GET /api/admin/users` 🔒👑

Get all users.

---

#### `PUT /api/admin/users/:wallet/admin` 🔒👑

Set user admin status.

**Request Body:**
```json
{
  "is_admin": true
}
```

---

### 📤 Upload

#### `POST /api/upload/logo` 🔒

Upload a token logo.

**Content-Type**: `multipart/form-data`

**Form Data:**
| Field | Type | Description |
|-------|------|-------------|
| logo | File | Image file (PNG, JPG, max 5MB) |

**Response:**
```json
{
  "success": true,
  "data": {
    "url": "https://supabase.../logo.png",
    "path": "logos/filename.png"
  }
}
```

---

## ❌ Error Responses

All errors follow this format:

```json
{
  "success": false,
  "message": "Error description",
  "error": "ERROR_CODE"
}
```

### HTTP Status Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 429 | Rate Limited |
| 500 | Server Error |

---

## 🔄 Rate Limiting

- **General endpoints**: 100 requests per 15 minutes
- **Auth endpoints**: 10 requests per 15 minutes

Rate limit headers are included in responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1641900000
```

---

## 📝 Examples

### Create Token Flow

```javascript
// 1. Authenticate
const nonce = await fetch('/api/users/nonce', {
  method: 'POST',
  body: JSON.stringify({ wallet: publicKey })
});

const signature = await wallet.signMessage(nonce.message);

const auth = await fetch('/api/users/verify', {
  method: 'POST',
  body: JSON.stringify({ wallet: publicKey, signature })
});

const token = auth.token;

// 2. Upload logo
const formData = new FormData();
formData.append('logo', logoFile);

const upload = await fetch('/api/upload/logo', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}` },
  body: formData
});

// 3. Create token
const newToken = await fetch('/api/tokens', {
  method: 'POST',
  headers: { 
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: 'Pepe Classic',
    symbol: 'PEPEC',
    initial_supply: '1000000000',
    decimals: 9,
    creator_fee_bps: 100,
    mint_address: mintAddress,
    logo_url: upload.data.url
  })
});
```

---

## 🔗 Related Documentation

- [Phase 2: Backend Development](./phases/phase-2-backend.md)
- [Phase 4: Integration](./phases/phase-4-integration.md)
- [README](../README.md)
