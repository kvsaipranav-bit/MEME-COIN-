# 🚀 Deployment Guide

This guide details the exact steps to deploy the Team 11 platform to a live environment (Devnet).

---

## 📋 Prerequisites

Ensure you have the following installed:
- [Solana CLI](https://docs.solana.com/cli/install-solana-cli-tools)
- [Anchor](https://www.anchor-lang.com/docs/installation)
- [Node.js](https://nodejs.org/) (v18+)
- [Supabase Account](https://supabase.com/)

---

## 1️⃣ Smart Contract Deployment

This is the most critical step. You must generate a unique Program ID.

### 1. Build & Generate Keypair
```bash
cd programs
anchor build
```
*This command creates `target/deploy/team_11-keypair.json`.*

### 2. Get Your Program ID
Run this command to see your new Program ID:
```bash
solana address -k target/deploy/team_11-keypair.json
```
**Copy this address.** You will need it in multiple places.

### 3. Update Source Code
Update the Program ID in these 3 files:

1. **`programs/Anchor.toml`**:
   ```toml
   [programs.devnet]
   team_11 = "PASTE_YOUR_ID_HERE"
   ```

2. **`programs/team-11/src/lib.rs`**:
   ```rust
   declare_id!("PASTE_YOUR_ID_HERE");
   ```

3. **`frontend/.env.local`**:
   ```env
   NEXT_PUBLIC_PROGRAM_ID=PASTE_YOUR_ID_HERE
   ```

### 4. Final Build & Deploy
Now that IDs match, build again and deploy:
```bash
anchor build
anchor deploy --provider.cluster devnet
```

### 5. Initialize Program
After deployment, you must initialize the program with your platform parameters:
```bash
# You can use a script or the Anchor tests to run the initialize instruction
# Example using tests:
anchor test --skip-local-validator --skip-deploy --provider.cluster devnet
```

---

## 2️⃣ Database Setup

### 1. Create Supabase Project
1. Log in to [Supabase](https://supabase.com/).
2. Create a new project.

### 2. Run Database Schema
1. Go to the **SQL Editor** in your Supabase dashboard.
2. Open `scripts/setup-database.sql` from this repository.
3. **IMPORTANT**: Find line 168 and replace `'YOUR_PLATFORM_WALLET_ADDRESS_HERE'` with your actual Solana wallet address.
4. Paste the content into the SQL Editor and click **Run**.

### 3. Configure Storage
1. Go to **Storage**.
2. Create a new bucket named `token-logos`.
3. Set the bucket to **Public**.

---

## 3️⃣ Backend Setup

### 1. Configure Environment
Create a `.env` file in the `backend` directory based on `.env.example`:

```env
PORT=3001
SUPABASE_URL=your_supabase_project_url
SUPABASE_ANON_KEY=your_supabase_anon_key
SOLANA_RPC_URL=https://api.devnet.solana.com
PROGRAM_ID=PASTE_YOUR_ID_HERE
PLATFORM_WALLET=your_wallet_address
JWT_SECRET=generate_a_secure_random_string
```

### 2. Start Backend
```bash
cd backend
npm install
npm start
```

---

## 4️⃣ Frontend Setup

### 1. Configure Environment
Create a `.env.local` file in the `frontend` directory based on `.env.local.example`:

```env
NEXT_PUBLIC_API_URL=http://localhost:3001/api
NEXT_PUBLIC_SOLANA_RPC_URL=https://api.devnet.solana.com
NEXT_PUBLIC_PROGRAM_ID=PASTE_YOUR_ID_HERE
```

### 2. Start Frontend
```bash
cd frontend
npm install
npm run dev
```

---

## ✅ Verification Checklist

- [ ] **Program ID** matches in `Anchor.toml`, `lib.rs`, and Frontend `.env`.
- [ ] **Database** has tables `users`, `tokens`, `liquidity_locks`.
- [ ] **Storage** bucket `token-logos` exists and is public.
- [ ] **Backend** is running without errors.
- [ ] **Frontend** loads and connects to your Phantom wallet.

🚀 **You are ready to launch!**
