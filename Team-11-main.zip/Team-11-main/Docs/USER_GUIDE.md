# 📖 User Guide

## Welcome to Team 11 - SolMeme Factory

This guide will walk you through using the Team 11 platform to create and manage meme coins on Solana.

---

## 🔗 Getting Started

### 1. Connect Your Wallet

To use the platform, you need a Phantom wallet:

1. **Install Phantom**: Visit [phantom.app](https://phantom.app/) and install the browser extension
2. **Create Wallet**: Follow the setup process to create a new wallet or import an existing one
3. **Fund Your Wallet**: Ensure you have some SOL for transaction fees (0.1 SOL minimum recommended)
4. **Connect**: Click "Connect Wallet" on the Team 11 homepage

---

## 🪙 Creating a Token

### Step 1: Access Token Creation

1. Navigate to the **Create** page from the navigation menu
2. Ensure your wallet is connected

### Step 2: Token Details

Fill in your token information:

| Field | Description | Example |
|-------|-------------|---------|
| **Token Name** | Full name of your token (max 50 chars) | "Pepe Classic" |
| **Symbol** | Ticker symbol (max 10 chars, all caps) | "PEPEC" |
| **Description** | Brief description of your token | "The ultimate meme coin" |
| **Initial Supply** | Total token supply | 1,000,000,000 |
| **Decimals** | Token precision (usually 9) | 9 |
| **Logo** | Upload an image (PNG/JPG, max 5MB) | (optional) |

### Step 3: Liquidity Lock Settings

Configure your liquidity lock:

| Field | Description | Requirement |
|-------|-------------|-------------|
| **Lock Duration** | How long liquidity is locked | Minimum 90 days |
| **Lock Amount** | Amount of SOL to lock | Your choice |
| **Creator Fee** | Fee you receive on trades | 0-10% |

### Step 4: Review & Confirm

1. Review all details carefully
2. Confirm the transaction in your Phantom wallet
3. Wait for blockchain confirmation

### Step 5: Success!

Once confirmed, your token is:
- ✅ Created on Solana blockchain
- ✅ Listed on the dashboard
- ✅ Liquidity locked for the specified period

---

## 📊 Dashboard

### Viewing All Tokens

The dashboard shows all tokens created on the platform:

- **Search**: Find tokens by name or symbol
- **Sort**: Order by newest, name, or other criteria
- **Filter**: View locked/unlocked tokens

### Token Cards Display:

Each token card shows:
- 🏷️ Token name and symbol
- 💰 Initial supply
- 👤 Creator address
- 🔒 Lock status and countdown
- 📅 Creation date

---

## 📄 Token Details Page

Click any token to view full details:

### Token Information
- Full token details
- Contract address (click to copy)
- Links to Solscan explorer
- Trade on Raydium button

### Liquidity Lock Status
- Amount of SOL locked
- Lock/Unlock dates
- Live countdown timer
- Claim button (when unlocked)

---

## 💼 My Tokens

### Managing Your Tokens

The "My Tokens" page shows all tokens you've created:

1. **View Your Tokens**: See all tokens created by your wallet
2. **Manage Fees**: Update creator fees (if applicable)
3. **Claim Liquidity**: Claim unlocked liquidity when the lock period expires

### Claiming Liquidity

When your lock period expires:

1. Navigate to your token on "My Tokens"
2. Click "Claim Liquidity"
3. Confirm the transaction in Phantom
4. Receive your locked SOL back

---

## 🛡️ Admin Panel

*Access for platform administrators only*

### Statistics
- Total tokens created
- Active liquidity locks
- Total SOL locked
- User count

### Configuration
- Platform fee settings
- Minimum lock period
- Maintenance mode toggle

### Token Management
- View all tokens
- Enable/disable tokens
- Monitor platform activity

---

## ⚡ Tips for Success

### Before Creating a Token:

1. **Plan Your Token**: Have a clear concept and community strategy
2. **Prepare Marketing**: Logo, website, social media
3. **Set Fair Fees**: Keep creator fees reasonable (0-2%)
4. **Lock Long-Term**: Longer locks build more trust

### After Launching:

1. **Share on Social Media**: Announce your token launch
2. **Build Community**: Engage with your token holders
3. **Provide Updates**: Keep your community informed
4. **Be Transparent**: The locked liquidity proves your commitment

---

## ❓ FAQ

### What is liquidity locking?
Liquidity locking means the initial trading liquidity cannot be removed for a set period. This protects buyers from "rug pulls" where creators drain liquidity.

### What's the minimum lock period?
The platform requires a minimum of **90 days** liquidity lock.

### What is the platform fee?
The platform charges **0.5%** on liquidity locks. This fee supports platform maintenance and development.

### Can I update my token after creation?
You can update the **creator fee** percentage, but not other token details. Token details are permanent on the blockchain.

### How do I trade my token?
After creation, your token is tradeable on **Raydium DEX**. Click "Trade on Raydium" on your token page.

### What wallet is supported?
Currently, we support **Phantom Wallet** only. More wallet support coming soon.

---

## 🆘 Support

### Having Issues?

1. **Check Network**: Ensure you're on Solana Devnet
2. **Refresh**: Try refreshing the page
3. **Reconnect Wallet**: Disconnect and reconnect Phantom
4. **Clear Cache**: Clear your browser cache

### Contact

For support, please open an issue on our GitHub repository.

---

## 🔗 Quick Links

- [Dashboard](/dashboard) - View all tokens
- [Create Token](/create) - Launch your meme coin
- [My Tokens](/my-tokens) - Manage your tokens
- [API Documentation](./API.md) - Developer API docs

---

*Last updated: January 2026*
