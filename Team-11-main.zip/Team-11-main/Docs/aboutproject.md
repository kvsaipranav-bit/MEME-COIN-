# 🚀 Team 11 - Meme Coin Creation Platform

## Project Overview

**Team 11** is a comprehensive meme coin creation platform built on the **Solana blockchain**. The platform enables users to create, deploy, and manage SPL tokens with built-in liquidity lock mechanisms, ensuring transparency and trust in the meme coin ecosystem.

---

## 🎯 Project Purpose

This mini project serves as a complete meme coin creation platform where users can:

1. **Create custom SPL tokens** on Solana with personalized parameters
2. **Lock initial liquidity** for a specified period (minimum 3 months)
3. **Trade tokens** on Raydium DEX
4. **View all platform tokens** with detailed liquidity lock information
5. **Manage their created tokens** through a comprehensive dashboard

---

## 🔑 Key Features

### 1. Token Creation
- Create SPL tokens with custom name, symbol, description, and logo
- Set initial supply and decimals
- Fixed maximum supply (no minting after creation)
- Non-burnable tokens
- Transaction fee configuration by creator

### 2. Liquidity Lock System (Core Feature)
- **Lock initial SOL liquidity** for a time period
- **Minimum lock period**: 3 months
- **Manual claim**: Creator decides when to withdraw after lock expires
- **Transparency**: All lock details publicly visible on dashboard
- **Display information**:
  - Lock amount (SOL)
  - Lock date
  - Unlock date
  - Remaining time countdown
  - Creator wallet address
  - Lock status (Locked/Unlocked/Claimed)

### 3. Trading & Transactions
- Buy/Sell tokens on Raydium DEX
- Transfer tokens between wallets
- **Platform fee**: 0.5% on all buy/sell transactions
- **Creator fee**: Configurable additional fee by token creator

### 4. Dashboard Features
- View all coins created on the platform
- Detailed token information and statistics
- Liquidity lock status and countdown timers
- Trading history and volume
- Creator verification status

---

## 👥 User Roles

### Regular User
- Connect wallet via Phantom
- View all platform tokens
- View token details and liquidity lock info
- Buy/Sell tokens on Raydium

### Token Creator
- All regular user permissions
- Create new tokens with custom parameters
- Configure transaction fees
- Add liquidity to Raydium
- Lock initial SOL liquidity
- View their created tokens
- Claim unlocked liquidity (manual)

### Platform Admin
- Platform fee configuration
- View platform analytics
- Manage suspicious tokens (delist if needed)
- View all platform statistics
- Emergency controls

---

## 💰 Transaction Fee Structure

| Fee Type | Percentage | Recipient |
|----------|-----------|-----------|
| Platform Fee | 0.5% | Platform Wallet |
| Creator Fee | Configurable | Token Creator |

---

## 🔗 Integrations

| Service | Purpose |
|---------|---------|
| **Solana Blockchain** | Token deployment & transactions |
| **SPL Token Program** | Token standard |
| **Phantom Wallet** | User authentication & transactions |
| **Raydium DEX** | Token trading & liquidity pools |
| **Supabase** | Backend database & storage |

---

## 🎨 Design System

The platform uses the **Koyeb Design System** featuring:

- **Color Palette**:
  - Primary Background: `#000000` (Pure Black) / `#181618` (Dark Charcoal)
  - Secondary Background: `#E6E5DE` (Off-White)
  - Accent Color: `#2EFF9B` (Neon Mint Green)
  - Text Primary: `#E6E5DE` (Off-White)
  - Text Secondary: `#A0A0A0` (Muted Gray)

- **Typography**:
  - Primary: JetBrains Mono (Monospace)
  - Secondary: Inter (Sans-serif)

- **UI Elements**:
  - 3D-style buttons with solid bottom shadows
  - Noise/grain texture overlay on backgrounds
  - Subtle grid patterns in hero sections
  - Green glow effects and accents
  - Smooth hover transitions and animations
  - Dark-themed cards with subtle borders

---

## 🌐 Network

- **Development & Testing**: Solana Devnet
- **Production**: Solana Mainnet (future)

---

## ⚙️ Tech Stack

| Layer | Technology |
|-------|------------|
| **Blockchain** | Solana |
| **Token Standard** | SPL (Solana Program Library) |
| **Smart Contracts** | Rust (Anchor Framework) |
| **Frontend** | TypeScript, React, Next.js |
| **Backend** | JavaScript, Node.js, Express |
| **Database** | Supabase (PostgreSQL) |
| **Wallet** | Phantom |
| **DEX** | Raydium |
| **Styling** | CSS with Koyeb Design System |

---

## 📊 Success Metrics

1. Token creation success rate
2. Liquidity lock transparency
3. Trading volume
4. User engagement
5. Platform stability

---

## 🔒 Security Considerations

1. Smart contract auditing
2. Wallet signature verification
3. Rate limiting on API endpoints
4. Input validation and sanitization
5. Secure storage of sensitive data
6. Admin access controls

---

## 📅 Project Timeline

Estimated development time: **8-10 weeks** across 5 phases

- Phase 0: Project Setup & Design System
- Phase 1: Solana Smart Contracts
- Phase 2: Backend API Development
- Phase 3: Frontend Development
- Phase 4: Integration, Testing & Deployment
