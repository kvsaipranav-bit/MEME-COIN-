# 🏗️ Team 11 - System Architecture

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              USER LAYER                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐  │
│   │   Browser   │    │   Phantom   │    │   Raydium   │    │   Mobile    │  │
│   │   (Next.js) │    │   Wallet    │    │     DEX     │    │   (Future)  │  │
│   └──────┬──────┘    └──────┬──────┘    └──────┬──────┘    └──────┬──────┘  │
└──────────┼──────────────────┼──────────────────┼──────────────────┼─────────┘
           │                  │                  │                  │
           ▼                  ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FRONTEND LAYER                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                    Next.js Application (TypeScript)                   │   │
│   ├─────────────────────────────────────────────────────────────────────┤   │
│   │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────┐ │   │
│   │  │   Home   │  │  Create  │  │Dashboard │  │  Token   │  │ Admin  │ │   │
│   │  │   Page   │  │   Token  │  │   Page   │  │  Details │  │ Panel  │ │   │
│   │  └──────────┘  └──────────┘  └──────────┘  └──────────┘  └────────┘ │   │
│   ├─────────────────────────────────────────────────────────────────────┤   │
│   │  ┌────────────────┐  ┌────────────────┐  ┌────────────────────────┐ │   │
│   │  │ Wallet Adapter │  │  Solana Web3   │  │    React Components    │ │   │
│   │  │   (Phantom)    │  │     SDK        │  │    (Koyeb Design)      │ │   │
│   │  └────────────────┘  └────────────────┘  └────────────────────────┘ │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
└──────────────────────────────────┬──────────────────────────────────────────┘
                                   │
                                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            BACKEND LAYER                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                  Node.js/Express API Server (JavaScript)             │   │
│   ├─────────────────────────────────────────────────────────────────────┤   │
│   │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┬───────────┐   │   │
│   │  │   Token API  │  │ Liquidity    │  │   User API   │ Admin API │   │   │
│   │  │   Endpoints  │  │ Lock API     │  │   Endpoints  │ Endpoints │   │   │
│   │  └──────────────┘  └──────────────┘  └──────────────┴───────────┘   │   │
│   ├─────────────────────────────────────────────────────────────────────┤   │
│   │  ┌────────────────┐  ┌────────────────┐  ┌────────────────────────┐ │   │
│   │  │  Supabase      │  │  Solana RPC    │  │   File Upload         │ │   │
│   │  │  Client        │  │  Connection    │  │   (Logo Storage)      │ │   │
│   │  └────────────────┘  └────────────────┘  └────────────────────────┘ │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
└──────────────────────────────────┬──────────────────────────────────────────┘
                                   │
           ┌───────────────────────┼───────────────────────┐
           ▼                       ▼                       ▼
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────────────┐
│   SUPABASE       │    │  SOLANA          │    │    EXTERNAL SERVICES     │
│   DATABASE       │    │  BLOCKCHAIN      │    │                          │
├──────────────────┤    ├──────────────────┤    ├──────────────────────────┤
│ ┌──────────────┐ │    │ ┌──────────────┐ │    │ ┌──────────────────────┐ │
│ │   tokens     │ │    │ │ SPL Token    │ │    │ │   Raydium SDK        │ │
│ │   table      │ │    │ │ Program      │ │    │ │   (DEX Integration)  │ │
│ └──────────────┘ │    │ └──────────────┘ │    │ └──────────────────────┘ │
│ ┌──────────────┐ │    │ ┌──────────────┐ │    │ ┌──────────────────────┐ │
│ │  liquidity   │ │    │ │ Liquidity    │ │    │ │   Phantom Wallet     │ │
│ │  _locks      │ │    │ │ Lock Program │ │    │ │   Adapter            │ │
│ └──────────────┘ │    │ └──────────────┘ │    │ └──────────────────────┘ │
│ ┌──────────────┐ │    │ ┌──────────────┐ │    │ ┌──────────────────────┐ │
│ │   users      │ │    │ │ Fee Config   │ │    │ │   Supabase Storage   │ │
│ │   table      │ │    │ │ Program      │ │    │ │   (Logo Images)      │ │
│ └──────────────┘ │    │ └──────────────┘ │    │ └──────────────────────┘ │
│ ┌──────────────┐ │    └──────────────────┘    └──────────────────────────┘
│ │  platform    │ │
│ │  _config     │ │
│ └──────────────┘ │
└──────────────────┘
```

---

## Component Architecture

### 1. Frontend Architecture (Next.js + TypeScript)

```
frontend/
├── app/                          # Next.js App Router
│   ├── layout.tsx                # Root layout with providers
│   ├── page.tsx                  # Home/Landing page
│   ├── create/
│   │   └── page.tsx              # Token creation page
│   ├── dashboard/
│   │   └── page.tsx              # Coins dashboard
│   ├── token/
│   │   └── [address]/
│   │       └── page.tsx          # Token details page
│   ├── my-tokens/
│   │   └── page.tsx              # Creator's tokens page
│   └── admin/
│       └── page.tsx              # Admin panel
│
├── components/
│   ├── ui/                       # Koyeb-styled UI components
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Input.tsx
│   │   ├── Modal.tsx
│   │   ├── Loading.tsx
│   │   └── ...
│   ├── layout/
│   │   ├── Header.tsx
│   │   ├── Footer.tsx
│   │   └── Sidebar.tsx
│   ├── token/
│   │   ├── TokenCard.tsx
│   │   ├── TokenCreationForm.tsx
│   │   ├── TokenDetails.tsx
│   │   └── LiquidityLockInfo.tsx
│   └── wallet/
│       └── WalletButton.tsx
│
├── hooks/
│   ├── useWallet.ts
│   ├── useToken.ts
│   ├── useLiquidityLock.ts
│   └── useApi.ts
│
├── lib/
│   ├── solana.ts                 # Solana connection utilities
│   ├── api.ts                    # API client
│   └── utils.ts
│
├── providers/
│   ├── WalletProvider.tsx
│   └── ThemeProvider.tsx
│
└── styles/
    ├── globals.css               # Koyeb design system
    └── components.css
```

### 2. Backend Architecture (Node.js + Express)

```
backend/
├── src/
│   ├── index.js                  # Entry point
│   ├── app.js                    # Express app setup
│   │
│   ├── config/
│   │   ├── database.js           # Supabase config
│   │   ├── solana.js             # Solana RPC config
│   │   └── constants.js          # App constants
│   │
│   ├── routes/
│   │   ├── index.js
│   │   ├── tokens.js             # Token CRUD endpoints
│   │   ├── liquidity.js          # Liquidity lock endpoints
│   │   ├── users.js              # User endpoints
│   │   └── admin.js              # Admin endpoints
│   │
│   ├── controllers/
│   │   ├── tokenController.js
│   │   ├── liquidityController.js
│   │   ├── userController.js
│   │   └── adminController.js
│   │
│   ├── services/
│   │   ├── tokenService.js
│   │   ├── liquidityService.js
│   │   ├── solanaService.js
│   │   └── storageService.js
│   │
│   ├── middleware/
│   │   ├── auth.js               # Wallet signature verification
│   │   ├── admin.js              # Admin role check
│   │   ├── rateLimit.js
│   │   └── validation.js
│   │
│   ├── models/
│   │   ├── Token.js
│   │   ├── LiquidityLock.js
│   │   ├── User.js
│   │   └── PlatformConfig.js
│   │
│   └── utils/
│       ├── logger.js
│       ├── errors.js
│       └── helpers.js
│
└── tests/
    ├── unit/
    ├── integration/
    └── fixtures/
```

### 3. Solana Programs Architecture (Rust + Anchor)

```
programs/
└── 📂 team-11/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs                # Main program entry
│       ├── instructions/
│       │   ├── mod.rs
│       │   ├── create_token.rs   # Token creation instruction
│       │   ├── lock_liquidity.rs # Liquidity lock instruction
│       │   ├── unlock_liquidity.rs
│       │   ├── claim_liquidity.rs
│       │   └── update_fees.rs
│       ├── state/
│       │   ├── mod.rs
│       │   ├── token_config.rs   # Token configuration account
│       │   ├── liquidity_lock.rs # Liquidity lock account
│       │   └── platform_config.rs
│       └── errors.rs             # Custom error codes
│
└── tests/
    └── team-11.ts        # Anchor tests
```

---

## Database Schema (Supabase/PostgreSQL)

### Tables

```sql
-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    wallet_address VARCHAR(44) UNIQUE NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Tokens table
CREATE TABLE tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mint_address VARCHAR(44) UNIQUE NOT NULL,
    name VARCHAR(50) NOT NULL,
    symbol VARCHAR(10) NOT NULL,
    description TEXT,
    logo_url TEXT,
    decimals INTEGER DEFAULT 9,
    initial_supply BIGINT NOT NULL,
    creator_wallet VARCHAR(44) NOT NULL,
    creator_fee_percentage DECIMAL(5,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    FOREIGN KEY (creator_wallet) REFERENCES users(wallet_address)
);

-- Liquidity locks table
CREATE TABLE liquidity_locks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_id UUID NOT NULL,
    lock_address VARCHAR(44) UNIQUE NOT NULL,
    amount_sol DECIMAL(20,9) NOT NULL,
    creator_wallet VARCHAR(44) NOT NULL,
    lock_date TIMESTAMP NOT NULL,
    unlock_date TIMESTAMP NOT NULL,
    status VARCHAR(20) DEFAULT 'locked', -- locked, unlocked, claimed
    claimed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    FOREIGN KEY (token_id) REFERENCES tokens(id),
    FOREIGN KEY (creator_wallet) REFERENCES users(wallet_address)
);

-- Platform configuration table
CREATE TABLE platform_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_fee_percentage DECIMAL(5,2) DEFAULT 0.5,
    platform_wallet VARCHAR(44) NOT NULL,
    min_lock_period_days INTEGER DEFAULT 90,
    is_maintenance BOOLEAN DEFAULT FALSE,
    updated_by VARCHAR(44),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Transaction history (optional for analytics)
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_id UUID NOT NULL,
    transaction_type VARCHAR(20) NOT NULL, -- buy, sell, transfer
    from_wallet VARCHAR(44),
    to_wallet VARCHAR(44),
    amount DECIMAL(30,9) NOT NULL,
    signature VARCHAR(88) NOT NULL,
    platform_fee_collected DECIMAL(20,9),
    creator_fee_collected DECIMAL(20,9),
    created_at TIMESTAMP DEFAULT NOW(),
    
    FOREIGN KEY (token_id) REFERENCES tokens(id)
);
```

---

## API Endpoints

### Token Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/tokens` | Create new token (with metadata) |
| GET | `/api/tokens` | List all tokens |
| GET | `/api/tokens/:address` | Get token details |
| GET | `/api/tokens/creator/:wallet` | Get tokens by creator |
| PUT | `/api/tokens/:address/fees` | Update creator fees |

### Liquidity Lock Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/liquidity/lock` | Create liquidity lock |
| GET | `/api/liquidity/:tokenAddress` | Get lock info for token |
| GET | `/api/liquidity/all` | List all active locks |
| POST | `/api/liquidity/claim/:lockId` | Claim unlocked liquidity |

### User Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/users/connect` | Register/Connect wallet |
| GET | `/api/users/:wallet` | Get user profile |
| GET | `/api/users/:wallet/tokens` | Get user's tokens |

### Admin Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/stats` | Platform statistics |
| PUT | `/api/admin/config` | Update platform config |
| PUT | `/api/admin/tokens/:address/status` | Update token status |

---

## Data Flow Diagrams

### Token Creation Flow

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  User    │    │ Frontend │    │ Backend  │    │ Solana   │    │ Supabase │
│ (Wallet) │    │ (Next.js)│    │ (Express)│    │ Blockchain│   │ Database │
└────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘
     │               │               │               │               │
     │ 1. Fill Form  │               │               │               │
     │──────────────>│               │               │               │
     │               │               │               │               │
     │               │ 2. Upload Logo│               │               │
     │               │──────────────>│               │               │
     │               │               │──────────────────────────────>│
     │               │               │               │    3. Store   │
     │               │               │<──────────────────────────────│
     │               │               │    Logo URL   │               │
     │               │               │               │               │
     │               │ 4. Create Token TX            │               │
     │               │──────────────>│               │               │
     │               │               │ 5. Build TX   │               │
     │               │<──────────────│               │               │
     │               │               │               │               │
     │ 6. Sign TX    │               │               │               │
     │<──────────────│               │               │               │
     │ (Phantom)     │               │               │               │
     │──────────────>│               │               │               │
     │               │               │               │               │
     │               │ 7. Submit Signed TX           │               │
     │               │──────────────>│               │               │
     │               │               │──────────────>│               │
     │               │               │ 8. Deploy Token               │
     │               │               │<──────────────│               │
     │               │               │   Mint Address│               │
     │               │               │               │               │
     │               │               │ 9. Store Token Metadata       │
     │               │               │──────────────────────────────>│
     │               │               │<──────────────────────────────│
     │               │               │               │               │
     │               │<──────────────│               │               │
     │               │  10. Success  │               │               │
     │<──────────────│               │               │               │
     │    Token Created!             │               │               │
```

### Liquidity Lock Flow

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ Creator  │    │ Frontend │    │ Backend  │    │ Solana   │    │ Supabase │
│ (Wallet) │    │ (Next.js)│    │ (Express)│    │ Blockchain│   │ Database │
└────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘
     │               │               │               │               │
     │ 1. Set Lock   │               │               │               │
     │    Amount &   │               │               │               │
     │    Duration   │               │               │               │
     │──────────────>│               │               │               │
     │               │               │               │               │
     │               │ 2. Create Lock TX             │               │
     │               │──────────────>│               │               │
     │               │               │ 3. Build TX   │               │
     │               │<──────────────│               │               │
     │               │               │               │               │
     │ 4. Sign TX    │               │               │               │
     │<──────────────│               │               │               │
     │──────────────>│               │               │               │
     │               │               │               │               │
     │               │ 5. Submit Lock TX             │               │
     │               │──────────────>│               │               │
     │               │               │──────────────>│               │
     │               │               │ 6. Transfer SOL to Lock PDA   │
     │               │               │<──────────────│               │
     │               │               │   Lock Account│               │
     │               │               │               │               │
     │               │               │ 7. Store Lock Details         │
     │               │               │──────────────────────────────>│
     │               │               │<──────────────────────────────│
     │               │               │               │               │
     │               │<──────────────│               │               │
     │<──────────────│ 8. Liquidity Locked!          │               │
```

### Liquidity Claim Flow (After Lock Expires)

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ Creator  │    │ Frontend │    │ Backend  │    │ Solana   │    │ Supabase │
└────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘    └────┬─────┘
     │               │               │               │               │
     │ 1. Click Claim│               │               │               │
     │──────────────>│               │               │               │
     │               │               │               │               │
     │               │ 2. Verify Lock Expired         │               │
     │               │──────────────>│               │               │
     │               │               │──────────────────────────────>│
     │               │               │<──────────────────────────────│
     │               │               │  3. Check Status              │
     │               │               │               │               │
     │               │ 4. Build Claim TX             │               │
     │               │<──────────────│               │               │
     │               │               │               │               │
     │ 5. Sign TX    │               │               │               │
     │<──────────────│               │               │               │
     │──────────────>│               │               │               │
     │               │               │               │               │
     │               │ 6. Submit Claim TX            │               │
     │               │──────────────>│               │               │
     │               │               │──────────────>│               │
     │               │               │ 7. Transfer SOL from Lock PDA │
     │               │               │<──────────────│               │
     │               │               │               │               │
     │               │               │ 8. Update Lock Status         │
     │               │               │──────────────────────────────>│
     │               │               │<──────────────────────────────│
     │               │               │               │               │
     │<──────────────│ 9. SOL Claimed!               │               │
```

---

## Security Architecture

### Authentication Flow (Phantom Wallet)

```
┌──────────┐    ┌──────────┐    ┌──────────┐
│  User    │    │ Frontend │    │ Backend  │
└────┬─────┘    └────┬─────┘    └────┬─────┘
     │               │               │
     │ 1. Connect    │               │
     │──────────────>│               │
     │               │               │
     │ 2. Phantom    │               │
     │    Popup      │               │
     │<──────────────│               │
     │               │               │
     │ 3. Approve    │               │
     │──────────────>│               │
     │               │               │
     │               │ 4. Get Nonce  │
     │               │──────────────>│
     │               │<──────────────│
     │               │               │
     │ 5. Sign Nonce │               │
     │<──────────────│               │
     │──────────────>│               │
     │               │               │
     │               │ 6. Verify     │
     │               │   Signature   │
     │               │──────────────>│
     │               │<──────────────│
     │               │   JWT Token   │
     │<──────────────│               │
     │   Authenticated!              │
```

### Security Layers

1. **Wallet Authentication**: Signature-based authentication using Phantom
2. **API Security**: JWT tokens for session management
3. **Rate Limiting**: Prevent abuse on all endpoints
4. **Input Validation**: Sanitize all user inputs
5. **Smart Contract Security**: Anchor framework safety checks
6. **Admin Access**: Role-based access control

---

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        PRODUCTION                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────────┐         ┌─────────────────┐               │
│   │    Vercel       │         │   Railway/      │               │
│   │   (Frontend)    │◄───────►│   Render        │               │
│   │   Next.js       │   API   │   (Backend)     │               │
│   └────────┬────────┘         └────────┬────────┘               │
│            │                           │                         │
│            │                           │                         │
│            ▼                           ▼                         │
│   ┌─────────────────┐         ┌─────────────────┐               │
│   │    Solana       │         │    Supabase     │               │
│   │    Devnet/      │         │    (Database    │               │
│   │    Mainnet      │         │     & Storage)  │               │
│   └─────────────────┘         └─────────────────┘               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```
