# 🚀 Phase 0: Project Setup & Design System

## Overview

**Duration**: 3-4 days  
**Goal**: Set up the complete project infrastructure, development environment, and implement the Koyeb design system.

---

## 📋 Tasks Checklist

### 0.1 Project Initialization
- [ ] Create root project structure
- [ ] Initialize Git repository
- [ ] Create `.gitignore` file
- [ ] Set up monorepo with npm workspaces
- [ ] Create README.md

### 0.2 Solana Program Setup
- [ ] Install Anchor Framework
- [ ] Initialize Anchor project
- [ ] Configure for Devnet
- [ ] Generate program keypair
- [ ] Set up program structure

### 0.3 Backend Setup
- [ ] Initialize Node.js project
- [ ] Install dependencies (Express, Supabase, etc.)
- [ ] Set up project structure
- [ ] Configure ESLint & Prettier
- [ ] Create environment files

### 0.4 Frontend Setup
- [ ] Create Next.js project with TypeScript
- [ ] Install Solana wallet adapter
- [ ] Set up project structure
- [ ] Configure TypeScript
- [ ] Create environment files

### 0.5 Database Setup
- [ ] Create Supabase project
- [ ] Run database migrations
- [ ] Set up storage bucket for logos
- [ ] Configure Row Level Security (RLS)
- [ ] Test database connection

### 0.6 Koyeb Design System Implementation
- [ ] Create color palette CSS variables
- [ ] Implement typography system
- [ ] Create Button component (3D style)
- [ ] Create Card component
- [ ] Create Input component
- [ ] Create Modal component
- [ ] Create Loading component
- [ ] Implement noise/grain texture overlay
- [ ] Create Header component
- [ ] Create Footer component
- [ ] Implement smooth animations

---

## 🛠️ Detailed Implementation

### 0.1 Project Initialization

```bash
# Create project root
mkdir coin_creation
cd coin_creation

# Initialize npm workspace
npm init -y

# Create root package.json for workspaces
```

**package.json (root)**:
```json
{
  "name": "team-11",
  "version": "1.0.0",
  "private": true,
  "workspaces": [
    "frontend",
    "backend"
  ],
  "scripts": {
    "dev:frontend": "npm run dev --workspace=frontend",
    "dev:backend": "npm run dev --workspace=backend",
    "test": "npm run test --workspaces",
    "build": "npm run build --workspaces"
  }
}
```

### 0.2 Solana Program Setup

```bash
# Install Anchor (if not installed)
cargo install --git https://github.com/coral-xyz/anchor anchor-cli

# Initialize Anchor workspace
anchor init programs

# Navigate to programs
cd programs

# Configure Anchor.toml for devnet
```

**Anchor.toml**:
```toml
[features]
seeds = false
skip-lint = false

[programs.devnet]
team_11 = "YourProgramIdHere"

[registry]
url = "https://api.apr.dev"

[provider]
cluster = "Devnet"
wallet = "~/.config/solana/id.json"

[scripts]
test = "yarn run ts-mocha -p ./tsconfig.json -t 1000000 tests/**/*.ts"
```

### 0.3 Backend Setup

```bash
cd backend
npm init -y

# Install dependencies
npm install express cors helmet morgan dotenv
npm install @supabase/supabase-js @solana/web3.js
npm install jsonwebtoken uuid multer

# Dev dependencies
npm install -D nodemon eslint prettier
```

### 0.4 Frontend Setup

```bash
# Create Next.js app
npx create-next-app@latest frontend --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"

cd frontend

# Install Solana dependencies
npm install @solana/web3.js @solana/wallet-adapter-react @solana/wallet-adapter-react-ui @solana/wallet-adapter-wallets @solana/wallet-adapter-base

# Install UI dependencies
npm install lucide-react clsx
```

### 0.5 Database Schema

```sql
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    wallet_address VARCHAR(44) UNIQUE NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tokens table
CREATE TABLE tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mint_address VARCHAR(44) UNIQUE NOT NULL,
    name VARCHAR(50) NOT NULL,
    symbol VARCHAR(10) NOT NULL,
    description TEXT,
    logo_url TEXT,
    decimals INTEGER DEFAULT 9,
    initial_supply BIGINT NOT NULL,
    creator_wallet VARCHAR(44) NOT NULL,
    creator_fee_percentage DECIMAL(5,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Liquidity locks table
CREATE TABLE liquidity_locks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_id UUID NOT NULL REFERENCES tokens(id),
    lock_address VARCHAR(44) UNIQUE NOT NULL,
    amount_sol DECIMAL(20,9) NOT NULL,
    creator_wallet VARCHAR(44) NOT NULL,
    lock_date TIMESTAMP WITH TIME ZONE NOT NULL,
    unlock_date TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(20) DEFAULT 'locked',
    claimed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Platform configuration
CREATE TABLE platform_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_fee_percentage DECIMAL(5,2) DEFAULT 0.5,
    platform_wallet VARCHAR(44) NOT NULL,
    min_lock_period_days INTEGER DEFAULT 90,
    is_maintenance BOOLEAN DEFAULT FALSE,
    updated_by VARCHAR(44),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_tokens_creator ON tokens(creator_wallet);
CREATE INDEX idx_tokens_active ON tokens(is_active);
CREATE INDEX idx_locks_token ON liquidity_locks(token_id);
CREATE INDEX idx_locks_status ON liquidity_locks(status);
CREATE INDEX idx_locks_unlock ON liquidity_locks(unlock_date);
```

### 0.6 Koyeb Design System CSS

```css
/* globals.css - Koyeb Design System */

:root {
  /* Colors */
  --color-bg-primary: #000000;
  --color-bg-secondary: #181618;
  --color-bg-tertiary: #1a1a1a;
  --color-bg-light: #E6E5DE;
  
  --color-accent: #2EFF9B;
  --color-accent-hover: #25cc7c;
  --color-accent-glow: rgba(46, 255, 155, 0.3);
  
  --color-text-primary: #E6E5DE;
  --color-text-secondary: #A0A0A0;
  --color-text-muted: #666666;
  
  --color-border: #333333;
  --color-border-light: #444444;
  
  --color-error: #ff4444;
  --color-warning: #ffaa00;
  --color-success: #2EFF9B;
  
  /* Typography */
  --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
  --font-sans: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  
  /* Spacing */
  --spacing-xs: 0.25rem;
  --spacing-sm: 0.5rem;
  --spacing-md: 1rem;
  --spacing-lg: 1.5rem;
  --spacing-xl: 2rem;
  --spacing-2xl: 3rem;
  
  /* Border Radius */
  --radius-sm: 2px;
  --radius-md: 4px;
  --radius-lg: 8px;
  
  /* Shadows */
  --shadow-3d: 0 4px 0 0 var(--color-border);
  --shadow-3d-hover: 0 2px 0 0 var(--color-border);
  --shadow-glow: 0 0 20px var(--color-accent-glow);
  
  /* Transitions */
  --transition-fast: 150ms ease;
  --transition-normal: 250ms ease;
  --transition-slow: 400ms ease;
}

/* Base Styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  font-size: 16px;
  scroll-behavior: smooth;
}

body {
  font-family: var(--font-sans);
  background-color: var(--color-bg-primary);
  color: var(--color-text-primary);
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* Noise Texture Overlay */
.noise-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 9999;
  opacity: 0.03;
  background-image: url('/images/noise.png');
  background-repeat: repeat;
}

/* Typography */
h1, h2, h3, h4, h5, h6 {
  font-family: var(--font-mono);
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

h1 { font-size: 3rem; }
h2 { font-size: 2.25rem; }
h3 { font-size: 1.5rem; }
h4 { font-size: 1.25rem; }

/* Code/Mono Text */
.mono {
  font-family: var(--font-mono);
}

/* Buttons */
.btn {
  font-family: var(--font-mono);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 0.75rem 1.5rem;
  border: 1px solid var(--color-accent);
  border-radius: var(--radius-sm);
  background: transparent;
  color: var(--color-accent);
  cursor: pointer;
  transition: all var(--transition-fast);
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
}

.btn:hover {
  color: var(--color-text-primary);
  border-color: var(--color-text-primary);
}

.btn-primary {
  background: var(--color-bg-secondary);
  color: var(--color-text-primary);
  border: none;
  box-shadow: var(--shadow-3d);
}

.btn-primary:hover {
  transform: translateY(2px);
  box-shadow: var(--shadow-3d-hover);
}

.btn-primary:active {
  transform: translateY(4px);
  box-shadow: none;
}

.btn-accent {
  background: var(--color-accent);
  color: var(--color-bg-primary);
  border: none;
  box-shadow: 0 4px 0 0 var(--color-accent-hover);
}

.btn-accent:hover {
  transform: translateY(2px);
  box-shadow: 0 2px 0 0 var(--color-accent-hover);
}

/* Cards */
.card {
  background: var(--color-bg-secondary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  padding: var(--spacing-lg);
  transition: all var(--transition-normal);
}

.card:hover {
  border-color: var(--color-accent);
  box-shadow: var(--shadow-glow);
}

/* Inputs */
.input {
  font-family: var(--font-mono);
  font-size: 0.875rem;
  padding: 0.75rem 1rem;
  background: var(--color-bg-tertiary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  color: var(--color-text-primary);
  width: 100%;
  transition: all var(--transition-fast);
}

.input:focus {
  outline: none;
  border-color: var(--color-accent);
  box-shadow: 0 0 0 2px var(--color-accent-glow);
}

.input::placeholder {
  color: var(--color-text-muted);
}

/* Animations */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes slideUp {
  from { 
    opacity: 0;
    transform: translateY(20px);
  }
  to { 
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes glow {
  0%, 100% { box-shadow: 0 0 5px var(--color-accent-glow); }
  50% { box-shadow: 0 0 20px var(--color-accent-glow); }
}

.animate-fade-in {
  animation: fadeIn var(--transition-normal) ease-out;
}

.animate-slide-up {
  animation: slideUp var(--transition-slow) ease-out;
}

.animate-pulse {
  animation: pulse 2s ease-in-out infinite;
}

.animate-glow {
  animation: glow 2s ease-in-out infinite;
}

/* Grid Background */
.grid-bg {
  background-image: 
    linear-gradient(rgba(46, 255, 155, 0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(46, 255, 155, 0.03) 1px, transparent 1px);
  background-size: 50px 50px;
}

/* Scrollbar */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: var(--color-bg-secondary);
}

::-webkit-scrollbar-thumb {
  background: var(--color-border);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: var(--color-accent);
}
```

---

## ✅ Testing Strategy

### Unit Tests
- Component rendering tests
- CSS class application tests
- Animation trigger tests

### Visual Tests
- Screenshot comparison for design consistency
- Responsive design tests
- Dark theme verification

### Accessibility Tests
- Color contrast validation
- Focus states
- Screen reader compatibility

---

## 📊 Acceptance Criteria

1. ✅ All projects (frontend, backend, programs) initialize without errors
2. ✅ Supabase database connected and tables created
3. ✅ Design system matches Koyeb aesthetics
4. ✅ All base UI components created and styled
5. ✅ Development servers run successfully
6. ✅ Git repository initialized with proper .gitignore

---

## 🎯 Deliverables

| Deliverable | Status |
|-------------|--------|
| Project structure created | ⬜ |
| Anchor program initialized | ⬜ |
| Backend server running | ⬜ |
| Frontend server running | ⬜ |
| Database schema deployed | ⬜ |
| Koyeb design system CSS | ⬜ |
| Base UI components | ⬜ |
| Header & Footer components | ⬜ |
| Noise texture overlay | ⬜ |
| Documentation updated | ⬜ |

---

## 📅 Estimated Timeline

| Task | Duration |
|------|----------|
| Project initialization | 2 hours |
| Solana program setup | 2 hours |
| Backend setup | 3 hours |
| Frontend setup | 2 hours |
| Database setup | 2 hours |
| Design system CSS | 4 hours |
| UI components | 8 hours |
| Testing & polish | 4 hours |
| **Total** | **~3-4 days** |
