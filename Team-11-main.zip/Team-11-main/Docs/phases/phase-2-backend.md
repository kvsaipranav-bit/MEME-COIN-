# 🖥️ Phase 2: Backend API Development

## Overview

**Duration**: 4-5 days  
**Goal**: Build Node.js/Express backend with Supabase integration for token metadata, liquidity tracking, and user management.

---

## 📋 Tasks Checklist

### 2.1 Project Setup
- [x] Initialize Express.js project
- [x] Configure Supabase client
- [x] Set up middleware (CORS, helmet, morgan)
- [x] Create project structure
- [x] Enhanced health check with service status

### 2.2 Authentication
- [x] Wallet signature verification (nacl + bs58)
- [x] JWT token generation
- [x] Auth middleware
- [x] Admin role middleware
- [x] Rate limiting

### 2.3 Token API
- [x] POST `/api/tokens` - Create token metadata
- [x] GET `/api/tokens` - List all tokens (with pagination)
- [x] GET `/api/tokens/:address` - Get token details
- [x] GET `/api/tokens/creator/:wallet` - Creator's tokens
- [x] PUT `/api/tokens/:address/fees` - Update fees
- [x] PUT `/api/tokens/:address/status` - Update status

### 2.4 Liquidity Lock API
- [x] POST `/api/liquidity/lock` - Record lock (with validation)
- [x] GET `/api/liquidity/:tokenAddress` - Get lock info
- [x] GET `/api/liquidity/all` - All active locks
- [x] POST `/api/liquidity/claim/:lockId` - Record claim

### 2.5 User & Admin API
- [x] POST `/api/users/connect` - Register wallet
- [x] POST `/api/users/nonce` - Get authentication nonce
- [x] POST `/api/users/verify` - Verify signature & login
- [x] GET `/api/users/:wallet` - Get profile
- [x] GET `/api/admin/stats` - Platform stats (enhanced)
- [x] GET `/api/admin/config` - Get config
- [x] PUT `/api/admin/config` - Update config
- [x] GET `/api/admin/users` - List all users (NEW)
- [x] PUT `/api/admin/users/:wallet/admin` - Set user admin (NEW)

### 2.6 File Upload
- [x] Logo upload to Supabase Storage
- [x] Image validation
- [x] POST `/api/upload/logo` - Upload logo
- [x] DELETE `/api/upload/logo` - Delete logo

### 2.7 Blockchain Services (NEW)
- [x] Transaction verification
- [x] Token mint verification
- [x] Account balance queries
- [x] Network status monitoring

---

## 🏗️ Project Structure

```
backend/src/
├── index.js              # Entry point
├── app.js                # Express setup with middleware
├── config/
│   ├── database.js       # Supabase config
│   ├── solana.js         # Solana RPC config
│   └── constants.js      # Platform constants
├── routes/
│   ├── index.js          # Route aggregator
│   ├── tokens.js         # 6 endpoints
│   ├── liquidity.js      # 4 endpoints
│   ├── users.js          # 6 endpoints
│   ├── admin.js          # 7 endpoints
│   └── upload.js         # 2 endpoints
├── controllers/
│   ├── tokenController.js
│   ├── liquidityController.js
│   ├── userController.js
│   ├── adminController.js
│   └── uploadController.js
├── services/
│   ├── tokenService.js
│   ├── liquidityService.js
│   ├── userService.js
│   ├── adminService.js     # NEW
│   ├── uploadService.js
│   └── solanaService.js    # NEW
├── middleware/
│   ├── auth.js           # JWT verification
│   ├── admin.js          # Admin role check
│   └── validation.js     # Request validation
└── utils/
    ├── logger.js         # Colored logger
    ├── errors.js         # Error handling
    └── helpers.js        # Utility functions
```

---

## 🔌 API Endpoints Summary (25 total)

### Tokens (6 endpoints)
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/tokens` | ✅ | Create token metadata |
| GET | `/api/tokens` | ❌ | List all tokens |
| GET | `/api/tokens/:address` | ❌ | Token details |
| GET | `/api/tokens/creator/:wallet` | ❌ | Creator's tokens |
| PUT | `/api/tokens/:address/fees` | ✅ | Update fees |
| PUT | `/api/tokens/:address/status` | ✅ | Update status |

### Liquidity (4 endpoints)
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/liquidity/lock` | ✅ | Record new lock |
| GET | `/api/liquidity/:tokenAddress` | ❌ | Get lock info |
| GET | `/api/liquidity/all` | ❌ | All active locks |
| POST | `/api/liquidity/claim/:lockId` | ✅ | Record claim |

### Users (6 endpoints)
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/users/connect` | ❌ | Register wallet |
| POST | `/api/users/nonce` | ❌ | Get auth nonce |
| POST | `/api/users/verify` | ❌ | Verify & login |
| GET | `/api/users/profile` | ✅ | Get own profile |
| GET | `/api/users/:wallet` | ❌ | Get user info |
| GET | `/api/users/:wallet/tokens` | ❌ | User's tokens |

### Admin (7 endpoints)
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/admin/stats` | Admin | Platform stats |
| GET | `/api/admin/config` | Admin | Get config |
| PUT | `/api/admin/config` | Admin | Update config |
| GET | `/api/admin/tokens` | Admin | All tokens |
| PUT | `/api/admin/tokens/:address/status` | Admin | Toggle token |
| GET | `/api/admin/users` | Admin | All users (NEW) |
| PUT | `/api/admin/users/:wallet/admin` | Admin | Set admin (NEW) |

### Upload (2 endpoints)
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/upload/logo` | ✅ | Upload token logo |
| DELETE | `/api/upload/logo` | ✅ | Delete logo |

---

## 🔐 Authentication Flow

```
1. Frontend: POST /api/users/nonce { wallet }
2. User signs the nonce message with Phantom
3. Frontend: POST /api/users/verify { wallet, signature }
4. Backend verifies signature using nacl
5. JWT token issued (valid 7 days)
6. Token used in Authorization header for protected routes
```

---

## 🔗 Service Layer

### Services (6 total)
| Service | Description |
|---------|-------------|
| `tokenService` | Token CRUD operations |
| `liquidityService` | Lock management |
| `userService` | User management |
| `adminService` | Admin operations (NEW) |
| `uploadService` | File uploads |
| `solanaService` | Blockchain verification (NEW) |

---

## ✅ Testing

### Test Files (11 total)
| File | Description | Tests |
|------|-------------|-------|
| `integration/api.test.js` | Health & base routes | ~10 |
| `integration/tokens.test.js` | Token API | ~12 |
| `integration/liquidity.test.js` | Liquidity API | ~12 |
| `integration/users.test.js` | User/Auth routes | ~12 |
| `integration/admin.test.js` | Admin routes | ~10 |
| `integration/upload.test.js` | Upload routes | ~6 |
| `unit/config.test.js` | Configuration | ~10 |
| `unit/utils.test.js` | Utilities | ~15 |
| `unit/services.test.js` | Service layer | ~5 |
| `unit/solanaService.test.js` | Solana service (NEW) | ~6 |
| `unit/adminService.test.js` | Admin service (NEW) | ~8 |

**Total: ~106 tests**

### Run Tests
```bash
cd backend
npm test              # Run all tests with coverage
npm run test:watch    # Watch mode
```

---

## 📊 Acceptance Criteria

1. ✅ All 25 API endpoints functional
2. ✅ Wallet authentication with signature verification
3. ✅ Supabase integration complete
4. ✅ File upload working
5. ✅ Rate limiting enabled (100 req/15min)
6. ✅ Admin-only routes protected
7. ✅ Request validation middleware
8. ✅ Solana blockchain verification
9. ✅ Enhanced health check with service status
10. ✅ Comprehensive test suite (106 tests)

---

## 📅 Timeline

| Task | Duration | Status |
|------|----------|--------|
| Project setup | 3 hours | ✅ Done |
| Authentication | 4 hours | ✅ Done |
| Token API | 6 hours | ✅ Done |
| Liquidity API | 4 hours | ✅ Done |
| User & Admin API | 4 hours | ✅ Done |
| File upload | 3 hours | ✅ Done |
| Blockchain services | 2 hours | ✅ Done |
| Testing | 8 hours | ✅ Done |
| **Total** | **~4-5 days** | **100% Complete** |

---

## 🚀 Running the Backend

```bash
# Navigate to backend
cd backend

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your Supabase credentials

# Run development server
npm run dev

# Run tests
npm test

# Run production
npm start
```

### Environment Variables
```env
# Server
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:3000

# Supabase
SUPABASE_URL=your_supabase_project_url
SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_KEY=your_supabase_service_role_key

# Solana
SOLANA_RPC_URL=https://api.devnet.solana.com
SOLANA_NETWORK=devnet
PROGRAM_ID=your_deployed_program_id

# Platform
PLATFORM_WALLET=your_platform_wallet_address
PLATFORM_FEE_BPS=50
MIN_LOCK_DAYS=90

# JWT
JWT_SECRET=your_super_secret_jwt_key
JWT_EXPIRES_IN=7d

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# File Upload
MAX_FILE_SIZE_MB=5
```
