# 📁 Team 11 - Project Structure

## Complete Directory Structure

```
coin_creation/
│
├── 📁 Docs/                           # Documentation
│   ├── aboutproject.md                # Project overview
│   ├── architechture.md               # System architecture
│   ├── projectstructure.md            # This file
│   └── phases/                        # Development phases
│       ├── phase-0-setup.md
│       ├── phase-1-smart-contracts.md
│       ├── phase-2-backend.md
│       ├── phase-3-frontend.md
│       └── phase-4-integration.md
│
├── 📁 programs/                       # Solana Smart Contracts (Rust)
│   ├── Anchor.toml                    # Anchor configuration
│   ├── Cargo.toml                     # Rust workspace config
│   │
│   └── 📁 team-11/
│       ├── Cargo.toml
│       └── 📁 src/
│           ├── lib.rs                 # Main program entry
│           ├── errors.rs              # Custom error codes
│           │
│           ├── 📁 instructions/       # Program instructions
│           │   ├── mod.rs
│           │   ├── initialize.rs      # Initialize platform
│           │   ├── create_token.rs    # Create SPL token
│           │   ├── lock_liquidity.rs  # Lock SOL liquidity
│           │   ├── unlock_liquidity.rs# Check unlock status
│           │   ├── claim_liquidity.rs # Claim unlocked SOL
│           │   └── update_fees.rs     # Update creator fees
│           │
│           └── 📁 state/              # Program state accounts
│               ├── mod.rs
│               ├── platform_config.rs # Platform configuration
│               ├── token_config.rs    # Token configuration
│               └── liquidity_lock.rs  # Liquidity lock data
│
├── 📁 backend/                        # Node.js Backend (JavaScript)
│   ├── package.json
│   ├── .env.example
│   ├── .env                           # Environment variables
│   │
│   └── 📁 src/
│       ├── index.js                   # Entry point
│       ├── app.js                     # Express app setup
│       │
│       ├── 📁 config/
│       │   ├── database.js            # Supabase configuration
│       │   ├── solana.js              # Solana RPC config
│       │   └── constants.js           # App constants
│       │
│       ├── 📁 routes/
│       │   ├── index.js               # Route aggregator
│       │   ├── tokens.js              # Token endpoints
│       │   ├── liquidity.js           # Liquidity lock endpoints
│       │   ├── users.js               # User endpoints
│       │   └── admin.js               # Admin endpoints
│       │
│       ├── 📁 controllers/
│       │   ├── tokenController.js
│       │   ├── liquidityController.js
│       │   ├── userController.js
│       │   └── adminController.js
│       │
│       ├── 📁 services/
│       │   ├── tokenService.js        # Token business logic
│       │   ├── liquidityService.js    # Liquidity lock logic
│       │   ├── solanaService.js       # Solana interactions
│       │   └── storageService.js      # File upload handling
│       │
│       ├── 📁 middleware/
│       │   ├── auth.js                # Wallet signature auth
│       │   ├── admin.js               # Admin role check
│       │   ├── rateLimit.js           # Rate limiting
│       │   └── validation.js          # Input validation
│       │
│       ├── 📁 models/
│       │   ├── Token.js               # Token model
│       │   ├── LiquidityLock.js       # Liquidity lock model
│       │   ├── User.js                # User model
│       │   └── PlatformConfig.js      # Platform config model
│       │
│       └── 📁 utils/
│           ├── logger.js              # Logging utility
│           ├── errors.js              # Error handling
│           └── helpers.js             # Helper functions
│
├── 📁 frontend/                       # Next.js Frontend (TypeScript)
│   ├── package.json
│   ├── next.config.js
│   ├── tsconfig.json
│   ├── .env.local.example
│   ├── .env.local                     # Environment variables
│   │
│   ├── 📁 public/
│   │   ├── favicon.ico
│   │   ├── logo.svg
│   │   └── 📁 images/
│   │       └── noise.png              # Background texture
│   │
│   ├── 📁 app/                        # Next.js App Router
│   │   ├── layout.tsx                 # Root layout
│   │   ├── page.tsx                   # Home page
│   │   ├── globals.css                # Global styles (Koyeb design)
│   │   │
│   │   ├── 📁 create/
│   │   │   └── page.tsx               # Token creation page
│   │   │
│   │   ├── 📁 dashboard/
│   │   │   └── page.tsx               # All coins dashboard
│   │   │
│   │   ├── 📁 token/
│   │   │   └── 📁 [address]/
│   │   │       └── page.tsx           # Token details page
│   │   │
│   │   ├── 📁 my-tokens/
│   │   │   └── page.tsx               # Creator's tokens
│   │   │
│   │   └── 📁 admin/
│   │       └── page.tsx               # Admin dashboard
│   │
│   ├── 📁 components/
│   │   ├── 📁 ui/                     # Koyeb-styled components
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── Loading.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Countdown.tsx
│   │   │   ├── Toast.tsx
│   │   │   └── index.ts               # Barrel export
│   │   │
│   │   ├── 📁 layout/
│   │   │   ├── Header.tsx             # Navigation header
│   │   │   ├── Footer.tsx
│   │   │   ├── Container.tsx
│   │   │   └── GrainOverlay.tsx       # Noise texture
│   │   │
│   │   ├── 📁 token/
│   │   │   ├── TokenCard.tsx          # Token display card
│   │   │   ├── TokenGrid.tsx          # Grid of tokens
│   │   │   ├── TokenCreationForm.tsx  # Creation form
│   │   │   ├── TokenDetails.tsx       # Full token info
│   │   │   ├── LiquidityLockCard.tsx  # Lock info display
│   │   │   └── LiquidityLockForm.tsx  # Lock creation form
│   │   │
│   │   ├── 📁 wallet/
│   │   │   ├── WalletButton.tsx       # Connect wallet btn
│   │   │   └── WalletProvider.tsx     # Wallet context
│   │   │
│   │   └── 📁 admin/
│   │       ├── StatsOverview.tsx
│   │       ├── ConfigPanel.tsx
│   │       └── TokenManagement.tsx
│   │
│   ├── 📁 hooks/
│   │   ├── useWallet.ts               # Wallet connection
│   │   ├── useToken.ts                # Token operations
│   │   ├── useLiquidityLock.ts        # Lock operations
│   │   ├── useApi.ts                  # API calls
│   │   └── useCountdown.ts            # Countdown timer
│   │
│   ├── 📁 lib/
│   │   ├── solana.ts                  # Solana utilities
│   │   ├── api.ts                     # API client
│   │   ├── utils.ts                   # Helper functions
│   │   └── constants.ts               # App constants
│   │
│   ├── 📁 providers/
│   │   ├── WalletProvider.tsx
│   │   ├── ThemeProvider.tsx
│   │   └── ToastProvider.tsx
│   │
│   ├── 📁 types/
│   │   ├── token.ts                   # Token types
│   │   ├── liquidity.ts               # Liquidity types
│   │   ├── user.ts                    # User types
│   │   └── api.ts                     # API response types
│   │
│   └── 📁 styles/
│       └── globals.css                # Koyeb design system
│
├── 📁 tests/                          # All Test Files
│   ├── 📁 programs/                   # Smart contract tests
│   │   ├── team-11.ts         # Anchor tests
│   │   └── utils.ts                   # Test utilities
│   │
│   ├── 📁 backend/
│   │   ├── 📁 unit/                   # Unit tests
│   │   │   ├── tokenService.test.js
│   │   │   ├── liquidityService.test.js
│   │   │   └── utils.test.js
│   │   │
│   │   ├── 📁 integration/            # Integration tests
│   │   │   ├── tokens.test.js
│   │   │   ├── liquidity.test.js
│   │   │   └── auth.test.js
│   │   │
│   │   └── 📁 fixtures/               # Test data
│   │       ├── tokens.json
│   │       └── users.json
│   │
│   └── 📁 frontend/
│       ├── 📁 unit/                   # Component tests
│       │   ├── TokenCard.test.tsx
│       │   ├── Button.test.tsx
│       │   └── hooks.test.ts
│       │
│       └── 📁 e2e/                    # End-to-end tests
│           ├── createToken.test.ts
│           ├── lockLiquidity.test.ts
│           └── dashboard.test.ts
│
├── 📁 scripts/                        # Deployment & utility scripts
│   ├── deploy-program.sh              # Deploy Solana program
│   ├── setup-database.sql             # Supabase schema
│   └── generate-keypair.sh            # Generate Solana keypair
│
├── 📁 .github/                        # GitHub Actions
│   └── 📁 workflows/
│       ├── test.yml                   # Run tests
│       ├── deploy-frontend.yml        # Deploy to Vercel
│       └── deploy-backend.yml         # Deploy to Railway
│
├── .gitignore
├── README.md
└── package.json                       # Root workspace config
```

---

## Technology Breakdown

### Programs (Solana Smart Contracts)

| File | Purpose |
|------|---------|
| `lib.rs` | Main entry point, declares program ID and modules |
| `errors.rs` | Custom error codes for better error handling |
| `instructions/*.rs` | Individual instruction handlers |
| `state/*.rs` | Account structures for on-chain data |

### Backend

| Directory | Purpose |
|-----------|---------|
| `routes/` | API endpoint definitions |
| `controllers/` | Request handling logic |
| `services/` | Business logic and external integrations |
| `middleware/` | Auth, validation, rate limiting |
| `models/` | Database model definitions |
| `utils/` | Helper functions and utilities |

### Frontend

| Directory | Purpose |
|-----------|---------|
| `app/` | Next.js pages and routing |
| `components/ui/` | Reusable Koyeb-styled components |
| `components/token/` | Token-specific components |
| `components/wallet/` | Wallet connection components |
| `hooks/` | Custom React hooks |
| `lib/` | Utility functions and API client |
| `providers/` | React context providers |
| `types/` | TypeScript type definitions |

---

## Configuration Files

### Root Level

```
├── package.json          # Workspace configuration
├── .gitignore           # Git ignore rules
├── README.md            # Project documentation
```

### Programs

```
├── Anchor.toml          # Anchor framework config
├── Cargo.toml           # Rust workspace config
```

### Backend

```
├── package.json         # Node.js dependencies
├── .env.example         # Environment template
├── .env                 # Environment variables (gitignored)
```

### Frontend

```
├── package.json         # Next.js dependencies
├── next.config.js       # Next.js configuration
├── tsconfig.json        # TypeScript config
├── .env.local.example   # Environment template
├── .env.local           # Environment variables (gitignored)
```

---

## Environment Variables

### Backend (.env)

```env
# Server
PORT=3001
NODE_ENV=development

# Supabase
SUPABASE_URL=your_supabase_url
SUPABASE_KEY=your_supabase_anon_key
SUPABASE_SERVICE_KEY=your_supabase_service_key

# Solana
SOLANA_RPC_URL=https://api.devnet.solana.com
PROGRAM_ID=your_program_id

# Platform
PLATFORM_WALLET=your_platform_wallet
PLATFORM_FEE_PERCENTAGE=0.5
MIN_LOCK_PERIOD_DAYS=90

# JWT
JWT_SECRET=your_jwt_secret
```

### Frontend (.env.local)

```env
# API
NEXT_PUBLIC_API_URL=http://localhost:3001/api

# Solana
NEXT_PUBLIC_SOLANA_RPC_URL=https://api.devnet.solana.com
NEXT_PUBLIC_SOLANA_NETWORK=devnet
NEXT_PUBLIC_PROGRAM_ID=your_program_id

# Platform
NEXT_PUBLIC_PLATFORM_NAME=Team 11
```

---

## Commands Reference

### Development

```bash
# Install all dependencies
npm install

# Start backend development server
cd backend && npm run dev

# Start frontend development server
cd frontend && npm run dev

# Build and deploy Solana program
cd programs && anchor build && anchor deploy

# Run tests
npm run test                    # All tests
npm run test:programs           # Smart contract tests
npm run test:backend            # Backend tests
npm run test:frontend           # Frontend tests
```

### Production

```bash
# Build frontend
cd frontend && npm run build

# Start backend production
cd backend && npm start

# Deploy to Vercel (frontend)
vercel --prod

# Deploy to Railway (backend)
railway up
```
