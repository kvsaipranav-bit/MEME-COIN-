const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const routes = require('./routes');
const { errorHandler, notFoundHandler } = require('./utils/errors');
const { logger } = require('./utils/logger');

const app = express();

// Security middleware
app.use(helmet());

// CORS configuration
app.use(cors({
    origin: process.env.NODE_ENV === 'production'
        ? process.env.FRONTEND_URL
        : ['http://localhost:3000', 'http://127.0.0.1:3000'],
    credentials: true,
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
    message: { error: 'Too many requests, please try again later.' },
    standardHeaders: true,
    legacyHeaders: false,
});
app.use('/api/', limiter);

// Request parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Logging
app.use(morgan('combined', {
    stream: { write: (message) => logger.info(message.trim()) }
}));

// Health check
app.get('/health', async (req, res) => {
    const health = {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        network: process.env.SOLANA_NETWORK || 'devnet',
        version: '1.0.0',
        services: {
            api: 'up'
        }
    };

    // Check database connectivity (non-blocking)
    try {
        const { supabase } = require('./config/database');
        if (supabase) {
            const { error } = await supabase.from('users').select('id', { count: 'exact', head: true });
            health.services.database = error ? 'degraded' : 'up';
        } else {
            health.services.database = 'not_configured';
        }
    } catch (e) {
        health.services.database = 'down';
    }

    // Check Solana connectivity (non-blocking)
    try {
        const { connection } = require('./config/solana');
        await connection.getSlot();
        health.services.solana = 'up';
    } catch (e) {
        health.services.solana = 'down';
    }

    // Set overall status
    const serviceStatuses = Object.values(health.services);
    if (serviceStatuses.includes('down')) {
        health.status = 'degraded';
    }

    res.json(health);
});

// API Routes
app.use('/api', routes);

// Error handling
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
