/**
 * Application Constants
 * Configuration values used throughout the application
 */

// Solana Network Configuration
const SOLANA_NETWORK = {
    DEVNET: 'devnet',
    MAINNET: 'mainnet-beta',
    TESTNET: 'testnet',
    DEFAULT: process.env.SOLANA_NETWORK || 'devnet',
};

// Token Defaults
const TOKEN_DEFAULTS = {
    DECIMALS: 9,
    INITIAL_SUPPLY: 1000000000, // 1 billion
    MAX_NAME_LENGTH: 50,
    MAX_SYMBOL_LENGTH: 10,
    MAX_DESCRIPTION_LENGTH: 500,
};

// Lock Defaults
const LOCK_DEFAULTS = {
    MIN_LOCK_DAYS: parseInt(process.env.MIN_LOCK_DAYS) || 90,
    MAX_LOCK_DAYS: 365 * 5, // 5 years
    MIN_LOCK_AMOUNT: 0.1, // SOL
    DEFAULT_LOCK_DAYS: 90,
};

// Validation Patterns
const VALIDATION = {
    // Solana addresses are base58 encoded, 32-44 characters
    WALLET_ADDRESS_REGEX: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/,
    // Token names: alphanumeric with spaces
    TOKEN_NAME_REGEX: /^[\w\s]{1,50}$/,
    // Token symbols: uppercase alphanumeric
    TOKEN_SYMBOL_REGEX: /^[A-Z0-9]{1,10}$/,
};

// Platform Settings
const PLATFORM = {
    FEE_BPS: parseInt(process.env.PLATFORM_FEE_BPS) || 50, // 0.5%
    MAX_CREATOR_FEE_BPS: 1000, // 10%
};

// File Upload
const UPLOAD = {
    MAX_LOGO_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_TYPES: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'],
};

// Pagination
const PAGINATION = {
    DEFAULT_PAGE_SIZE: 20,
    MAX_PAGE_SIZE: 100,
};

// Lock Status Enum
const LOCK_STATUS = {
    LOCKED: 'locked',
    UNLOCKED: 'unlocked',
    CLAIMED: 'claimed',
};

// JWT
const JWT = {
    EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
};

module.exports = {
    SOLANA_NETWORK,
    TOKEN_DEFAULTS,
    LOCK_DEFAULTS,
    VALIDATION,
    PLATFORM,
    UPLOAD,
    PAGINATION,
    LOCK_STATUS,
    JWT,

    // Legacy exports for backwards compatibility
    PLATFORM_FEE_BPS: PLATFORM.FEE_BPS,
    MIN_LOCK_DAYS: LOCK_DEFAULTS.MIN_LOCK_DAYS,
    MAX_CREATOR_FEE_BPS: PLATFORM.MAX_CREATOR_FEE_BPS,
    MAX_TOKEN_NAME_LENGTH: TOKEN_DEFAULTS.MAX_NAME_LENGTH,
    MAX_TOKEN_SYMBOL_LENGTH: TOKEN_DEFAULTS.MAX_SYMBOL_LENGTH,
    MAX_DESCRIPTION_LENGTH: TOKEN_DEFAULTS.MAX_DESCRIPTION_LENGTH,
    MAX_LOGO_SIZE: UPLOAD.MAX_LOGO_SIZE,
    ALLOWED_LOGO_TYPES: UPLOAD.ALLOWED_TYPES,
    DEFAULT_PAGE_SIZE: PAGINATION.DEFAULT_PAGE_SIZE,
    MAX_PAGE_SIZE: PAGINATION.MAX_PAGE_SIZE,
    JWT_EXPIRES_IN: JWT.EXPIRES_IN,
};
