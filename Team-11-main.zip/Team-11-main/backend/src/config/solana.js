const { Connection, clusterApiUrl, PublicKey } = require('@solana/web3.js');

// ===== DEPLOYED PROGRAM ID =====
const DEPLOYED_PROGRAM_ID = '63eKfsfRtuSjQXsrZKKQBqdDyFFwRYnLRPZ83MWDMg5u';

const network = process.env.SOLANA_NETWORK || 'devnet';
const rpcUrl = process.env.SOLANA_RPC_URL || clusterApiUrl(network);

const connection = new Connection(rpcUrl, 'confirmed');

const getConnection = () => connection;

const getProgramId = () => process.env.PROGRAM_ID || DEPLOYED_PROGRAM_ID;

const getProgramPublicKey = () => new PublicKey(getProgramId());

// PDA Seeds
const SEEDS = {
    PLATFORM_CONFIG: 'platform_config',
    TOKEN_METADATA: 'token_metadata',
    LIQUIDITY_LOCK: 'liquidity_lock',
};

module.exports = {
    connection,
    getConnection,
    getProgramId,
    getProgramPublicKey,
    network,
    rpcUrl,
    SEEDS,
    DEPLOYED_PROGRAM_ID
};

