/**
 * Admin Controller
 * Handles admin-related API requests
 */

const adminService = require('../services/adminService');
const { logger } = require('../utils/logger');

const adminController = {
    // Get platform statistics
    async getStats(req, res, next) {
        try {
            const stats = await adminService.getStats();
            res.json(stats);
        } catch (error) {
            next(error);
        }
    },

    // Get platform configuration
    async getConfig(req, res, next) {
        try {
            const config = await adminService.getConfig();
            res.json(config);
        } catch (error) {
            next(error);
        }
    },

    // Update platform configuration
    async updateConfig(req, res, next) {
        try {
            const config = await adminService.updateConfig(req.body, req.user.wallet);
            res.json(config);
        } catch (error) {
            next(error);
        }
    },

    // Update token status (admin)
    async updateTokenStatus(req, res, next) {
        try {
            const { address } = req.params;
            const { is_active } = req.body;

            const token = await adminService.updateTokenStatus(address, is_active, req.user.wallet);
            res.json(token);
        } catch (error) {
            next(error);
        }
    },

    // Get all tokens (admin view with more details)
    async getAllTokensAdmin(req, res, next) {
        try {
            const { page = 1, limit = 50, includeInactive = 'true' } = req.query;

            const result = await adminService.getAllTokens({
                page: parseInt(page),
                limit: parseInt(limit),
                includeInactive: includeInactive === 'true'
            });

            res.json(result);
        } catch (error) {
            next(error);
        }
    },

    // Get all users (admin view)
    async getAllUsers(req, res, next) {
        try {
            const { page = 1, limit = 50 } = req.query;

            const result = await adminService.getAllUsers({
                page: parseInt(page),
                limit: parseInt(limit)
            });

            res.json(result);
        } catch (error) {
            next(error);
        }
    },

    // Set user admin status
    async setUserAdmin(req, res, next) {
        try {
            const { wallet } = req.params;
            const { is_admin } = req.body;

            const user = await adminService.setUserAdmin(wallet, is_admin, req.user.wallet);
            res.json(user);
        } catch (error) {
            next(error);
        }
    }
};

module.exports = adminController;
