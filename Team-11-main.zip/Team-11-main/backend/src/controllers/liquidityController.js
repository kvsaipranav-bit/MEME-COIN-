const liquidityService = require('../services/liquidityService');
const { logger } = require('../utils/logger');
const { AppError } = require('../utils/errors');

const liquidityController = {
    // Get all active locks
    async getAllLocks(req, res, next) {
        try {
            const { status, page = 1, limit = 20 } = req.query;

            const result = await liquidityService.getAllLocks({
                status,
                page: parseInt(page),
                limit: parseInt(limit)
            });

            res.json(result);
        } catch (error) {
            next(error);
        }
    },

    // Get lock info for a specific token
    async getLockByToken(req, res, next) {
        try {
            const { tokenAddress } = req.params;
            const lock = await liquidityService.getLockByToken(tokenAddress);

            if (!lock) {
                throw new AppError('Liquidity lock not found', 404);
            }

            res.json(lock);
        } catch (error) {
            next(error);
        }
    },

    // Create new liquidity lock
    async createLock(req, res, next) {
        try {
            const lockData = {
                ...req.body,
                creator_wallet: req.user.wallet
            };

            const lock = await liquidityService.createLock(lockData);

            logger.info(`Liquidity locked: ${lock.amount_sol} SOL for token ${lock.token_id}`);

            res.status(201).json(lock);
        } catch (error) {
            next(error);
        }
    },

    // Claim unlocked liquidity
    async claimLiquidity(req, res, next) {
        try {
            const { lockId } = req.params;

            const lock = await liquidityService.claimLiquidity(lockId, req.user.wallet);

            logger.info(`Liquidity claimed: ${lock.amount_sol} SOL by ${req.user.wallet}`);

            res.json(lock);
        } catch (error) {
            next(error);
        }
    }
};

module.exports = liquidityController;
