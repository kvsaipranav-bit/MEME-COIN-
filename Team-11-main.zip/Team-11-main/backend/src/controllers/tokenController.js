const tokenService = require('../services/tokenService');
const { logger } = require('../utils/logger');
const { AppError } = require('../utils/errors');

const tokenController = {
    // Get all tokens with pagination
    async getAllTokens(req, res, next) {
        try {
            const { page = 1, limit = 20, search, sort = 'created_at', order = 'desc' } = req.query;

            const result = await tokenService.getAllTokens({
                page: parseInt(page),
                limit: parseInt(limit),
                search,
                sort,
                order
            });

            res.json(result);
        } catch (error) {
            next(error);
        }
    },

    // Get token by mint address
    async getTokenByAddress(req, res, next) {
        try {
            const { address } = req.params;
            const token = await tokenService.getTokenByAddress(address);

            if (!token) {
                throw new AppError('Token not found', 404);
            }

            res.json(token);
        } catch (error) {
            next(error);
        }
    },

    // Get tokens by creator wallet
    async getTokensByCreator(req, res, next) {
        try {
            const { wallet } = req.params;
            const tokens = await tokenService.getTokensByCreator(wallet);

            res.json(tokens);
        } catch (error) {
            next(error);
        }
    },

    // Create new token
    async createToken(req, res, next) {
        try {
            const tokenData = {
                ...req.body,
                creator_wallet: req.user.wallet
            };

            const token = await tokenService.createToken(tokenData);

            logger.info(`Token created: ${token.symbol} by ${req.user.wallet}`);

            res.status(201).json(token);
        } catch (error) {
            next(error);
        }
    },

    // Update creator fees
    async updateCreatorFees(req, res, next) {
        try {
            const { address } = req.params;
            const { fee_percentage } = req.body;

            const token = await tokenService.updateCreatorFees(
                address,
                req.user.wallet,
                fee_percentage
            );

            res.json(token);
        } catch (error) {
            next(error);
        }
    },

    // Update token status (creator only)
    async updateTokenStatus(req, res, next) {
        try {
            const { address } = req.params;
            const { is_active } = req.body;

            const token = await tokenService.updateTokenStatus(
                address,
                req.user.wallet,
                is_active
            );

            res.json(token);
        } catch (error) {
            next(error);
        }
    }
};

module.exports = tokenController;
