const uploadService = require('../services/uploadService');
const { logger } = require('../utils/logger');
const { AppError } = require('../utils/errors');

const uploadController = {
    // Upload token logo
    async uploadLogo(req, res, next) {
        try {
            if (!req.file) {
                throw new AppError('No file uploaded', 400);
            }

            // Validate image
            await uploadService.validateImage(req.file);

            // Upload to storage
            const result = await uploadService.uploadToStorage(req.file, 'logos');

            logger.info(`Logo uploaded by ${req.user.wallet}: ${result.path}`);

            res.status(201).json({
                success: true,
                data: {
                    url: result.url,
                    path: result.path,
                    originalName: result.originalName,
                    size: result.size
                }
            });
        } catch (error) {
            next(error);
        }
    },

    // Delete uploaded file
    async deleteLogo(req, res, next) {
        try {
            const { path: filePath } = req.body;

            if (!filePath) {
                throw new AppError('File path required', 400);
            }

            await uploadService.deleteFromStorage(filePath, 'logos');

            logger.info(`Logo deleted by ${req.user.wallet}: ${filePath}`);

            res.json({
                success: true,
                message: 'File deleted successfully'
            });
        } catch (error) {
            next(error);
        }
    }
};

module.exports = uploadController;
