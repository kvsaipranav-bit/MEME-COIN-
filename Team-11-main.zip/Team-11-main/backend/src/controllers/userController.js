const userService = require('../services/userService');
const tokenService = require('../services/tokenService');
const { logger } = require('../utils/logger');
const { AppError } = require('../utils/errors');
const jwt = require('jsonwebtoken');
const nacl = require('tweetnacl');
const bs58 = require('bs58');
const { v4: uuidv4 } = require('uuid');

// Store nonces temporarily (in production, use Redis)
const nonceStore = new Map();

const userController = {
    // Generate nonce for wallet signature
    async getNonce(req, res, next) {
        try {
            const { wallet } = req.body;

            if (!wallet) {
                throw new AppError('Wallet address required', 400);
            }

            const nonce = uuidv4();
            const message = `Sign this message to verify your wallet ownership.\n\nNonce: ${nonce}\nTimestamp: ${Date.now()}`;

            // Store nonce with expiry (5 minutes)
            nonceStore.set(wallet, { nonce, message, expires: Date.now() + 5 * 60 * 1000 });

            res.json({ message, nonce });
        } catch (error) {
            next(error);
        }
    },

    // Verify wallet signature and issue JWT
    async verifySignature(req, res, next) {
        try {
            const { wallet, signature } = req.body;

            if (!wallet || !signature) {
                throw new AppError('Wallet and signature required', 400);
            }

            const storedData = nonceStore.get(wallet);

            if (!storedData || Date.now() > storedData.expires) {
                nonceStore.delete(wallet);
                throw new AppError('Nonce expired, please request a new one', 401);
            }

            // Verify signature
            const messageBytes = new TextEncoder().encode(storedData.message);
            const signatureBytes = bs58.decode(signature);
            const publicKeyBytes = bs58.decode(wallet);

            const isValid = nacl.sign.detached.verify(
                messageBytes,
                signatureBytes,
                publicKeyBytes
            );

            if (!isValid) {
                throw new AppError('Invalid signature', 401);
            }

            // Clear nonce
            nonceStore.delete(wallet);

            // Get or create user
            let user = await userService.getUserByWallet(wallet);
            if (!user) {
                user = await userService.createUser(wallet);
            }

            // Issue JWT
            const token = jwt.sign(
                { wallet: user.wallet_address, isAdmin: user.is_admin },
                process.env.JWT_SECRET,
                { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
            );

            logger.info(`User authenticated: ${wallet}`);

            res.json({
                token,
                user: {
                    wallet: user.wallet_address,
                    isAdmin: user.is_admin,
                    createdAt: user.created_at
                }
            });
        } catch (error) {
            next(error);
        }
    },

    // Connect wallet (deprecated, use getNonce + verifySignature)
    async connectWallet(req, res, next) {
        try {
            const { wallet } = req.body;

            if (!wallet) {
                throw new AppError('Wallet address required', 400);
            }

            let user = await userService.getUserByWallet(wallet);

            if (!user) {
                user = await userService.createUser(wallet);
                logger.info(`New user registered: ${wallet}`);
            }

            res.json({
                wallet: user.wallet_address,
                isAdmin: user.is_admin,
                createdAt: user.created_at
            });
        } catch (error) {
            next(error);
        }
    },

    // Get user profile (authenticated)
    async getProfile(req, res, next) {
        try {
            const user = await userService.getUserByWallet(req.user.wallet);

            if (!user) {
                throw new AppError('User not found', 404);
            }

            res.json(user);
        } catch (error) {
            next(error);
        }
    },

    // Get user by wallet address
    async getUserByWallet(req, res, next) {
        try {
            const { wallet } = req.params;
            const user = await userService.getUserByWallet(wallet);

            if (!user) {
                throw new AppError('User not found', 404);
            }

            res.json({
                wallet: user.wallet_address,
                createdAt: user.created_at
            });
        } catch (error) {
            next(error);
        }
    },

    // Get user's created tokens
    async getUserTokens(req, res, next) {
        try {
            const { wallet } = req.params;
            const tokens = await tokenService.getTokensByCreator(wallet);

            res.json(tokens);
        } catch (error) {
            next(error);
        }
    }
};

module.exports = userController;
