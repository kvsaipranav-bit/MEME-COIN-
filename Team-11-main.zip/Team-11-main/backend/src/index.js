require('dotenv').config();
const app = require('./app');
const { logger } = require('./utils/logger');
const { displayStartup, displayServiceStatus, displayShutdown } = require('./utils/banner');
const { getProgramId, network } = require('./config/solana');

const PORT = process.env.PORT || 3001;
const VERSION = '1.0.0';

// Start server with professional display
app.listen(PORT, async () => {
  // Display beautiful startup banner
  displayStartup({
    port: PORT,
    environment: process.env.NODE_ENV || 'development',
    network: network,
    programId: getProgramId(),
    version: VERSION,
  });

  // Check and display service status after a short delay
  setTimeout(async () => {
    const services = {
      'API Server': 'up',
      'Solana RPC': 'checking...',
      'Database': 'checking...',
    };

    // Check Solana connection
    try {
      const { connection } = require('./config/solana');
      await connection.getSlot();
      services['Solana RPC'] = 'up';
    } catch (e) {
      services['Solana RPC'] = 'down';
    }

    // Check database connection
    try {
      const { supabase } = require('./config/database');
      if (supabase) {
        const { error } = await supabase.from('users').select('id', { count: 'exact', head: true });
        services['Database'] = error ? 'degraded' : 'up';
      } else {
        services['Database'] = 'not_configured';
      }
    } catch (e) {
      services['Database'] = 'down';
    }

    displayServiceStatus(services);
    console.log('');
    logger.info('Listening for incoming requests...');
  }, 1000);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  displayShutdown();
  process.exit(0);
});

process.on('SIGINT', () => {
  displayShutdown();
  process.exit(0);
});

