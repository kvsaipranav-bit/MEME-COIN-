const { AppError } = require('../utils/errors');
const userService = require('../services/userService');

const adminOnly = async (req, res, next) => {
    try {
        if (!req.user) {
            throw new AppError('Authentication required', 401);
        }

        // Check admin status from database
        const isAdmin = await userService.isAdmin(req.user.wallet);

        if (!isAdmin) {
            throw new AppError('Admin access required', 403);
        }

        next();
    } catch (error) {
        next(error);
    }
};

module.exports = { adminOnly };
