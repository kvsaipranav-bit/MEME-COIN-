const jwt = require('jsonwebtoken');
const { AppError } = require('../utils/errors');

const auth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new AppError('Authentication required', 401);
        }

        const token = authHeader.split(' ')[1];

        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            req.user = {
                wallet: decoded.wallet,
                isAdmin: decoded.isAdmin
            };
            next();
        } catch (err) {
            throw new AppError('Invalid or expired token', 401);
        }
    } catch (error) {
        next(error);
    }
};

// Optional auth - doesn't fail if no token
const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;

        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.split(' ')[1];
            try {
                const decoded = jwt.verify(token, process.env.JWT_SECRET);
                req.user = {
                    wallet: decoded.wallet,
                    isAdmin: decoded.isAdmin
                };
            } catch (err) {
                // Ignore invalid token for optional auth
            }
        }
        next();
    } catch (error) {
        next(error);
    }
};

module.exports = { auth, optionalAuth };
