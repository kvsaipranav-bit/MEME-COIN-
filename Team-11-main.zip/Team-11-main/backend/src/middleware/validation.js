const { AppError } = require('../utils/errors');
const constants = require('../config/constants');

const validateToken = (req, res, next) => {
    const { name, symbol, initial_supply, decimals, creator_fee_percentage } = req.body;

    // Name validation
    if (!name || typeof name !== 'string') {
        throw new AppError('Token name is required', 400);
    }
    if (name.length > constants.MAX_TOKEN_NAME_LENGTH) {
        throw new AppError(`Token name must be ${constants.MAX_TOKEN_NAME_LENGTH} characters or less`, 400);
    }

    // Symbol validation
    if (!symbol || typeof symbol !== 'string') {
        throw new AppError('Token symbol is required', 400);
    }
    if (symbol.length > constants.MAX_TOKEN_SYMBOL_LENGTH) {
        throw new AppError(`Token symbol must be ${constants.MAX_TOKEN_SYMBOL_LENGTH} characters or less`, 400);
    }

    // Supply validation
    if (!initial_supply || initial_supply <= 0) {
        throw new AppError('Initial supply must be greater than 0', 400);
    }

    // Decimals validation
    if (decimals !== undefined && (decimals < 0 || decimals > 9)) {
        throw new AppError('Decimals must be between 0 and 9', 400);
    }

    // Fee validation
    if (creator_fee_percentage !== undefined) {
        if (creator_fee_percentage < 0 || creator_fee_percentage > 10) {
            throw new AppError('Creator fee must be between 0% and 10%', 400);
        }
    }

    next();
};

const validateLiquidityLock = (req, res, next) => {
    const { token_address, amount_sol, lock_duration_days } = req.body;

    if (!token_address) {
        throw new AppError('Token address is required', 400);
    }

    if (!amount_sol || amount_sol <= 0) {
        throw new AppError('Lock amount must be greater than 0', 400);
    }

    if (!lock_duration_days || lock_duration_days < constants.MIN_LOCK_DAYS) {
        throw new AppError(`Lock duration must be at least ${constants.MIN_LOCK_DAYS} days`, 400);
    }

    next();
};

const validateWallet = (req, res, next) => {
    const { wallet } = req.body;

    if (!wallet) {
        throw new AppError('Wallet address is required', 400);
    }

    // Basic Solana wallet address validation (base58, 32-44 chars)
    const walletRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
    if (!walletRegex.test(wallet)) {
        throw new AppError('Invalid wallet address format', 400);
    }

    next();
};

module.exports = { validateToken, validateLiquidityLock, validateWallet };
