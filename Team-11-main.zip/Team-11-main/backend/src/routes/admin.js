const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { auth } = require('../middleware/auth');
const { adminOnly } = require('../middleware/admin');

// All admin routes require authentication and admin role
router.use(auth, adminOnly);

// Platform stats and config
router.get('/stats', adminController.getStats);
router.get('/config', adminController.getConfig);
router.put('/config', adminController.updateConfig);

// Token management
router.get('/tokens', adminController.getAllTokensAdmin);
router.put('/tokens/:address/status', adminController.updateTokenStatus);

// User management
router.get('/users', adminController.getAllUsers);
router.put('/users/:wallet/admin', adminController.setUserAdmin);

module.exports = router;
