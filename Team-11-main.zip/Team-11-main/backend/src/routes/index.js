const express = require('express');
const router = express.Router();

const tokenRoutes = require('./tokens');
const liquidityRoutes = require('./liquidity');
const userRoutes = require('./users');
const adminRoutes = require('./admin');
const uploadRoutes = require('./upload');

// Mount routes
router.use('/tokens', tokenRoutes);
router.use('/liquidity', liquidityRoutes);
router.use('/users', userRoutes);
router.use('/admin', adminRoutes);
router.use('/upload', uploadRoutes);

// API info
router.get('/', (req, res) => {
    res.json({
        name: 'Team 11 API',
        version: '1.0.0',
        endpoints: {
            tokens: '/api/tokens',
            liquidity: '/api/liquidity',
            users: '/api/users',
            admin: '/api/admin',
            upload: '/api/upload'
        }
    });
});

module.exports = router;
