const express = require('express');
const router = express.Router();
const liquidityController = require('../controllers/liquidityController');
const { auth } = require('../middleware/auth');
const { validateLiquidityLock } = require('../middleware/validation');

// Public routes
router.get('/all', liquidityController.getAllLocks);
router.get('/:tokenAddress', liquidityController.getLockByToken);

// Protected routes
router.post('/lock', auth, validateLiquidityLock, liquidityController.createLock);
router.post('/claim/:lockId', auth, liquidityController.claimLiquidity);

module.exports = router;
