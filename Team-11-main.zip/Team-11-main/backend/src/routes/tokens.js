const express = require('express');
const router = express.Router();
const tokenController = require('../controllers/tokenController');
const { auth } = require('../middleware/auth');
const { validateToken } = require('../middleware/validation');

// Public routes
router.get('/', tokenController.getAllTokens);
router.get('/:address', tokenController.getTokenByAddress);
router.get('/creator/:wallet', tokenController.getTokensByCreator);

// Protected routes
router.post('/', auth, validateToken, tokenController.createToken);
router.put('/:address/fees', auth, tokenController.updateCreatorFees);
router.put('/:address/status', auth, tokenController.updateTokenStatus);

module.exports = router;
