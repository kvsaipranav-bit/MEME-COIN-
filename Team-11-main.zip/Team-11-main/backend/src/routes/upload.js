const express = require('express');
const router = express.Router();
const uploadController = require('../controllers/uploadController');
const uploadService = require('../services/uploadService');
const { auth } = require('../middleware/auth');

// All upload routes require authentication
router.use(auth);

// Upload token logo
router.post('/logo', uploadService.single('logo'), uploadController.uploadLogo);

// Delete uploaded file
router.delete('/logo', uploadController.deleteLogo);

module.exports = router;
