const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { auth } = require('../middleware/auth');

// Public routes
router.post('/connect', userController.connectWallet);
router.post('/nonce', userController.getNonce);
router.post('/verify', userController.verifySignature);

// Protected routes
router.get('/profile', auth, userController.getProfile);
router.get('/:wallet', userController.getUserByWallet);
router.get('/:wallet/tokens', userController.getUserTokens);

module.exports = router;
