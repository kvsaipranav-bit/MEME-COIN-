/**
 * Admin Service
 * Business logic for admin operations
 */

const { supabase } = require('../config/database');
const { AppError } = require('../utils/errors');
const { logger } = require('../utils/logger');

const adminService = {
    /**
     * Get platform statistics
     * @returns {Promise<object>}
     */
    async getStats() {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        // Get token count
        const { count: tokenCount } = await supabase
            .from('tokens')
            .select('*', { count: 'exact', head: true });

        // Get active locks count and total SOL
        const { data: lockData, count: activeLocks } = await supabase
            .from('liquidity_locks')
            .select('amount_sol', { count: 'exact' })
            .eq('status', 'locked');

        const totalLockedSol = lockData?.reduce((sum, lock) => sum + parseFloat(lock.amount_sol || 0), 0) || 0;

        // Get user count
        const { count: userCount } = await supabase
            .from('users')
            .select('*', { count: 'exact', head: true });

        // Get claimed locks
        const { count: claimedLocks } = await supabase
            .from('liquidity_locks')
            .select('*', { count: 'exact', head: true })
            .eq('status', 'claimed');

        // Get tokens created in last 24 hours
        const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
        const { count: recentTokens } = await supabase
            .from('tokens')
            .select('*', { count: 'exact', head: true })
            .gte('created_at', yesterday);

        return {
            totalTokens: tokenCount || 0,
            activeLocks: activeLocks || 0,
            claimedLocks: claimedLocks || 0,
            totalLockedSol,
            totalUsers: userCount || 0,
            recentTokens: recentTokens || 0,
            timestamp: new Date().toISOString()
        };
    },

    /**
     * Get platform configuration
     * @returns {Promise<object>}
     */
    async getConfig() {
        if (!supabase) {
            return {
                platform_fee_percentage: parseFloat(process.env.PLATFORM_FEE_BPS || 50) / 100,
                min_lock_period_days: parseInt(process.env.MIN_LOCK_DAYS || 90),
                is_maintenance: false
            };
        }

        const { data, error } = await supabase
            .from('platform_config')
            .select('*')
            .single();

        if (error && error.code !== 'PGRST116') {
            throw error;
        }

        return data || {
            platform_fee_percentage: 0.5,
            min_lock_period_days: 90,
            is_maintenance: false
        };
    },

    /**
     * Update platform configuration
     * @param {object} config - New configuration values
     * @param {string} adminWallet - Admin wallet performing the update
     * @returns {Promise<object>}
     */
    async updateConfig(config, adminWallet) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        const { platform_fee_percentage, min_lock_period_days, is_maintenance } = config;

        // Validate fee percentage
        if (platform_fee_percentage !== undefined && (platform_fee_percentage < 0 || platform_fee_percentage > 10)) {
            throw new AppError('Platform fee must be between 0% and 10%', 400);
        }

        // Validate lock period
        if (min_lock_period_days !== undefined && min_lock_period_days < 1) {
            throw new AppError('Minimum lock period must be at least 1 day', 400);
        }

        const { data, error } = await supabase
            .from('platform_config')
            .upsert({
                id: '00000000-0000-0000-0000-000000000001', // Singleton
                platform_fee_percentage,
                min_lock_period_days,
                is_maintenance,
                updated_by: adminWallet,
                updated_at: new Date().toISOString()
            })
            .select()
            .single();

        if (error) throw error;

        logger.info(`Platform config updated by ${adminWallet}`);

        return data;
    },

    /**
     * Update token status (admin override)
     * @param {string} mintAddress - Token mint address
     * @param {boolean} isActive - New active status
     * @param {string} adminWallet - Admin wallet performing the update
     * @returns {Promise<object>}
     */
    async updateTokenStatus(mintAddress, isActive, adminWallet) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        const { data, error } = await supabase
            .from('tokens')
            .update({
                is_active: isActive,
                updated_at: new Date().toISOString()
            })
            .eq('mint_address', mintAddress)
            .select()
            .single();

        if (error) {
            if (error.code === 'PGRST116') {
                throw new AppError('Token not found', 404);
            }
            throw error;
        }

        logger.info(`Token ${mintAddress} status updated to ${isActive} by admin ${adminWallet}`);

        return data;
    },

    /**
     * Get all tokens with admin details
     * @param {object} options - Pagination options
     * @returns {Promise<object>}
     */
    async getAllTokens({ page = 1, limit = 50, includeInactive = true }) {
        if (!supabase) {
            return { tokens: [], total: 0, page, limit };
        }

        const offset = (page - 1) * limit;

        let query = supabase
            .from('tokens')
            .select('*, liquidity_locks(*), users!tokens_creator_wallet_fkey(wallet_address, is_admin)', { count: 'exact' });

        if (!includeInactive) {
            query = query.eq('is_active', true);
        }

        const { data, error, count } = await query
            .order('created_at', { ascending: false })
            .range(offset, offset + limit - 1);

        if (error) throw error;

        return {
            tokens: data || [],
            total: count || 0,
            page,
            limit,
            totalPages: Math.ceil((count || 0) / limit)
        };
    },

    /**
     * Get all users (admin view)
     * @param {object} options - Pagination options
     * @returns {Promise<object>}
     */
    async getAllUsers({ page = 1, limit = 50 }) {
        if (!supabase) {
            return { users: [], total: 0, page, limit };
        }

        const offset = (page - 1) * limit;

        const { data, error, count } = await supabase
            .from('users')
            .select('*', { count: 'exact' })
            .order('created_at', { ascending: false })
            .range(offset, offset + limit - 1);

        if (error) throw error;

        return {
            users: data || [],
            total: count || 0,
            page,
            limit,
            totalPages: Math.ceil((count || 0) / limit)
        };
    },

    /**
     * Set user admin status
     * @param {string} wallet - User wallet address
     * @param {boolean} isAdmin - Admin status
     * @param {string} adminWallet - Admin performing the action
     * @returns {Promise<object>}
     */
    async setUserAdmin(wallet, isAdmin, adminWallet) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        if (wallet === adminWallet) {
            throw new AppError('Cannot modify your own admin status', 400);
        }

        const { data, error } = await supabase
            .from('users')
            .update({ is_admin: isAdmin, updated_at: new Date().toISOString() })
            .eq('wallet_address', wallet)
            .select()
            .single();

        if (error) {
            if (error.code === 'PGRST116') {
                throw new AppError('User not found', 404);
            }
            throw error;
        }

        logger.info(`User ${wallet} admin status set to ${isAdmin} by ${adminWallet}`);

        return data;
    }
};

module.exports = adminService;
