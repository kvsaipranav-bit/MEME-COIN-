const { supabase } = require('../config/database');
const { AppError } = require('../utils/errors');
const constants = require('../config/constants');

const liquidityService = {
    // Get all locks with pagination
    async getAllLocks({ status, page = 1, limit = 20 }) {
        if (!supabase) {
            return { locks: [], total: 0, page, limit };
        }

        const offset = (page - 1) * limit;

        let query = supabase
            .from('liquidity_locks')
            .select('*, tokens(name, symbol, mint_address)', { count: 'exact' });

        if (status) {
            query = query.eq('status', status);
        }

        query = query
            .order('unlock_date', { ascending: true })
            .range(offset, offset + limit - 1);

        const { data, error, count } = await query;

        if (error) throw error;

        // Add computed fields
        const locks = (data || []).map(lock => ({
            ...lock,
            remaining_time: this.calculateRemainingTime(lock.unlock_date),
            is_unlockable: new Date(lock.unlock_date) <= new Date()
        }));

        return {
            locks,
            total: count || 0,
            page,
            limit,
            totalPages: Math.ceil((count || 0) / limit)
        };
    },

    // Get lock by token address
    async getLockByToken(tokenAddress) {
        if (!supabase) return null;

        // First get the token
        const { data: token } = await supabase
            .from('tokens')
            .select('id')
            .eq('mint_address', tokenAddress)
            .single();

        if (!token) return null;

        const { data, error } = await supabase
            .from('liquidity_locks')
            .select('*, tokens(name, symbol, mint_address)')
            .eq('token_id', token.id)
            .single();

        if (error && error.code !== 'PGRST116') throw error;

        if (data) {
            data.remaining_time = this.calculateRemainingTime(data.unlock_date);
            data.is_unlockable = new Date(data.unlock_date) <= new Date();
        }

        return data;
    },

    // Create new liquidity lock
    async createLock(lockData) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        // Get token
        const { data: token } = await supabase
            .from('tokens')
            .select('id, creator_wallet')
            .eq('mint_address', lockData.token_address)
            .single();

        if (!token) {
            throw new AppError('Token not found', 404);
        }

        if (token.creator_wallet !== lockData.creator_wallet) {
            throw new AppError('Only token creator can lock liquidity', 403);
        }

        // Check for existing lock
        const { data: existingLock } = await supabase
            .from('liquidity_locks')
            .select('id')
            .eq('token_id', token.id)
            .single();

        if (existingLock) {
            throw new AppError('Liquidity already locked for this token', 400);
        }

        // Validate lock duration
        if (lockData.lock_duration_days < constants.MIN_LOCK_DAYS) {
            throw new AppError(`Minimum lock period is ${constants.MIN_LOCK_DAYS} days`, 400);
        }

        const lockDate = new Date();
        const unlockDate = new Date(lockDate.getTime() + lockData.lock_duration_days * 24 * 60 * 60 * 1000);

        const { data, error } = await supabase
            .from('liquidity_locks')
            .insert({
                token_id: token.id,
                lock_address: lockData.lock_address,
                amount_sol: lockData.amount_sol,
                creator_wallet: lockData.creator_wallet,
                lock_date: lockDate.toISOString(),
                unlock_date: unlockDate.toISOString(),
                status: constants.LOCK_STATUS.LOCKED
            })
            .select()
            .single();

        if (error) throw error;

        return data;
    },

    // Claim unlocked liquidity
    async claimLiquidity(lockId, creatorWallet) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        const { data: lock, error: fetchError } = await supabase
            .from('liquidity_locks')
            .select('*')
            .eq('id', lockId)
            .single();

        if (fetchError || !lock) {
            throw new AppError('Lock not found', 404);
        }

        if (lock.creator_wallet !== creatorWallet) {
            throw new AppError('Only the lock creator can claim', 403);
        }

        if (lock.status === constants.LOCK_STATUS.CLAIMED) {
            throw new AppError('Liquidity already claimed', 400);
        }

        if (new Date(lock.unlock_date) > new Date()) {
            throw new AppError('Lock period has not expired', 400);
        }

        const { data, error } = await supabase
            .from('liquidity_locks')
            .update({
                status: constants.LOCK_STATUS.CLAIMED,
                claimed_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            })
            .eq('id', lockId)
            .select()
            .single();

        if (error) throw error;

        return data;
    },

    // Calculate remaining time
    calculateRemainingTime(unlockDate) {
        const now = new Date();
        const unlock = new Date(unlockDate);
        const diff = unlock - now;

        if (diff <= 0) {
            return { expired: true, days: 0, hours: 0, minutes: 0 };
        }

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

        return { expired: false, days, hours, minutes };
    }
};

module.exports = liquidityService;
