/**
 * Solana Blockchain Service
 * Service for verifying on-chain transactions and account data
 */

const { connection, getProgramId } = require('../config/solana');
const { PublicKey } = require('@solana/web3.js');
const { logger } = require('../utils/logger');

const solanaService = {
    /**
     * Verify if a transaction exists and is confirmed
     * @param {string} signature - Transaction signature
     * @returns {Promise<{confirmed: boolean, slot?: number, error?: string}>}
     */
    async verifyTransaction(signature) {
        try {
            const result = await connection.getSignatureStatus(signature);

            if (!result.value) {
                return { confirmed: false, error: 'Transaction not found' };
            }

            const status = result.value;

            if (status.err) {
                return { confirmed: false, error: 'Transaction failed' };
            }

            if (status.confirmationStatus === 'confirmed' || status.confirmationStatus === 'finalized') {
                return { confirmed: true, slot: status.slot };
            }

            return { confirmed: false, error: 'Transaction not confirmed yet' };
        } catch (error) {
            logger.error(`Error verifying transaction: ${error.message}`);
            return { confirmed: false, error: error.message };
        }
    },

    /**
     * Get transaction details
     * @param {string} signature - Transaction signature
     * @returns {Promise<object|null>}
     */
    async getTransaction(signature) {
        try {
            const tx = await connection.getTransaction(signature, {
                maxSupportedTransactionVersion: 0
            });
            return tx;
        } catch (error) {
            logger.error(`Error getting transaction: ${error.message}`);
            return null;
        }
    },

    /**
     * Verify if a token mint exists on-chain
     * @param {string} mintAddress - Token mint address
     * @returns {Promise<boolean>}
     */
    async verifyTokenMint(mintAddress) {
        try {
            const mintPubkey = new PublicKey(mintAddress);
            const accountInfo = await connection.getAccountInfo(mintPubkey);

            // If account exists and has data, it's likely a valid mint
            return accountInfo !== null && accountInfo.data.length > 0;
        } catch (error) {
            logger.error(`Error verifying token mint: ${error.message}`);
            return false;
        }
    },

    /**
     * Get account balance in SOL
     * @param {string} address - Wallet address
     * @returns {Promise<number>}
     */
    async getBalance(address) {
        try {
            const pubkey = new PublicKey(address);
            const balance = await connection.getBalance(pubkey);
            return balance / 1e9; // Convert lamports to SOL
        } catch (error) {
            logger.error(`Error getting balance: ${error.message}`);
            return 0;
        }
    },

    /**
     * Verify program account exists (PDA)
     * @param {string} address - PDA address
     * @returns {Promise<boolean>}
     */
    async verifyProgramAccount(address) {
        try {
            const pubkey = new PublicKey(address);
            const accountInfo = await connection.getAccountInfo(pubkey);

            if (!accountInfo) return false;

            const programId = getProgramId();
            if (programId) {
                const programPubkey = new PublicKey(programId);
                return accountInfo.owner.equals(programPubkey);
            }

            return true;
        } catch (error) {
            logger.error(`Error verifying program account: ${error.message}`);
            return false;
        }
    },

    /**
     * Get recent blockhash for transactions
     * @returns {Promise<{blockhash: string, lastValidBlockHeight: number}|null>}
     */
    async getRecentBlockhash() {
        try {
            const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash();
            return { blockhash, lastValidBlockHeight };
        } catch (error) {
            logger.error(`Error getting blockhash: ${error.message}`);
            return null;
        }
    },

    /**
     * Get network status
     * @returns {Promise<{slot: number, epoch: number}>}
     */
    async getNetworkStatus() {
        try {
            const slot = await connection.getSlot();
            const epochInfo = await connection.getEpochInfo();
            return {
                slot,
                epoch: epochInfo.epoch,
                transactionCount: await connection.getTransactionCount()
            };
        } catch (error) {
            logger.error(`Error getting network status: ${error.message}`);
            return { slot: 0, epoch: 0, transactionCount: 0 };
        }
    }
};

module.exports = solanaService;
