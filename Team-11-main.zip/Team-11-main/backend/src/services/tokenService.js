const { supabase } = require('../config/database');
const { AppError } = require('../utils/errors');
const constants = require('../config/constants');

const tokenService = {
    // Get all tokens with pagination
    async getAllTokens({ page = 1, limit = 20, search, sort = 'created_at', order = 'desc' }) {
        if (!supabase) {
            return { tokens: [], total: 0, page, limit };
        }

        const offset = (page - 1) * limit;

        let query = supabase
            .from('tokens')
            .select('*, liquidity_locks(id, amount_sol, unlock_date, status)', { count: 'exact' })
            .eq('is_active', true);

        // Search by name or symbol
        if (search) {
            query = query.or(`name.ilike.%${search}%,symbol.ilike.%${search}%`);
        }

        // Sorting
        const ascending = order.toLowerCase() === 'asc';
        query = query.order(sort, { ascending });

        // Pagination
        query = query.range(offset, offset + limit - 1);

        const { data, error, count } = await query;

        if (error) throw error;

        return {
            tokens: data || [],
            total: count || 0,
            page,
            limit,
            totalPages: Math.ceil((count || 0) / limit)
        };
    },

    // Get token by mint address
    async getTokenByAddress(mintAddress) {
        if (!supabase) return null;

        const { data, error } = await supabase
            .from('tokens')
            .select('*, liquidity_locks(*)')
            .eq('mint_address', mintAddress)
            .single();

        if (error && error.code !== 'PGRST116') throw error;

        return data;
    },

    // Get tokens by creator
    async getTokensByCreator(wallet) {
        if (!supabase) return [];

        const { data, error } = await supabase
            .from('tokens')
            .select('*, liquidity_locks(*)')
            .eq('creator_wallet', wallet)
            .order('created_at', { ascending: false });

        if (error) throw error;

        return data || [];
    },

    // Create new token
    async createToken(tokenData) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        // Validate
        if (!tokenData.name || tokenData.name.length > constants.MAX_TOKEN_NAME_LENGTH) {
            throw new AppError(`Token name must be 1-${constants.MAX_TOKEN_NAME_LENGTH} characters`, 400);
        }
        if (!tokenData.symbol || tokenData.symbol.length > constants.MAX_TOKEN_SYMBOL_LENGTH) {
            throw new AppError(`Token symbol must be 1-${constants.MAX_TOKEN_SYMBOL_LENGTH} characters`, 400);
        }
        if (tokenData.creator_fee_percentage > constants.MAX_CREATOR_FEE_BPS / 100) {
            throw new AppError('Creator fee cannot exceed 10%', 400);
        }

        const { data, error } = await supabase
            .from('tokens')
            .insert({
                mint_address: tokenData.mint_address,
                name: tokenData.name,
                symbol: tokenData.symbol.toUpperCase(),
                description: tokenData.description || '',
                logo_url: tokenData.logo_url || null,
                decimals: tokenData.decimals || 9,
                initial_supply: tokenData.initial_supply,
                creator_wallet: tokenData.creator_wallet,
                creator_fee_percentage: tokenData.creator_fee_percentage || 0,
                is_active: true
            })
            .select()
            .single();

        if (error) throw error;

        return data;
    },

    // Update creator fees
    async updateCreatorFees(mintAddress, creatorWallet, feePercentage) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        if (feePercentage > constants.MAX_CREATOR_FEE_BPS / 100) {
            throw new AppError('Creator fee cannot exceed 10%', 400);
        }

        // Verify ownership
        const token = await this.getTokenByAddress(mintAddress);
        if (!token) {
            throw new AppError('Token not found', 404);
        }
        if (token.creator_wallet !== creatorWallet) {
            throw new AppError('Only token creator can update fees', 403);
        }

        const { data, error } = await supabase
            .from('tokens')
            .update({
                creator_fee_percentage: feePercentage,
                updated_at: new Date().toISOString()
            })
            .eq('mint_address', mintAddress)
            .select()
            .single();

        if (error) throw error;

        return data;
    },

    // Update token status
    async updateTokenStatus(mintAddress, creatorWallet, isActive) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        // Verify ownership
        const token = await this.getTokenByAddress(mintAddress);
        if (!token) {
            throw new AppError('Token not found', 404);
        }
        if (token.creator_wallet !== creatorWallet) {
            throw new AppError('Only token creator can update status', 403);
        }

        const { data, error } = await supabase
            .from('tokens')
            .update({
                is_active: isActive,
                updated_at: new Date().toISOString()
            })
            .eq('mint_address', mintAddress)
            .select()
            .single();

        if (error) throw error;

        return data;
    }
};

module.exports = tokenService;
