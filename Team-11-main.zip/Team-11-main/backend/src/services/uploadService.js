const { supabase } = require('../config/database');
const { AppError } = require('../utils/errors');
const { logger } = require('../utils/logger');
const constants = require('../config/constants');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// Configure multer for memory storage
const storage = multer.memoryStorage();

// File filter for images
const fileFilter = (req, file, cb) => {
    const allowedTypes = constants.ALLOWED_LOGO_TYPES || ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new AppError(`Invalid file type. Allowed: ${allowedTypes.join(', ')}`, 400), false);
    }
};

// Multer upload configuration
const upload = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: constants.MAX_LOGO_SIZE || 5 * 1024 * 1024 // 5MB default
    }
});

const uploadService = {
    // Multer middleware for single file upload
    single: (fieldName) => upload.single(fieldName),

    // Upload file to Supabase Storage
    async uploadToStorage(file, bucket = 'logos') {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        if (!file) {
            throw new AppError('No file provided', 400);
        }

        // Generate unique filename
        const ext = path.extname(file.originalname);
        const filename = `${uuidv4()}${ext}`;
        const filePath = `tokens/${filename}`;

        // Upload to Supabase Storage
        const { data, error } = await supabase.storage
            .from(bucket)
            .upload(filePath, file.buffer, {
                contentType: file.mimetype,
                upsert: false
            });

        if (error) {
            logger.error(`File upload failed: ${error.message}`);
            throw new AppError('Failed to upload file', 500);
        }

        // Get public URL
        const { data: urlData } = supabase.storage
            .from(bucket)
            .getPublicUrl(filePath);

        logger.info(`File uploaded: ${filePath}`);

        return {
            path: filePath,
            url: urlData.publicUrl,
            originalName: file.originalname,
            size: file.size,
            mimeType: file.mimetype
        };
    },

    // Delete file from Supabase Storage
    async deleteFromStorage(filePath, bucket = 'logos') {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        const { error } = await supabase.storage
            .from(bucket)
            .remove([filePath]);

        if (error) {
            logger.error(`File deletion failed: ${error.message}`);
            throw new AppError('Failed to delete file', 500);
        }

        logger.info(`File deleted: ${filePath}`);
        return true;
    },

    // Validate image dimensions (optional)
    async validateImage(file) {
        // Basic validation - file exists and is within size limits
        if (!file) {
            throw new AppError('No file provided', 400);
        }

        if (file.size > (constants.MAX_LOGO_SIZE || 5 * 1024 * 1024)) {
            throw new AppError('File too large', 400);
        }

        return true;
    }
};

module.exports = uploadService;
