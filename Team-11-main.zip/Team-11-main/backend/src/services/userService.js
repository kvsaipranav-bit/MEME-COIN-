const { supabase } = require('../config/database');
const { AppError } = require('../utils/errors');

const userService = {
    // Get user by wallet address
    async getUserByWallet(wallet) {
        if (!supabase) return null;

        const { data, error } = await supabase
            .from('users')
            .select('*')
            .eq('wallet_address', wallet)
            .single();

        if (error && error.code !== 'PGRST116') throw error;

        return data;
    },

    // Create new user
    async createUser(wallet, isAdmin = false) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        const { data, error } = await supabase
            .from('users')
            .insert({
                wallet_address: wallet,
                is_admin: isAdmin
            })
            .select()
            .single();

        if (error) {
            if (error.code === '23505') {
                // Duplicate key, user already exists
                return this.getUserByWallet(wallet);
            }
            throw error;
        }

        return data;
    },

    // Update user
    async updateUser(wallet, updates) {
        if (!supabase) {
            throw new AppError('Database not configured', 500);
        }

        const { data, error } = await supabase
            .from('users')
            .update({
                ...updates,
                updated_at: new Date().toISOString()
            })
            .eq('wallet_address', wallet)
            .select()
            .single();

        if (error) throw error;

        return data;
    },

    // Check if user is admin
    async isAdmin(wallet) {
        const user = await this.getUserByWallet(wallet);
        return user?.is_admin || false;
    }
};

module.exports = userService;
