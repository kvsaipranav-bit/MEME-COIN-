/**
 * Professional Console Banner & Startup Display
 * Beautiful ASCII art and formatted output for Team-11 Backend
 */

const { getProgramId, network, rpcUrl } = require('../config/solana');

// ====== COLORS ======
const colors = {
    reset: '\x1b[0m',
    bold: '\x1b[1m',
    dim: '\x1b[2m',
    underscore: '\x1b[4m',

    // Foreground
    black: '\x1b[30m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',

    // Bright
    brightBlack: '\x1b[90m',
    brightRed: '\x1b[91m',
    brightGreen: '\x1b[92m',
    brightYellow: '\x1b[93m',
    brightBlue: '\x1b[94m',
    brightMagenta: '\x1b[95m',
    brightCyan: '\x1b[96m',
    brightWhite: '\x1b[97m',

    // Background
    bgBlack: '\x1b[40m',
    bgRed: '\x1b[41m',
    bgGreen: '\x1b[42m',
    bgYellow: '\x1b[43m',
    bgBlue: '\x1b[44m',
    bgMagenta: '\x1b[45m',
    bgCyan: '\x1b[46m',
    bgWhite: '\x1b[47m',
};

// ====== ASCII ART BANNERS ======
const banners = {
    main: `
${colors.brightCyan}╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║   ${colors.brightMagenta}████████╗███████╗ █████╗ ███╗   ███╗      ██╗ ██╗${colors.brightCyan}                           ║
║   ${colors.brightMagenta}╚══██╔══╝██╔════╝██╔══██╗████╗ ████║     ███║███║${colors.brightCyan}                           ║
║   ${colors.brightMagenta}   ██║   █████╗  ███████║██╔████╔██║     ╚██║╚██║${colors.brightCyan}                           ║
║   ${colors.brightMagenta}   ██║   ██╔══╝  ██╔══██║██║╚██╔╝██║      ██║ ██║${colors.brightCyan}                           ║
║   ${colors.brightMagenta}   ██║   ███████╗██║  ██║██║ ╚═╝ ██║      ██║ ██║${colors.brightCyan}                           ║
║   ${colors.brightMagenta}   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝      ╚═╝ ╚═╝${colors.brightCyan}                           ║
║                                                                              ║
║   ${colors.brightYellow}⚡ SOLANA MEME COIN PLATFORM ⚡${colors.brightCyan}                                          ║
║   ${colors.white}Create • Lock • Trade${colors.brightCyan}                                                     ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝${colors.reset}
`,

    mini: `
${colors.brightCyan}┌─────────────────────────────────────────┐
│  ${colors.brightMagenta}TEAM 11${colors.brightCyan} │ ${colors.brightYellow}Solana Meme Coin Platform${colors.brightCyan}   │
└─────────────────────────────────────────┘${colors.reset}
`
};

// ====== UTILITY FUNCTIONS ======
const line = (char = '─', length = 78) => colors.brightBlack + char.repeat(length) + colors.reset;
const box = (text, width = 76) => {
    const padding = Math.max(0, width - text.length);
    return `${colors.brightBlack}│${colors.reset} ${text}${' '.repeat(padding)} ${colors.brightBlack}│${colors.reset}`;
};

const statusIcon = (status) => {
    const icons = {
        success: `${colors.brightGreen}✓${colors.reset}`,
        error: `${colors.brightRed}✗${colors.reset}`,
        warning: `${colors.brightYellow}⚠${colors.reset}`,
        info: `${colors.brightCyan}ℹ${colors.reset}`,
        loading: `${colors.brightBlue}◌${colors.reset}`,
        rocket: `${colors.brightMagenta}🚀${colors.reset}`,
        database: `${colors.brightBlue}🗄${colors.reset}`,
        network: `${colors.brightCyan}🌐${colors.reset}`,
        lock: `${colors.brightYellow}🔒${colors.reset}`,
        key: `${colors.brightGreen}🔑${colors.reset}`,
        coin: `${colors.brightYellow}🪙${colors.reset}`,
        server: `${colors.brightMagenta}⚡${colors.reset}`,
    };
    return icons[status] || icons.info;
};

// ====== STARTUP DISPLAY ======
const displayStartup = (config) => {
    const {
        port,
        environment,
        network: solanaNetwork,
        programId,
        version = '1.0.0',
    } = config;

    console.clear();
    console.log(banners.main);

    // Server Info Section
    console.log(`${colors.brightBlack}┌${'─'.repeat(78)}┐${colors.reset}`);
    console.log(box(`${colors.bold}${colors.white}SERVER INFORMATION${colors.reset}`));
    console.log(`${colors.brightBlack}├${'─'.repeat(78)}┤${colors.reset}`);
    console.log(box(`${statusIcon('server')} Status:         ${colors.brightGreen}ONLINE${colors.reset}`));
    console.log(box(`${statusIcon('rocket')} Port:           ${colors.brightCyan}${port}${colors.reset}`));
    console.log(box(`${statusIcon('info')} Environment:    ${environment === 'production' ? colors.brightRed : colors.brightYellow}${environment.toUpperCase()}${colors.reset}`));
    console.log(box(`${statusIcon('info')} Version:        ${colors.white}v${version}${colors.reset}`));
    console.log(`${colors.brightBlack}└${'─'.repeat(78)}┘${colors.reset}`);

    console.log('');

    // Solana Info Section
    console.log(`${colors.brightBlack}┌${'─'.repeat(78)}┐${colors.reset}`);
    console.log(box(`${colors.bold}${colors.white}SOLANA BLOCKCHAIN${colors.reset}`));
    console.log(`${colors.brightBlack}├${'─'.repeat(78)}┤${colors.reset}`);
    console.log(box(`${statusIcon('network')} Network:        ${colors.brightMagenta}${solanaNetwork.toUpperCase()}${colors.reset}`));
    console.log(box(`${statusIcon('key')} Program ID:     ${colors.brightCyan}${programId ? programId.substring(0, 20) + '...' : 'Not Set'}${colors.reset}`));
    console.log(box(`${statusIcon('lock')} RPC Endpoint:   ${colors.white}${rpcUrl.substring(0, 40)}...${colors.reset}`));
    console.log(`${colors.brightBlack}└${'─'.repeat(78)}┘${colors.reset}`);

    console.log('');

    // Endpoints Section
    console.log(`${colors.brightBlack}┌${'─'.repeat(78)}┐${colors.reset}`);
    console.log(box(`${colors.bold}${colors.white}API ENDPOINTS${colors.reset}`));
    console.log(`${colors.brightBlack}├${'─'.repeat(78)}┤${colors.reset}`);
    console.log(box(`${statusIcon('success')} Health:         ${colors.brightCyan}http://localhost:${port}/health${colors.reset}`));
    console.log(box(`${statusIcon('success')} API Base:       ${colors.brightCyan}http://localhost:${port}/api${colors.reset}`));
    console.log(box(`${statusIcon('coin')} Tokens:         ${colors.brightCyan}http://localhost:${port}/api/tokens${colors.reset}`));
    console.log(box(`${statusIcon('lock')} Liquidity:      ${colors.brightCyan}http://localhost:${port}/api/liquidity${colors.reset}`));
    console.log(box(`${statusIcon('database')} Admin:          ${colors.brightCyan}http://localhost:${port}/api/admin${colors.reset}`));
    console.log(`${colors.brightBlack}└${'─'.repeat(78)}┘${colors.reset}`);

    console.log('');

    // Ready Message
    console.log(`${colors.brightGreen}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}`);
    console.log(`${colors.brightGreen}  ✨ Server is ready! Waiting for connections...${colors.reset}`);
    console.log(`${colors.brightGreen}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}`);
    console.log('');
};

// ====== SERVICE STATUS DISPLAY ======
const displayServiceStatus = (services) => {
    console.log(`${colors.brightBlack}┌${'─'.repeat(78)}┐${colors.reset}`);
    console.log(box(`${colors.bold}${colors.white}SERVICE STATUS${colors.reset}`));
    console.log(`${colors.brightBlack}├${'─'.repeat(78)}┤${colors.reset}`);

    for (const [name, status] of Object.entries(services)) {
        const icon = status === 'up' ? statusIcon('success') :
            status === 'degraded' ? statusIcon('warning') : statusIcon('error');
        const statusColor = status === 'up' ? colors.brightGreen :
            status === 'degraded' ? colors.brightYellow : colors.brightRed;
        console.log(box(`${icon} ${name.padEnd(15)} ${statusColor}${status.toUpperCase()}${colors.reset}`));
    }

    console.log(`${colors.brightBlack}└${'─'.repeat(78)}┘${colors.reset}`);
};

// ====== REQUEST LOGGER ======
const logRequest = (method, path, statusCode, duration) => {
    const methodColors = {
        GET: colors.brightGreen,
        POST: colors.brightYellow,
        PUT: colors.brightBlue,
        DELETE: colors.brightRed,
        PATCH: colors.brightMagenta,
    };

    const statusColors = {
        2: colors.brightGreen,  // 2xx
        3: colors.brightCyan,   // 3xx
        4: colors.brightYellow, // 4xx
        5: colors.brightRed,    // 5xx
    };

    const methodColor = methodColors[method] || colors.white;
    const statusColor = statusColors[Math.floor(statusCode / 100)] || colors.white;

    const timestamp = new Date().toISOString().split('T')[1].split('.')[0];

    console.log(
        `${colors.brightBlack}[${timestamp}]${colors.reset} ` +
        `${methodColor}${method.padEnd(7)}${colors.reset} ` +
        `${colors.white}${path.padEnd(40)}${colors.reset} ` +
        `${statusColor}${statusCode}${colors.reset} ` +
        `${colors.brightBlack}${duration}ms${colors.reset}`
    );
};

// ====== SHUTDOWN MESSAGE ======
const displayShutdown = () => {
    console.log('');
    console.log(`${colors.brightYellow}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}`);
    console.log(`${colors.brightYellow}  👋 Server shutting down gracefully...${colors.reset}`);
    console.log(`${colors.brightYellow}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${colors.reset}`);
    console.log('');
};

module.exports = {
    colors,
    banners,
    displayStartup,
    displayServiceStatus,
    displayShutdown,
    logRequest,
    statusIcon,
    line,
    box
};
