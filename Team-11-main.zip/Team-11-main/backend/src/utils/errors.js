class AppError extends Error {
    constructor(message, statusCode = 500) {
        super(message);
        this.statusCode = statusCode;
        this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
        this.isOperational = true;

        Error.captureStackTrace(this, this.constructor);
    }
}

const errorHandler = (err, req, res, next) => {
    let { statusCode = 500, message } = err;

    // Supabase errors
    if (err.code === 'PGRST116') {
        statusCode = 404;
        message = 'Resource not found';
    } else if (err.code === '23505') {
        statusCode = 409;
        message = 'Resource already exists';
    } else if (err.code === '23503') {
        statusCode = 400;
        message = 'Invalid reference';
    }

    // JWT errors
    if (err.name === 'JsonWebTokenError') {
        statusCode = 401;
        message = 'Invalid token';
    } else if (err.name === 'TokenExpiredError') {
        statusCode = 401;
        message = 'Token expired';
    }

    // Log error in development
    if (process.env.NODE_ENV === 'development') {
        console.error('Error:', err);
    }

    res.status(statusCode).json({
        status: 'error',
        statusCode,
        message,
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    });
};

const notFoundHandler = (req, res, next) => {
    res.status(404).json({
        status: 'error',
        statusCode: 404,
        message: `Cannot ${req.method} ${req.originalUrl}`
    });
};

module.exports = { AppError, errorHandler, notFoundHandler };
