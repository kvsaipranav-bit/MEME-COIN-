/**
 * Helper Utility Functions
 * Common utility functions used throughout the application
 */

const { VALIDATION, LOCK_DEFAULTS } = require('../config/constants');

/**
 * Format error for response
 * @param {Error|string} error - Error object or message
 * @returns {object} Formatted error object
 */
function formatError(error) {
    const message = error instanceof Error ? error.message : String(error);
    const result = { message };

    // Include stack trace in development
    if (process.env.NODE_ENV === 'development' && error instanceof Error) {
        result.stack = error.stack;
    }

    return result;
}

/**
 * Check if a string is a valid Solana wallet address
 * @param {string} address - Wallet address to validate
 * @returns {boolean} True if valid
 */
function isValidWalletAddress(address) {
    if (!address || typeof address !== 'string') {
        return false;
    }
    return VALIDATION.WALLET_ADDRESS_REGEX.test(address);
}

/**
 * Truncate a wallet address for display
 * @param {string} address - Full wallet address
 * @param {number} startLength - Characters to show at start
 * @param {number} endLength - Characters to show at end
 * @returns {string} Truncated address
 */
function truncateAddress(address, startLength = 4, endLength = 4) {
    if (!address || typeof address !== 'string') {
        return '';
    }
    if (address.length <= startLength + endLength) {
        return address;
    }
    return `${address.slice(0, startLength)}...${address.slice(-endLength)}`;
}

/**
 * Calculate unlock date from days
 * @param {number} days - Number of days to lock
 * @returns {Date} Unlock date
 */
function calculateUnlockDate(days = LOCK_DEFAULTS.DEFAULT_LOCK_DAYS) {
    const now = new Date();
    return new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
}

/**
 * Format token amount with commas
 * @param {number} amount - Token amount
 * @param {number} decimals - Decimal places
 * @returns {string} Formatted amount
 */
function formatTokenAmount(amount, decimals = 0) {
    if (amount === 0) return '0';
    return amount.toLocaleString('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
    });
}

/**
 * Convert lamports to SOL
 * @param {number} lamports - Amount in lamports
 * @returns {number} Amount in SOL
 */
function lamportsToSol(lamports) {
    return lamports / 1e9;
}

/**
 * Convert SOL to lamports
 * @param {number} sol - Amount in SOL
 * @returns {number} Amount in lamports
 */
function solToLamports(sol) {
    return Math.floor(sol * 1e9);
}

/**
 * Sleep for specified milliseconds
 * @param {number} ms - Milliseconds to sleep
 * @returns {Promise<void>}
 */
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Generate random ID
 * @param {number} length - ID length
 * @returns {string} Random ID
 */
function generateId(length = 16) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

module.exports = {
    formatError,
    isValidWalletAddress,
    truncateAddress,
    calculateUnlockDate,
    formatTokenAmount,
    lamportsToSol,
    solToLamports,
    sleep,
    generateId,
};
