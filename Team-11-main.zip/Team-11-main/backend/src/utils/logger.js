const isDev = process.env.NODE_ENV === 'development';

const levels = {
    error: 0,
    warn: 1,
    info: 2,
    debug: 3
};

const colors = {
    error: '\x1b[31m', // Red
    warn: '\x1b[33m',  // Yellow
    info: '\x1b[36m',  // Cyan
    debug: '\x1b[37m', // White
    reset: '\x1b[0m'
};

const formatMessage = (level, message) => {
    const timestamp = new Date().toISOString();
    const color = colors[level] || colors.reset;
    const prefix = `[${timestamp}] [${level.toUpperCase()}]`;

    if (isDev) {
        return `${color}${prefix}${colors.reset} ${message}`;
    }

    return JSON.stringify({ timestamp, level, message });
};

const logger = {
    error: (message, ...args) => {
        console.error(formatMessage('error', message), ...args);
    },

    warn: (message, ...args) => {
        console.warn(formatMessage('warn', message), ...args);
    },

    info: (message, ...args) => {
        console.log(formatMessage('info', message), ...args);
    },

    debug: (message, ...args) => {
        if (isDev) {
            console.log(formatMessage('debug', message), ...args);
        }
    }
};

module.exports = { logger };
