/**
 * Admin Routes Tests
 * Tests for admin API endpoints
 */

const request = require('supertest');
const app = require('../../src/app');

describe('Admin API Routes', () => {
    describe('GET /api/admin/stats', () => {
        it('should require authentication', async () => {
            const response = await request(app).get('/api/admin/stats');
            expect(response.status).toBe(401);
        });

        it('should require admin role', async () => {
            // Even with a token, non-admin should be rejected
            const response = await request(app)
                .get('/api/admin/stats')
                .set('Authorization', 'Bearer non-admin-token');

            expect(response.status).toBe(401);
        });
    });

    describe('GET /api/admin/config', () => {
        it('should require authentication', async () => {
            const response = await request(app).get('/api/admin/config');
            expect(response.status).toBe(401);
        });
    });

    describe('PUT /api/admin/config', () => {
        it('should require authentication', async () => {
            const response = await request(app)
                .put('/api/admin/config')
                .send({ platform_fee_percentage: 1.0 });

            expect(response.status).toBe(401);
        });

        it('should reject non-admin users', async () => {
            const response = await request(app)
                .put('/api/admin/config')
                .set('Authorization', 'Bearer fake-token')
                .send({ platform_fee_percentage: 1.0 });

            expect(response.status).toBe(401);
        });
    });

    describe('PUT /api/admin/tokens/:address/status', () => {
        it('should require authentication', async () => {
            const response = await request(app)
                .put('/api/admin/tokens/test-address/status')
                .send({ is_active: false });

            expect(response.status).toBe(401);
        });
    });

    describe('GET /api/admin/tokens', () => {
        it('should require authentication', async () => {
            const response = await request(app).get('/api/admin/tokens');
            expect(response.status).toBe(401);
        });
    });
});

describe('Admin Route Security', () => {
    const adminRoutes = [
        { method: 'get', path: '/api/admin/stats' },
        { method: 'get', path: '/api/admin/config' },
        { method: 'put', path: '/api/admin/config' },
        { method: 'get', path: '/api/admin/tokens' },
        { method: 'put', path: '/api/admin/tokens/test/status' }
    ];

    adminRoutes.forEach(({ method, path }) => {
        it(`should require auth for ${method.toUpperCase()} ${path}`, async () => {
            const response = await request(app)[method](path);
            expect(response.status).toBe(401);
        });
    });
});
