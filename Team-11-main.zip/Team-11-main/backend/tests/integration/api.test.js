/**
 * API Health & Routes Tests
 * Tests for Express app and API endpoints
 */

const request = require('supertest');
const app = require('../../src/app');

describe('API Health Check', () => {
    describe('GET /health', () => {
        it('should return 200 OK', async () => {
            const response = await request(app).get('/health');
            expect(response.status).toBe(200);
        });

        it('should return health status object', async () => {
            const response = await request(app).get('/health');
            expect(response.body).toHaveProperty('status');
            expect(['ok', 'healthy']).toContain(response.body.status);
        });

        it('should include timestamp', async () => {
            const response = await request(app).get('/health');
            expect(response.body).toHaveProperty('timestamp');
        });

        it('should include network info', async () => {
            const response = await request(app).get('/health');
            expect(response.body).toHaveProperty('network');
        });
    });
});

describe('API Base Routes', () => {
    describe('GET /api', () => {
        it('should return API info', async () => {
            const response = await request(app).get('/api');
            expect(response.status).toBe(200);
        });

        it('should include version', async () => {
            const response = await request(app).get('/api');
            expect(response.body).toHaveProperty('version');
        });

        it('should include endpoints info', async () => {
            const response = await request(app).get('/api');
            expect(response.body).toHaveProperty('endpoints');
        });
    });
});

describe('Error Handling', () => {
    describe('404 Not Found', () => {
        it('should return 404 for unknown routes', async () => {
            const response = await request(app).get('/unknown-route-xyz');
            expect(response.status).toBe(404);
        });

        it('should return error message for unknown routes', async () => {
            const response = await request(app).get('/unknown-route-xyz');
            expect(response.body).toHaveProperty('message');
        });
    });
});

describe('CORS & Security Headers', () => {
    it('should allow CORS from localhost', async () => {
        const response = await request(app)
            .get('/health')
            .set('Origin', 'http://localhost:3000');

        // Should not be blocked
        expect(response.status).toBe(200);
    });

    it('should have security headers', async () => {
        const response = await request(app).get('/health');

        // Check for common security headers (helmet adds these)
        expect(response.headers).toHaveProperty('x-content-type-options');
    });
});
