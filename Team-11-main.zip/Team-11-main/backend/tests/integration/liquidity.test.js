/**
 * Liquidity Routes Tests
 * Tests for liquidity-related API endpoints
 */

const request = require('supertest');
const app = require('../../src/app');

describe('Liquidity API Routes', () => {
    describe('GET /api/liquidity/all', () => {
        it('should return 200 OK', async () => {
            const response = await request(app).get('/api/liquidity/all');
            expect(response.status).toBe(200);
        });

        it('should return response object', async () => {
            const response = await request(app).get('/api/liquidity/all');
            expect(response.body).toBeDefined();
        });

        it('should support query parameters', async () => {
            const response = await request(app).get('/api/liquidity/all?page=1&limit=10');
            expect(response.status).toBe(200);
        });

        it('should support status filter', async () => {
            const response = await request(app).get('/api/liquidity/all?status=locked');
            expect(response.status).toBe(200);
        });
    });

    describe('GET /api/liquidity/:tokenAddress', () => {
        it('should handle non-existent token address', async () => {
            const response = await request(app).get('/api/liquidity/non-existent-address');
            // Should return 404 or error
            expect([200, 404, 500]).toContain(response.status);
        });
    });

    describe('POST /api/liquidity/lock', () => {
        it('should require authentication', async () => {
            const response = await request(app)
                .post('/api/liquidity/lock')
                .send({
                    token_address: 'test-token',
                    amount_sol: 1.0,
                    lock_duration_days: 90
                });

            // Should return 401 without auth
            expect(response.status).toBe(401);
        });

        it('should reject empty request body', async () => {
            const response = await request(app)
                .post('/api/liquidity/lock')
                .set('Authorization', 'Bearer invalid-token')
                .send({});

            // Should return 400 or 401
            expect([400, 401]).toContain(response.status);
        });
    });

    describe('POST /api/liquidity/claim/:lockId', () => {
        it('should require authentication', async () => {
            const response = await request(app)
                .post('/api/liquidity/claim/test-lock-id');

            expect(response.status).toBe(401);
        });
    });
});

describe('Liquidity Route Security', () => {
    describe('Protected Routes', () => {
        it('should require auth for POST /api/liquidity/lock', async () => {
            const response = await request(app).post('/api/liquidity/lock').send({});
            expect(response.status).toBe(401);
        });

        it('should require auth for POST /api/liquidity/claim/:lockId', async () => {
            const response = await request(app).post('/api/liquidity/claim/123');
            expect(response.status).toBe(401);
        });
    });

    describe('Public Routes', () => {
        it('should allow GET /api/liquidity/all without auth', async () => {
            const response = await request(app).get('/api/liquidity/all');
            expect(response.status).toBe(200);
        });

        it('should allow GET /api/liquidity/:tokenAddress without auth', async () => {
            const response = await request(app).get('/api/liquidity/some-address');
            // May be 200 or 404, but not 401
            expect([200, 404, 500]).toContain(response.status);
        });
    });
});
