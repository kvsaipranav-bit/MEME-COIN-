/**
 * Token Routes Tests
 * Tests for token-related API endpoints
 */

const request = require('supertest');
const app = require('../../src/app');

describe('Token API Routes', () => {
    describe('GET /api/tokens', () => {
        it('should return 200 OK', async () => {
            const response = await request(app).get('/api/tokens');
            expect(response.status).toBe(200);
        });

        it('should return response object', async () => {
            const response = await request(app).get('/api/tokens');
            expect(response.body).toBeDefined();
        });

        it('should support query parameters', async () => {
            const response = await request(app).get('/api/tokens?page=1&limit=10');
            expect(response.status).toBe(200);
        });
    });

    describe('GET /api/tokens/:address', () => {
        it('should handle non-existent token address', async () => {
            const response = await request(app).get('/api/tokens/non-existent-address');
            // Should return 404 or 200 with null data depending on implementation
            expect([200, 404]).toContain(response.status);
        });
    });

    describe('GET /api/tokens/creator/:wallet', () => {
        it('should return tokens by creator wallet', async () => {
            const response = await request(app).get('/api/tokens/creator/7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU');
            expect([200, 404]).toContain(response.status);
        });
    });

    describe('POST /api/tokens', () => {
        it('should require authentication', async () => {
            const response = await request(app)
                .post('/api/tokens')
                .send({
                    name: 'Test Token',
                    symbol: 'TEST',
                });

            // Should return 401 without auth
            expect(response.status).toBe(401);
        });

        it('should reject empty request body', async () => {
            const response = await request(app)
                .post('/api/tokens')
                .set('Authorization', 'Bearer test-token')
                .send({});

            // Should return 400 or 401
            expect([400, 401]).toContain(response.status);
        });
    });
});

describe('Token Route Security', () => {
    describe('Protected Routes', () => {
        it('should require auth for POST /api/tokens', async () => {
            const response = await request(app).post('/api/tokens').send({});
            expect(response.status).toBe(401);
        });

        it('should require auth for PUT /api/tokens/:address/fees', async () => {
            const response = await request(app).put('/api/tokens/test-address/fees').send({});
            expect(response.status).toBe(401);
        });

        it('should require auth for PUT /api/tokens/:address/status', async () => {
            const response = await request(app).put('/api/tokens/test-address/status').send({});
            expect(response.status).toBe(401);
        });
    });

    describe('Public Routes', () => {
        it('should allow GET /api/tokens without auth', async () => {
            const response = await request(app).get('/api/tokens');
            expect(response.status).toBe(200);
        });

        it('should allow GET /api/tokens/:address without auth', async () => {
            const response = await request(app).get('/api/tokens/some-address');
            // May be 200 or 404, but not 401
            expect([200, 404]).toContain(response.status);
        });
    });
});
