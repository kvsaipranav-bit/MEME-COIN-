/**
 * Upload Routes Tests
 * Tests for file upload API endpoints
 */

const request = require('supertest');
const path = require('path');
const app = require('../../src/app');

describe('Upload API Routes', () => {
    describe('POST /api/upload/logo', () => {
        it('should require authentication', async () => {
            const response = await request(app)
                .post('/api/upload/logo');

            expect(response.status).toBe(401);
        });

        it('should require file to be uploaded', async () => {
            const response = await request(app)
                .post('/api/upload/logo')
                .set('Authorization', 'Bearer fake-token');

            // Will fail auth first
            expect(response.status).toBe(401);
        });
    });

    describe('DELETE /api/upload/logo', () => {
        it('should require authentication', async () => {
            const response = await request(app)
                .delete('/api/upload/logo')
                .send({ path: 'test/logo.png' });

            expect(response.status).toBe(401);
        });

        it('should require file path', async () => {
            const response = await request(app)
                .delete('/api/upload/logo')
                .set('Authorization', 'Bearer valid-token')
                .send({});

            // Will fail auth first, or 400 if auth passes
            expect([400, 401]).toContain(response.status);
        });
    });
});

describe('Upload Route Security', () => {
    it('should require auth for POST /api/upload/logo', async () => {
        const response = await request(app).post('/api/upload/logo');
        expect(response.status).toBe(401);
    });

    it('should require auth for DELETE /api/upload/logo', async () => {
        const response = await request(app).delete('/api/upload/logo');
        expect(response.status).toBe(401);
    });
});
