/**
 * User Routes Tests
 * Tests for user and authentication API endpoints
 */

const request = require('supertest');
const app = require('../../src/app');

describe('User API Routes', () => {
    describe('POST /api/users/connect', () => {
        it('should return 400 for missing wallet', async () => {
            const response = await request(app)
                .post('/api/users/connect')
                .send({});

            expect(response.status).toBe(400);
        });

        it('should accept valid wallet address', async () => {
            const response = await request(app)
                .post('/api/users/connect')
                .send({ wallet: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU' });

            // May succeed or fail depending on database
            expect([200, 201, 500]).toContain(response.status);
        });
    });

    describe('POST /api/users/nonce', () => {
        it('should return 400 for missing wallet', async () => {
            const response = await request(app)
                .post('/api/users/nonce')
                .send({});

            expect(response.status).toBe(400);
        });

        it('should return nonce for valid wallet', async () => {
            const response = await request(app)
                .post('/api/users/nonce')
                .send({ wallet: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU' });

            expect(response.status).toBe(200);
            expect(response.body).toHaveProperty('nonce');
            expect(response.body).toHaveProperty('message');
        });
    });

    describe('POST /api/users/verify', () => {
        it('should return 400 for missing wallet or signature', async () => {
            const response = await request(app)
                .post('/api/users/verify')
                .send({});

            expect(response.status).toBe(400);
        });

        it('should return 401 for invalid signature', async () => {
            const response = await request(app)
                .post('/api/users/verify')
                .send({
                    wallet: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
                    signature: 'invalid_signature'
                });

            expect([400, 401]).toContain(response.status);
        });
    });

    describe('GET /api/users/profile', () => {
        it('should require authentication', async () => {
            const response = await request(app).get('/api/users/profile');

            expect(response.status).toBe(401);
        });

        it('should reject invalid token', async () => {
            const response = await request(app)
                .get('/api/users/profile')
                .set('Authorization', 'Bearer invalid-token');

            expect(response.status).toBe(401);
        });
    });

    describe('GET /api/users/:wallet', () => {
        it('should allow public access', async () => {
            const response = await request(app)
                .get('/api/users/7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU');

            // May return 200 or 404, but not 401
            expect([200, 404]).toContain(response.status);
        });
    });

    describe('GET /api/users/:wallet/tokens', () => {
        it('should return created tokens for wallet', async () => {
            const response = await request(app)
                .get('/api/users/7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU/tokens');

            expect(response.status).toBe(200);
        });
    });
});

describe('Authentication Flow', () => {
    it('should generate nonce, then allow verification', async () => {
        // Step 1: Get nonce
        const nonceResponse = await request(app)
            .post('/api/users/nonce')
            .send({ wallet: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU' });

        expect(nonceResponse.status).toBe(200);
        expect(nonceResponse.body).toHaveProperty('nonce');
        expect(nonceResponse.body).toHaveProperty('message');

        // Step 2: Attempt verification (will fail without valid signature)
        const verifyResponse = await request(app)
            .post('/api/users/verify')
            .send({
                wallet: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
                signature: 'fake_signature'
            });

        // Should fail because signature is invalid
        expect([400, 401]).toContain(verifyResponse.status);
    });
});
