/**
 * Admin Service Tests
 * Tests for admin service business logic
 */

describe('Admin Service', () => {
    let adminService;

    beforeAll(() => {
        adminService = require('../../src/services/adminService');
    });

    describe('getConfig', () => {
        it('should return default config when database not configured', async () => {
            const config = await adminService.getConfig();
            expect(config).toHaveProperty('platform_fee_percentage');
            expect(config).toHaveProperty('min_lock_period_days');
            expect(config).toHaveProperty('is_maintenance');
        });

        it('should have reasonable default values', async () => {
            const config = await adminService.getConfig();
            expect(config.platform_fee_percentage).toBeLessThanOrEqual(10);
            expect(config.min_lock_period_days).toBeGreaterThanOrEqual(1);
        });
    });

    describe('getStats', () => {
        it('should throw error when database not configured', async () => {
            // This will throw because supabase is not configured in test env
            try {
                await adminService.getStats();
            } catch (error) {
                expect(error.message).toContain('Database');
            }
        });
    });

    describe('getAllTokens', () => {
        it('should return empty array when database not configured', async () => {
            const result = await adminService.getAllTokens({});
            expect(result).toHaveProperty('tokens');
            expect(Array.isArray(result.tokens)).toBe(true);
        });

        it('should respect pagination parameters', async () => {
            const result = await adminService.getAllTokens({ page: 1, limit: 10 });
            expect(result.page).toBe(1);
            expect(result.limit).toBe(10);
        });
    });

    describe('getAllUsers', () => {
        it('should return empty array when database not configured', async () => {
            const result = await adminService.getAllUsers({});
            expect(result).toHaveProperty('users');
            expect(Array.isArray(result.users)).toBe(true);
        });
    });
});
