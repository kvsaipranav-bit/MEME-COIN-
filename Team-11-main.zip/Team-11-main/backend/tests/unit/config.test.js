/**
 * Configuration Tests
 * Tests for configuration modules
 */

const { SOLANA_NETWORK, TOKEN_DEFAULTS, LOCK_DEFAULTS, VALIDATION } = require('../../src/config/constants');

describe('Configuration Constants', () => {
    describe('SOLANA_NETWORK', () => {
        it('should have valid network configurations', () => {
            expect(SOLANA_NETWORK).toBeDefined();
            expect(SOLANA_NETWORK.DEVNET).toBe('devnet');
            expect(SOLANA_NETWORK.MAINNET).toBe('mainnet-beta');
        });

        it('should use devnet as default', () => {
            expect(SOLANA_NETWORK.DEFAULT).toBe('devnet');
        });
    });

    describe('TOKEN_DEFAULTS', () => {
        it('should have valid token default values', () => {
            expect(TOKEN_DEFAULTS).toBeDefined();
            expect(TOKEN_DEFAULTS.DECIMALS).toBe(9);
            expect(TOKEN_DEFAULTS.INITIAL_SUPPLY).toBeGreaterThan(0);
        });

        it('should have reasonable max values', () => {
            expect(TOKEN_DEFAULTS.MAX_NAME_LENGTH).toBeLessThanOrEqual(50);
            expect(TOKEN_DEFAULTS.MAX_SYMBOL_LENGTH).toBeLessThanOrEqual(10);
        });
    });

    describe('LOCK_DEFAULTS', () => {
        it('should have minimum lock duration of at least 90 days', () => {
            expect(LOCK_DEFAULTS).toBeDefined();
            expect(LOCK_DEFAULTS.MIN_LOCK_DAYS).toBeGreaterThanOrEqual(90);
        });

        it('should have maximum lock duration greater than minimum', () => {
            expect(LOCK_DEFAULTS.MAX_LOCK_DAYS).toBeGreaterThan(LOCK_DEFAULTS.MIN_LOCK_DAYS);
        });

        it('should have valid minimum lock amount', () => {
            expect(LOCK_DEFAULTS.MIN_LOCK_AMOUNT).toBeGreaterThan(0);
        });
    });

    describe('VALIDATION', () => {
        it('should have wallet address validation regex', () => {
            expect(VALIDATION).toBeDefined();
            expect(VALIDATION.WALLET_ADDRESS_REGEX).toBeDefined();
        });

        it('should validate correct Solana addresses', () => {
            const validAddress = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU';
            expect(VALIDATION.WALLET_ADDRESS_REGEX.test(validAddress)).toBe(true);
        });

        it('should reject invalid Solana addresses', () => {
            const invalidAddress = 'invalid-address';
            expect(VALIDATION.WALLET_ADDRESS_REGEX.test(invalidAddress)).toBe(false);
        });
    });
});
