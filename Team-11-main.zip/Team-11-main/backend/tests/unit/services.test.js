/**
 * Service Layer Tests
 * Tests for business logic services
 */

describe('Token Service', () => {
    describe('getAllTokens', () => {
        it('should return empty array when database not configured', async () => {
            // Mock test - service should handle no DB gracefully
            const tokenService = require('../../src/services/tokenService');
            const result = await tokenService.getAllTokens({});
            expect(result).toHaveProperty('tokens');
            expect(Array.isArray(result.tokens)).toBe(true);
        });
    });
});

describe('Liquidity Service', () => {
    describe('calculateRemainingTime', () => {
        it('should return expired for past dates', () => {
            const liquidityService = require('../../src/services/liquidityService');
            const pastDate = new Date(Date.now() - 1000 * 60 * 60 * 24);
            const result = liquidityService.calculateRemainingTime(pastDate.toISOString());
            expect(result.expired).toBe(true);
        });

        it('should return remaining time for future dates', () => {
            const liquidityService = require('../../src/services/liquidityService');
            const futureDate = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30); // 30 days
            const result = liquidityService.calculateRemainingTime(futureDate.toISOString());
            expect(result.expired).toBe(false);
            expect(result.days).toBeGreaterThanOrEqual(29);
        });
    });
});

describe('User Service', () => {
    describe('getUserByWallet', () => {
        it('should return null for non-existent wallet', async () => {
            const userService = require('../../src/services/userService');
            const result = await userService.getUserByWallet('non-existent-wallet');
            expect(result).toBeNull();
        });
    });
});
