/**
 * Solana Service Tests
 * Tests for Solana blockchain verification service
 */

describe('Solana Service', () => {
    let solanaService;

    beforeAll(() => {
        solanaService = require('../../src/services/solanaService');
    });

    describe('verifyTransaction', () => {
        it('should return not found for invalid signature', async () => {
            const result = await solanaService.verifyTransaction('invalid_signature');
            expect(result.confirmed).toBe(false);
        });
    });

    describe('getBalance', () => {
        it('should return 0 for invalid address', async () => {
            const balance = await solanaService.getBalance('invalid');
            expect(balance).toBe(0);
        });

        it('should return a number for valid address', async () => {
            const balance = await solanaService.getBalance('11111111111111111111111111111111');
            expect(typeof balance).toBe('number');
        });
    });

    describe('getNetworkStatus', () => {
        it('should return network status object', async () => {
            const status = await solanaService.getNetworkStatus();
            expect(status).toHaveProperty('slot');
            expect(status).toHaveProperty('epoch');
        });
    });

    describe('getRecentBlockhash', () => {
        it('should return blockhash info', async () => {
            const result = await solanaService.getRecentBlockhash();
            // May be null if RPC fails, but should be object if successful
            if (result) {
                expect(result).toHaveProperty('blockhash');
                expect(result).toHaveProperty('lastValidBlockHeight');
            }
        });
    });
});
