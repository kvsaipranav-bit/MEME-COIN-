/**
 * Utility Functions Tests
 * Tests for helper utilities
 */

const {
    formatError,
    isValidWalletAddress,
    truncateAddress,
    calculateUnlockDate,
    formatTokenAmount
} = require('../../src/utils/helpers');

describe('Utility Functions', () => {
    describe('formatError', () => {
        it('should format error with message', () => {
            const error = new Error('Test error');
            const formatted = formatError(error);

            expect(formatted).toHaveProperty('message', 'Test error');
        });

        it('should handle string errors', () => {
            const formatted = formatError('String error');
            expect(formatted).toHaveProperty('message');
        });

        it('should include stack in development', () => {
            const originalEnv = process.env.NODE_ENV;
            process.env.NODE_ENV = 'development';

            const error = new Error('Test error');
            const formatted = formatError(error);

            expect(formatted).toHaveProperty('stack');
            process.env.NODE_ENV = originalEnv;
        });
    });

    describe('isValidWalletAddress', () => {
        it('should return true for valid Solana address', () => {
            const validAddress = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU';
            expect(isValidWalletAddress(validAddress)).toBe(true);
        });

        it('should return false for invalid address', () => {
            expect(isValidWalletAddress('invalid')).toBe(false);
            expect(isValidWalletAddress('')).toBe(false);
            expect(isValidWalletAddress(null)).toBe(false);
        });

        it('should return false for address with wrong length', () => {
            const shortAddress = '7xKXtg2CW87d97';
            expect(isValidWalletAddress(shortAddress)).toBe(false);
        });
    });

    describe('truncateAddress', () => {
        it('should truncate wallet address', () => {
            const address = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU';
            const truncated = truncateAddress(address);

            expect(truncated).toContain('...');
            expect(truncated.length).toBeLessThan(address.length);
        });

        it('should handle custom lengths', () => {
            const address = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU';
            const truncated = truncateAddress(address, 6, 6);

            expect(truncated).toBe('7xKXtg...osgAsU');
        });

        it('should return empty string for invalid input', () => {
            expect(truncateAddress(null)).toBe('');
            expect(truncateAddress('')).toBe('');
        });
    });

    describe('calculateUnlockDate', () => {
        it('should calculate correct unlock date', () => {
            const days = 90;
            const unlockDate = calculateUnlockDate(days);

            const now = new Date();
            const expected = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);

            // Allow 1 second tolerance
            const diff = Math.abs(unlockDate.getTime() - expected.getTime());
            expect(diff).toBeLessThan(1000);
        });

        it('should return future date', () => {
            const unlockDate = calculateUnlockDate(90);
            expect(unlockDate.getTime()).toBeGreaterThan(Date.now());
        });
    });

    describe('formatTokenAmount', () => {
        it('should format large numbers with commas', () => {
            expect(formatTokenAmount(1000000)).toBe('1,000,000');
            expect(formatTokenAmount(1000000000)).toBe('1,000,000,000');
        });

        it('should handle decimals', () => {
            const formatted = formatTokenAmount(1000.5, 1);
            expect(formatted).toContain('1,000');
        });

        it('should handle zero', () => {
            expect(formatTokenAmount(0)).toBe('0');
        });
    });
});
