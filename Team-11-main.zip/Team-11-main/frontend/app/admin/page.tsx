'use client';

import { useState, useEffect } from 'react';
import { useWallet } from '@/providers/Providers';
import { useAuth } from '@/hooks/useAuth';
import { api, PlatformStats, PlatformConfig, Token, ApiError } from '@/lib/api';
import {
    Settings,
    BarChart3,
    Users,
    Coins,
    Lock,
    AlertCircle,
    CheckCircle,
    XCircle,
    Wallet,
    Save,
    RefreshCw
} from 'lucide-react';

// No mock data - only real blockchain data from API

// Default config for initial state before API loads
const defaultConfig = {
    platformFeePercentage: 0.5,
    minLockPeriodDays: 90,
    isMaintenance: false,
};

interface ConfigState {
    platformFeePercentage: number;
    minLockPeriodDays: number;
    isMaintenance: boolean;
}

export default function AdminPage() {
    const { connected, publicKey, connect } = useWallet();
    const { token: authToken, isAdmin, isAuthenticated, login, isLoading: authLoading } = useAuth();

    const [stats, setStats] = useState<PlatformStats | null>(null);
    const [config, setConfig] = useState<ConfigState>(defaultConfig);
    const [tokens, setTokens] = useState<Token[]>([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [activeTab, setActiveTab] = useState<'stats' | 'config' | 'tokens'>('stats');
    const [error, setError] = useState<string | null>(null);

    // Fetch admin data
    const fetchAdminData = async () => {
        if (!authToken) {
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);

        try {
            const [statsData, configData, tokensData] = await Promise.all([
                api.admin.getStats(authToken),
                api.admin.getConfig(authToken),
                api.admin.getAllTokens(authToken)
            ]);

            setStats(statsData);
            setConfig({
                platformFeePercentage: configData.platform_fee_percentage,
                minLockPeriodDays: configData.min_lock_period_days,
                isMaintenance: configData.is_maintenance,
            });
            setTokens(tokensData.tokens);
        } catch (err) {
            console.error('Failed to fetch admin data:', err);
            const message = err instanceof ApiError
                ? (err.status === 403 ? 'Access denied. Admin privileges required.' : err.message)
                : 'Failed to load admin data. Please ensure the backend is running.';
            setError(message);
            setStats(null);
            setTokens([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isAuthenticated && authToken) {
            fetchAdminData();
        } else {
            setLoading(false);
        }
    }, [isAuthenticated, authToken]);

    const handleSaveConfig = async () => {
        if (!authToken) return;

        setSaving(true);
        setError(null);

        try {
            await api.admin.updateConfig({
                platform_fee_percentage: config.platformFeePercentage,
                min_lock_period_days: config.minLockPeriodDays,
                is_maintenance: config.isMaintenance,
            }, authToken);

            alert('Configuration saved successfully!');
        } catch (err) {
            setError(err instanceof ApiError ? err.message : 'Failed to save configuration');
        } finally {
            setSaving(false);
        }
    };

    const handleToggleTokenStatus = async (tokenAddress: string, currentStatus: boolean) => {
        if (!authToken) return;

        try {
            await api.admin.updateTokenStatus(tokenAddress, !currentStatus, authToken);
            // Refresh tokens
            fetchAdminData();
        } catch (err) {
            setError(err instanceof ApiError ? err.message : 'Failed to update token status');
        }
    };

    const handleLogin = async () => {
        const success = await login();
        if (success) {
            fetchAdminData();
        }
    };

    if (!connected) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{ maxWidth: '500px', margin: '0 auto', textAlign: 'center' }}>
                        <div style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: 'var(--radius-full)',
                            background: 'var(--bg-dark)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto var(--space-8)',
                            color: 'var(--accent)'
                        }}>
                            <Wallet size={36} />
                        </div>
                        <h2 style={{ marginBottom: 'var(--space-4)' }}>Admin Access Required</h2>
                        <p style={{ marginBottom: 'var(--space-8)' }}>
                            Please connect your admin wallet to access the admin panel.
                        </p>
                        <button onClick={connect} className="btn btn-primary btn-lg">
                            ▸ Connect Wallet
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    if (!isAuthenticated) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{ maxWidth: '500px', margin: '0 auto', textAlign: 'center' }}>
                        <div style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: 'var(--radius-full)',
                            background: 'var(--bg-dark)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto var(--space-8)',
                            color: 'var(--accent)'
                        }}>
                            <Lock size={36} />
                        </div>
                        <h2 style={{ marginBottom: 'var(--space-4)' }}>Authentication Required</h2>
                        <p style={{ marginBottom: 'var(--space-8)' }}>
                            Please sign a message to verify your admin access.
                        </p>
                        <button
                            onClick={handleLogin}
                            className="btn btn-primary btn-lg"
                            disabled={authLoading}
                        >
                            {authLoading ? 'Signing...' : '▸ Sign to Authenticate'}
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
            {/* Page Header */}
            <section style={{
                padding: 'var(--space-12) 0',
                borderBottom: '1px solid var(--border)',
                background: 'var(--bg-secondary)'
            }}>
                <div className="container">
                    <div className="flex items-center gap-3">
                        <Settings size={28} style={{ color: 'var(--accent)' }} />
                        <div>
                            <h1 style={{ marginBottom: 'var(--space-1)' }}>Admin Panel</h1>
                            <p style={{ margin: 0 }}>Manage platform configuration and monitor statistics</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Real data only - no mock data banner */}

            {/* Error Banner */}
            {error && (
                <div style={{
                    background: 'rgba(239, 68, 68, 0.1)',
                    borderBottom: '1px solid var(--error)',
                    padding: 'var(--space-3) 0'
                }}>
                    <div className="container">
                        <div className="flex items-center gap-2" style={{ color: 'var(--error)', fontSize: '0.875rem' }}>
                            <AlertCircle size={16} />
                            <span>{error}</span>
                        </div>
                    </div>
                </div>
            )}

            {/* Tab Navigation */}
            <section style={{ borderBottom: '1px solid var(--border)' }}>
                <div className="container">
                    <div style={{ display: 'flex', gap: 'var(--space-1)' }}>
                        {[
                            { id: 'stats', label: 'Statistics', icon: <BarChart3 size={16} /> },
                            { id: 'config', label: 'Configuration', icon: <Settings size={16} /> },
                            { id: 'tokens', label: 'Token Management', icon: <Coins size={16} /> },
                        ].map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id as any)}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 'var(--space-2)',
                                    padding: 'var(--space-4) var(--space-6)',
                                    background: 'none',
                                    border: 'none',
                                    borderBottom: activeTab === tab.id ? '2px solid var(--accent)' : '2px solid transparent',
                                    color: activeTab === tab.id ? 'var(--text-primary)' : 'var(--text-muted)',
                                    cursor: 'pointer',
                                    fontFamily: 'var(--font-mono)',
                                    fontSize: '0.875rem',
                                    fontWeight: 500,
                                    transition: 'all 0.15s'
                                }}
                            >
                                {tab.icon}
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            {/* Content */}
            <section style={{ padding: 'var(--space-12) 0' }}>
                <div className="container">
                    {loading ? (
                        <div style={{ textAlign: 'center', padding: 'var(--space-16) 0' }}>
                            <div style={{
                                width: '48px',
                                height: '48px',
                                border: '3px solid var(--border)',
                                borderTopColor: 'var(--accent)',
                                borderRadius: '50%',
                                margin: '0 auto var(--space-4)',
                                animation: 'spin 1s linear infinite'
                            }} />
                            <p>Loading admin data...</p>
                        </div>
                    ) : (
                        <>
                            {/* Statistics Tab */}
                            {activeTab === 'stats' && stats && (
                                <div className="animate-slide-up">
                                    {/* Stats Grid */}
                                    <div style={{
                                        display: 'grid',
                                        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                                        gap: 'var(--space-6)',
                                        marginBottom: 'var(--space-12)'
                                    }}>
                                        {[
                                            { label: 'Total Tokens', value: stats.totalTokens, icon: <Coins size={24} />, color: 'var(--accent)' },
                                            { label: 'Active Locks', value: stats.activeLocks, icon: <Lock size={24} />, color: 'var(--info)' },
                                            { label: 'Total Locked SOL', value: stats.totalLockedSol.toLocaleString(), icon: <BarChart3 size={24} />, color: 'var(--warning)' },
                                            { label: 'Total Users', value: stats.totalUsers, icon: <Users size={24} />, color: 'var(--accent)' },
                                        ].map((stat) => (
                                            <div key={stat.label} className="card">
                                                <div className="flex items-center gap-3" style={{ marginBottom: 'var(--space-4)' }}>
                                                    <div style={{ color: stat.color }}>{stat.icon}</div>
                                                    <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{stat.label}</span>
                                                </div>
                                                <p style={{
                                                    fontSize: '2rem',
                                                    fontWeight: 700,
                                                    fontFamily: 'var(--font-mono)',
                                                    margin: 0
                                                }}>
                                                    {stat.value}
                                                </p>
                                            </div>
                                        ))}
                                    </div>

                                    {/* Recent Tokens */}
                                    <div className="card">
                                        <h3 style={{ marginBottom: 'var(--space-6)', textTransform: 'none' }}>
                                            Recent Tokens ({stats.recentTokens} today)
                                        </h3>
                                        <div style={{ overflowX: 'auto' }}>
                                            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                                                <thead>
                                                    <tr style={{ borderBottom: '1px solid var(--border)' }}>
                                                        {['Token', 'Symbol', 'Created', 'Status'].map((h) => (
                                                            <th key={h} style={{
                                                                textAlign: 'left',
                                                                padding: 'var(--space-3)',
                                                                fontSize: '0.75rem',
                                                                textTransform: 'uppercase',
                                                                color: 'var(--text-muted)'
                                                            }}>
                                                                {h}
                                                            </th>
                                                        ))}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {tokens.slice(0, 5).map((token) => (
                                                        <tr key={token.id || token.mint_address} style={{ borderBottom: '1px solid var(--border)' }}>
                                                            <td style={{ padding: 'var(--space-3)' }}>
                                                                <span style={{ fontWeight: 600 }}>{token.name}</span>
                                                                <br />
                                                                <code style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                                                    {token.mint_address.slice(0, 8)}...
                                                                </code>
                                                            </td>
                                                            <td style={{ padding: 'var(--space-3)', fontFamily: 'var(--font-mono)' }}>
                                                                ${token.symbol}
                                                            </td>
                                                            <td style={{ padding: 'var(--space-3)', color: 'var(--text-muted)' }}>
                                                                {new Date(token.created_at).toLocaleDateString()}
                                                            </td>
                                                            <td style={{ padding: 'var(--space-3)' }}>
                                                                {token.is_active ? (
                                                                    <span className="badge badge-success">Active</span>
                                                                ) : (
                                                                    <span className="badge badge-error">Inactive</span>
                                                                )}
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Configuration Tab */}
                            {activeTab === 'config' && (
                                <div className="animate-slide-up" style={{ maxWidth: '600px' }}>
                                    <div className="card">
                                        <h3 style={{ marginBottom: 'var(--space-8)', textTransform: 'none' }}>
                                            Platform Configuration
                                        </h3>

                                        <div className="input-group">
                                            <label className="label">Platform Fee (%)</label>
                                            <input
                                                type="number"
                                                className="input"
                                                value={config.platformFeePercentage}
                                                onChange={(e) => setConfig(prev => ({
                                                    ...prev,
                                                    platformFeePercentage: parseFloat(e.target.value)
                                                }))}
                                                min={0}
                                                max={10}
                                                step={0.1}
                                            />
                                            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                                                Fee collected on each liquidity lock (max 10%)
                                            </p>
                                        </div>

                                        <div className="input-group">
                                            <label className="label">Minimum Lock Period (Days)</label>
                                            <input
                                                type="number"
                                                className="input"
                                                value={config.minLockPeriodDays}
                                                onChange={(e) => setConfig(prev => ({
                                                    ...prev,
                                                    minLockPeriodDays: parseInt(e.target.value)
                                                }))}
                                                min={1}
                                            />
                                        </div>

                                        <div className="input-group">
                                            <label className="label">Maintenance Mode</label>
                                            <div style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 'var(--space-4)'
                                            }}>
                                                <button
                                                    onClick={() => setConfig(prev => ({ ...prev, isMaintenance: !prev.isMaintenance }))}
                                                    style={{
                                                        width: '56px',
                                                        height: '28px',
                                                        borderRadius: '14px',
                                                        border: 'none',
                                                        background: config.isMaintenance ? 'var(--error)' : 'var(--accent)',
                                                        position: 'relative',
                                                        cursor: 'pointer',
                                                        transition: 'background 0.2s'
                                                    }}
                                                >
                                                    <div style={{
                                                        width: '24px',
                                                        height: '24px',
                                                        borderRadius: '50%',
                                                        background: 'white',
                                                        position: 'absolute',
                                                        top: '2px',
                                                        left: config.isMaintenance ? '30px' : '2px',
                                                        transition: 'left 0.2s'
                                                    }} />
                                                </button>
                                                <span style={{ color: config.isMaintenance ? 'var(--error)' : 'var(--text-muted)' }}>
                                                    {config.isMaintenance ? 'Enabled (Platform Disabled)' : 'Disabled'}
                                                </span>
                                            </div>
                                        </div>

                                        <button
                                            className="btn btn-primary btn-lg"
                                            style={{ width: '100%', marginTop: 'var(--space-8)' }}
                                            onClick={handleSaveConfig}
                                            disabled={saving}
                                        >
                                            {saving ? 'Saving...' : (
                                                <>
                                                    <Save size={18} />
                                                    Save Configuration
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            )}

                            {/* Tokens Tab */}
                            {activeTab === 'tokens' && (
                                <div className="animate-slide-up">
                                    <div className="card">
                                        <h3 style={{ marginBottom: 'var(--space-6)', textTransform: 'none' }}>
                                            Token Management ({tokens.length} tokens)
                                        </h3>

                                        <div style={{ overflowX: 'auto' }}>
                                            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                                                <thead>
                                                    <tr style={{ borderBottom: '1px solid var(--border)' }}>
                                                        {['Token', 'Symbol', 'Created', 'Status', 'Actions'].map((h) => (
                                                            <th key={h} style={{
                                                                textAlign: 'left',
                                                                padding: 'var(--space-3)',
                                                                fontSize: '0.75rem',
                                                                textTransform: 'uppercase',
                                                                color: 'var(--text-muted)'
                                                            }}>
                                                                {h}
                                                            </th>
                                                        ))}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {tokens.map((token) => (
                                                        <tr key={token.id || token.mint_address} style={{ borderBottom: '1px solid var(--border)' }}>
                                                            <td style={{ padding: 'var(--space-3)' }}>
                                                                {token.name}
                                                            </td>
                                                            <td style={{ padding: 'var(--space-3)', fontFamily: 'var(--font-mono)' }}>
                                                                ${token.symbol}
                                                            </td>
                                                            <td style={{ padding: 'var(--space-3)', color: 'var(--text-muted)' }}>
                                                                {new Date(token.created_at).toLocaleDateString()}
                                                            </td>
                                                            <td style={{ padding: 'var(--space-3)' }}>
                                                                {token.is_active ? (
                                                                    <span className="badge badge-success">Active</span>
                                                                ) : (
                                                                    <span className="badge badge-error">Inactive</span>
                                                                )}
                                                            </td>
                                                            <td style={{ padding: 'var(--space-3)' }}>
                                                                <button
                                                                    className="btn btn-sm"
                                                                    style={{
                                                                        padding: '4px 8px',
                                                                        fontSize: '0.75rem'
                                                                    }}
                                                                    onClick={() => handleToggleTokenStatus(token.mint_address, token.is_active)}
                                                                >
                                                                    {token.is_active ? (
                                                                        <><XCircle size={14} /> Disable</>
                                                                    ) : (
                                                                        <><CheckCircle size={14} /> Enable</>
                                                                    )}
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </section>
        </div>
    );
}
