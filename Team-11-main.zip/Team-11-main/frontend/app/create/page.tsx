'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useWallet } from '@/providers/Providers';
import { Keypair, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { Upload, Info, Lock, ArrowRight, Check, AlertCircle, Wallet, Loader2, ExternalLink, Settings } from 'lucide-react';
import { PROGRAM_ID, getPlatformConfigPDA } from '@/lib/solana';
import {
    isPlatformInitialized,
    buildInitializeTx,
    buildCreateTokenTx,
    buildLockLiquidityWithPoolTx,
    fetchPlatformConfig
} from '@/lib/program';

interface FormData {
    name: string;
    symbol: string;
    description: string;
    initialSupply: string;
    decimals: string;
    creatorFee: string;
    lockDuration: string;
    lockAmount: string;
    poolTokenPercent: string; // % of tokens to add to pool for trading
}

export default function CreateTokenPage() {
    const router = useRouter();
    const { connected, connect, publicKey, connection } = useWallet();
    const [step, setStep] = useState(1);
    const [creating, setCreating] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [txSignature, setTxSignature] = useState<string | null>(null);
    const [createdMint, setCreatedMint] = useState<string | null>(null);
    const [platformInitialized, setPlatformInitialized] = useState<boolean | null>(null);
    const [initializingPlatform, setInitializingPlatform] = useState(false);
    const [minLockDays, setMinLockDays] = useState<number>(90);
    const [platformFeeBps, setPlatformFeeBps] = useState<number>(0);

    const [formData, setFormData] = useState<FormData>({
        name: '',
        symbol: '',
        description: '',
        initialSupply: '1000000000',
        decimals: '9',
        creatorFee: '0',
        lockDuration: '120', // Default to common minimum
        lockAmount: '1',
        poolTokenPercent: '80', // Default 80% of tokens to pool
    });

    // Check if platform is initialized and get config
    useEffect(() => {
        const checkPlatform = async () => {
            if (connection) {
                try {
                    const initialized = await isPlatformInitialized(connection);
                    setPlatformInitialized(initialized);
                    if (initialized) {
                        const config = await fetchPlatformConfig(connection);
                        console.log('📊 Platform config:', config);
                        if (config) {
                            setMinLockDays(config.minLockPeriodDays);
                            setPlatformFeeBps(config.platformFeeBps);
                            // Update form with actual minimum
                            setFormData(prev => ({
                                ...prev,
                                lockDuration: String(config.minLockPeriodDays)
                            }));
                        }
                    }
                } catch (err) {
                    console.error('Failed to check platform:', err);
                    setPlatformInitialized(false);
                }
            }
        };
        checkPlatform();
    }, [connection]);

    const updateField = (field: keyof FormData, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const isStep1Valid = formData.name && formData.symbol && formData.initialSupply;
    const isStep2Valid = Number(formData.lockDuration) >= minLockDays && Number(formData.lockAmount) > 0;

    // Initialize the platform (one time setup)
    const handleInitializePlatform = async () => {
        if (!publicKey || !connection) return;

        setInitializingPlatform(true);
        setError(null);

        try {
            console.log('🔧 Initializing platform...');

            const tx = await buildInitializeTx(
                connection,
                publicKey,
                publicKey, // platform wallet = admin for simplicity
                50, // 0.5% platform fee
                90  // 90 days minimum lock
            );

            const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('confirmed');
            tx.recentBlockhash = blockhash;
            tx.feePayer = publicKey;

            const provider = (window as any).solana;
            const signedTx = await provider.signTransaction(tx);
            const signature = await connection.sendRawTransaction(signedTx.serialize());

            await connection.confirmTransaction({
                signature,
                blockhash,
                lastValidBlockHeight,
            }, 'confirmed');

            console.log('✅ Platform initialized!');
            setPlatformInitialized(true);

        } catch (err: any) {
            console.error('❌ Failed to initialize platform:', err);
            setError(err.message || 'Failed to initialize platform');
        } finally {
            setInitializingPlatform(false);
        }
    };

    // Create Token using the Anchor program
    const handleCreateToken = async () => {
        if (!publicKey || !connection) {
            setError('Please connect your wallet first');
            return;
        }

        setCreating(true);
        setError(null);
        setTxSignature(null);

        try {
            console.log('🚀 Creating token via Team-11 program...');
            console.log('📍 Program ID:', PROGRAM_ID.toBase58());

            // Generate a new mint keypair
            const mintKeypair = Keypair.generate();
            console.log('🪙 Mint Address:', mintKeypair.publicKey.toBase58());

            const decimals = parseInt(formData.decimals);
            const initialSupply = BigInt(formData.initialSupply);
            const creatorFeeBps = Math.round(parseFloat(formData.creatorFee) * 100);

            // Build the create token transaction
            const createTokenTx = await buildCreateTokenTx(
                connection,
                publicKey,
                mintKeypair,
                formData.name,
                formData.symbol,
                decimals,
                initialSupply,
                creatorFeeBps
            );

            // Get fresh blockhash with 'finalized' commitment for more time
            const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
            createTokenTx.recentBlockhash = blockhash;
            createTokenTx.feePayer = publicKey;

            // Add priority fees for better landing on Devnet
            const { ComputeBudgetProgram } = await import('@solana/web3.js');
            const priorityFeeIx = ComputeBudgetProgram.setComputeUnitPrice({ microLamports: 50000 });
            const computeUnitsIx = ComputeBudgetProgram.setComputeUnitLimit({ units: 400000 });
            createTokenTx.instructions = [priorityFeeIx, computeUnitsIx, ...createTokenTx.instructions];

            // Partial sign with mint keypair
            createTokenTx.partialSign(mintKeypair);

            console.log('📝 Requesting signature for token creation...');

            const provider = (window as any).solana;
            const signedTx = await provider.signTransaction(createTokenTx);

            const signature = await connection.sendRawTransaction(signedTx.serialize(), {
                skipPreflight: false,
                preflightCommitment: 'confirmed',
                maxRetries: 3,
            });

            console.log('📤 Token creation tx sent:', signature);
            console.log('🔍 View on Explorer:', `https://explorer.solana.com/tx/${signature}?cluster=devnet`);

            // Wait for confirmation with timeout handling
            try {
                await connection.confirmTransaction({
                    signature,
                    blockhash,
                    lastValidBlockHeight,
                }, 'confirmed');
                console.log('✅ Token created successfully!');
            } catch (confirmErr: any) {
                // Check if tx actually succeeded
                const status = await connection.getSignatureStatus(signature);
                if (status.value?.confirmationStatus === 'confirmed' || status.value?.confirmationStatus === 'finalized') {
                    console.log('✅ Token created (confirmed via status check)');
                } else {
                    throw confirmErr;
                }
            }

            // Now lock liquidity AND create trading pool in ONE step!
            const lockAmount = parseFloat(formData.lockAmount);
            const lockDurationDays = parseInt(formData.lockDuration);
            const lockAmountLamports = BigInt(Math.round(lockAmount * LAMPORTS_PER_SOL));

            // Calculate tokens for pool based on percentage (reuse decimals and initialSupply from above)
            const poolTokenPercent = parseFloat(formData.poolTokenPercent);
            const poolTokenAmount = (initialSupply * BigInt(Math.round(poolTokenPercent))) / BigInt(100) * BigInt(10 ** decimals);

            // Get platform config to get platform wallet
            const config = await fetchPlatformConfig(connection);
            if (!config) {
                throw new Error('Platform config not found');
            }

            console.log('🔒 Creating liquidity pool with trading enabled!');
            console.log('💰 SOL:', lockAmount, 'for', lockDurationDays, 'days');
            console.log('🪙 Tokens to pool:', poolTokenPercent, '% =', poolTokenAmount.toString());

            const lockTx = await buildLockLiquidityWithPoolTx(
                connection,
                publicKey,
                mintKeypair.publicKey,
                config.platformWallet,
                lockAmountLamports,
                poolTokenAmount,
                lockDurationDays
            );

            const { blockhash: lockBlockhash, lastValidBlockHeight: lockBlockHeight } =
                await connection.getLatestBlockhash('finalized');
            lockTx.recentBlockhash = lockBlockhash;
            lockTx.feePayer = publicKey;

            console.log('📝 Requesting signature for liquidity pool creation...');

            const signedLockTx = await provider.signTransaction(lockTx);
            const lockSignature = await connection.sendRawTransaction(signedLockTx.serialize(), {
                skipPreflight: false,
                preflightCommitment: 'confirmed',
            });

            console.log('📤 Pool creation tx sent:', lockSignature);

            await connection.confirmTransaction({
                signature: lockSignature,
                blockhash: lockBlockhash,
                lastValidBlockHeight: lockBlockHeight,
            }, 'confirmed');

            console.log('✅ Trading pool created! Trading is now LIVE!');
            console.log('🪙 Mint Address:', mintKeypair.publicKey.toBase58());

            setTxSignature(signature);
            setCreatedMint(mintKeypair.publicKey.toBase58());
            setStep(4);

        } catch (err: any) {
            console.error('❌ Token creation failed:', err);

            let message = 'Failed to create token';
            if (err.message) {
                if (err.message.includes('User rejected')) {
                    message = 'Transaction was rejected by user';
                } else if (err.message.includes('insufficient')) {
                    message = 'Insufficient SOL balance. Please get some Devnet SOL from a faucet.';
                } else if (err.message.includes('0x1')) {
                    message = 'Insufficient funds for transaction. You need ~0.05 SOL + lock amount.';
                } else if (err.message.includes('already in use')) {
                    message = 'Platform may already be initialized. Try creating the token.';
                } else {
                    message = err.message;
                }
            }
            setError(message);
        } finally {
            setCreating(false);
        }
    };

    if (!connected) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{
                        maxWidth: '500px',
                        margin: '0 auto',
                        textAlign: 'center'
                    }}>
                        <div style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: 'var(--radius-full)',
                            background: 'var(--bg-dark)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto var(--space-8)',
                            color: 'var(--accent)'
                        }}>
                            <Wallet size={36} />
                        </div>
                        <h2 style={{ marginBottom: 'var(--space-4)' }}>Connect Your Wallet</h2>
                        <p style={{ marginBottom: 'var(--space-8)' }}>
                            Please connect your Phantom wallet to create a new token on Devnet.
                        </p>
                        <button onClick={connect} className="btn btn-primary btn-lg">
                            ▸ Connect Wallet
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    // Show platform initialization if not initialized
    if (platformInitialized === false) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{
                        maxWidth: '500px',
                        margin: '0 auto',
                        textAlign: 'center'
                    }}>
                        <div style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: 'var(--radius-full)',
                            background: 'var(--bg-dark)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto var(--space-8)',
                            color: 'var(--accent)'
                        }}>
                            <Settings size={36} />
                        </div>
                        <h2 style={{ marginBottom: 'var(--space-4)' }}>Initialize Platform</h2>
                        <p style={{ marginBottom: 'var(--space-6)' }}>
                            The platform needs to be initialized before creating tokens. This is a one-time setup.
                        </p>

                        {error && (
                            <div style={{
                                background: 'rgba(239, 68, 68, 0.1)',
                                border: '1px solid var(--error)',
                                borderRadius: 'var(--radius-md)',
                                padding: 'var(--space-4)',
                                marginBottom: 'var(--space-6)',
                                color: 'var(--error)',
                                fontSize: '0.875rem'
                            }}>
                                {error}
                            </div>
                        )}

                        <div style={{
                            background: 'var(--bg-secondary)',
                            borderRadius: 'var(--radius-md)',
                            padding: 'var(--space-6)',
                            marginBottom: 'var(--space-8)',
                            textAlign: 'left'
                        }}>
                            <h4 style={{ marginBottom: 'var(--space-4)', textTransform: 'none' }}>Platform Settings</h4>
                            <div style={{ display: 'grid', gap: 'var(--space-2)', fontSize: '0.875rem' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: 'var(--text-muted)' }}>Platform Fee</span>
                                    <span>0.5%</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: 'var(--text-muted)' }}>Min Lock Period</span>
                                    <span>90 days</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: 'var(--text-muted)' }}>Admin</span>
                                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>
                                        {publicKey?.toBase58().slice(0, 8)}...
                                    </span>
                                </div>
                            </div>
                        </div>

                        <button
                            onClick={handleInitializePlatform}
                            className="btn btn-primary btn-lg"
                            disabled={initializingPlatform}
                            style={{ width: '100%' }}
                        >
                            {initializingPlatform ? (
                                <>
                                    <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }} />
                                    Initializing...
                                </>
                            ) : (
                                '▸ Initialize Platform'
                            )}
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    // Loading state while checking platform
    if (platformInitialized === null) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{ textAlign: 'center' }}>
                        <Loader2 size={48} style={{
                            color: 'var(--accent)',
                            margin: '0 auto var(--space-4)',
                            animation: 'spin 1s linear infinite'
                        }} />
                        <p>Checking platform status...</p>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
            {/* Page Header */}
            <section style={{
                padding: 'var(--space-12) 0',
                borderBottom: '1px solid var(--border)',
                background: 'var(--bg-secondary)'
            }}>
                <div className="container">
                    <div style={{ maxWidth: '600px' }}>
                        <h1 style={{ marginBottom: 'var(--space-4)' }}>Create Token</h1>
                        <p>Launch your meme coin on Solana Devnet with built-in liquidity lock.</p>
                    </div>
                </div>
            </section>

            {/* Progress Steps */}
            <section style={{ padding: 'var(--space-8) 0', borderBottom: '1px solid var(--border)' }}>
                <div className="container">
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: 'var(--space-4)'
                    }}>
                        {[1, 2, 3, 4].map((s) => (
                            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)' }}>
                                <div style={{
                                    width: '36px',
                                    height: '36px',
                                    borderRadius: 'var(--radius-full)',
                                    background: step >= s ? (s === 4 && step === 4 ? 'var(--accent)' : 'var(--bg-dark)') : 'var(--bg-secondary)',
                                    color: step >= s ? 'var(--text-light)' : 'var(--text-muted)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    fontFamily: 'var(--font-mono)',
                                    fontWeight: 700,
                                    fontSize: '0.875rem',
                                    transition: 'all 0.2s'
                                }}>
                                    {step > s || (s === 4 && step === 4) ? <Check size={16} /> : s}
                                </div>
                                <span style={{
                                    fontFamily: 'var(--font-mono)',
                                    fontSize: '0.8125rem',
                                    fontWeight: 500,
                                    color: step >= s ? 'var(--text-primary)' : 'var(--text-muted)',
                                    display: s === 4 ? 'none' : 'block'
                                }}>
                                    {s === 1 ? 'Token' : s === 2 ? 'Lock' : s === 3 ? 'Review' : 'Done'}
                                </span>
                                {s < 4 && (
                                    <div style={{
                                        width: '40px',
                                        height: '2px',
                                        background: step > s ? 'var(--bg-dark)' : 'var(--border)'
                                    }} />
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Form Content */}
            <section style={{ padding: 'var(--space-12) 0 var(--space-16)' }}>
                <div className="container">
                    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
                        {/* Step 1: Token Details */}
                        {step === 1 && (
                            <div className="animate-slide-up">
                                <h3 style={{ marginBottom: 'var(--space-8)', textTransform: 'none' }}>
                                    Token Details
                                </h3>

                                <div className="input-group">
                                    <label className="label">Token Name *</label>
                                    <input
                                        type="text"
                                        className="input"
                                        placeholder="e.g., Pepe Classic"
                                        value={formData.name}
                                        onChange={(e) => updateField('name', e.target.value)}
                                        maxLength={50}
                                    />
                                </div>

                                <div className="input-group">
                                    <label className="label">Token Symbol *</label>
                                    <input
                                        type="text"
                                        className="input"
                                        placeholder="e.g., PEPEC"
                                        value={formData.symbol}
                                        onChange={(e) => updateField('symbol', e.target.value.toUpperCase())}
                                        maxLength={10}
                                    />
                                </div>

                                <div className="input-group">
                                    <label className="label">Description</label>
                                    <textarea
                                        className="input"
                                        placeholder="Describe your token..."
                                        value={formData.description}
                                        onChange={(e) => updateField('description', e.target.value)}
                                        maxLength={500}
                                        style={{ minHeight: '100px', resize: 'vertical' }}
                                    />
                                </div>

                                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 'var(--space-4)' }}>
                                    <div className="input-group">
                                        <label className="label">Initial Supply *</label>
                                        <input
                                            type="number"
                                            className="input"
                                            placeholder="1000000000"
                                            value={formData.initialSupply}
                                            onChange={(e) => updateField('initialSupply', e.target.value)}
                                        />
                                    </div>

                                    <div className="input-group">
                                        <label className="label">Decimals</label>
                                        <select
                                            className="input"
                                            value={formData.decimals}
                                            onChange={(e) => updateField('decimals', e.target.value)}
                                        >
                                            <option value="9">9</option>
                                            <option value="6">6</option>
                                            <option value="0">0</option>
                                        </select>
                                    </div>
                                </div>

                                <div style={{ marginTop: 'var(--space-8)' }}>
                                    <button
                                        className="btn btn-primary btn-lg"
                                        style={{ width: '100%' }}
                                        disabled={!isStep1Valid}
                                        onClick={() => setStep(2)}
                                    >
                                        Continue to Liquidity Lock
                                        <ArrowRight size={18} />
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Step 2: Liquidity Lock */}
                        {step === 2 && (
                            <div className="animate-slide-up">
                                <h3 style={{ marginBottom: 'var(--space-8)', textTransform: 'none' }}>
                                    Liquidity Lock
                                </h3>

                                <div style={{
                                    background: 'var(--accent-subtle)',
                                    border: '1px solid var(--accent)',
                                    borderRadius: 'var(--radius-md)',
                                    padding: 'var(--space-4)',
                                    marginBottom: 'var(--space-8)',
                                    display: 'flex',
                                    gap: 'var(--space-3)'
                                }}>
                                    <Info size={20} style={{ color: 'var(--accent-darker)', flexShrink: 0 }} />
                                    <p style={{ fontSize: '0.875rem', color: 'var(--accent-darker)', margin: 0 }}>
                                        Locking liquidity builds trust with your community. The SOL will be locked in a program-controlled account.
                                    </p>
                                </div>

                                <div className="input-group">
                                    <label className="label">Lock Duration (Days) *</label>
                                    <input
                                        type="number"
                                        className="input"
                                        placeholder={String(minLockDays)}
                                        value={formData.lockDuration}
                                        onChange={(e) => updateField('lockDuration', e.target.value)}
                                        min={minLockDays}
                                    />
                                    <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                                        Minimum {minLockDays} days (platform requirement)
                                    </p>
                                </div>

                                <div className="input-group">
                                    <label className="label">Lock Amount (SOL) *</label>
                                    <input
                                        type="number"
                                        className="input"
                                        placeholder="1.0"
                                        value={formData.lockAmount}
                                        onChange={(e) => updateField('lockAmount', e.target.value)}
                                        min={0.1}
                                        step={0.1}
                                    />
                                    <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                                        This SOL goes into the trading pool as liquidity
                                    </p>
                                </div>

                                <div className="input-group">
                                    <label className="label">Tokens for Trading Pool (%) *</label>
                                    <input
                                        type="number"
                                        className="input"
                                        placeholder="80"
                                        value={formData.poolTokenPercent}
                                        onChange={(e) => updateField('poolTokenPercent', e.target.value)}
                                        min={10}
                                        max={100}
                                        step={5}
                                    />
                                    <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                                        {parseFloat(formData.poolTokenPercent) || 80}% of {Number(formData.initialSupply).toLocaleString()} = {Math.round(Number(formData.initialSupply) * (parseFloat(formData.poolTokenPercent) || 80) / 100).toLocaleString()} tokens for trading
                                    </p>
                                </div>

                                <div className="input-group">
                                    <label className="label">Creator Fee (%)</label>
                                    <input
                                        type="number"
                                        className="input"
                                        placeholder="0"
                                        value={formData.creatorFee}
                                        onChange={(e) => updateField('creatorFee', e.target.value)}
                                        min={0}
                                        max={10}
                                        step={0.1}
                                    />
                                </div>

                                <div style={{ display: 'flex', gap: 'var(--space-4)', marginTop: 'var(--space-8)' }}>
                                    <button className="btn btn-ghost" onClick={() => setStep(1)} style={{ flex: 1 }}>
                                        ◂ Back
                                    </button>
                                    <button
                                        className="btn btn-primary btn-lg"
                                        style={{ flex: 2 }}
                                        disabled={!isStep2Valid}
                                        onClick={() => setStep(3)}
                                    >
                                        Review & Create
                                        <ArrowRight size={18} />
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Step 3: Review */}
                        {step === 3 && (
                            <div className="animate-slide-up">
                                <h3 style={{ marginBottom: 'var(--space-8)', textTransform: 'none' }}>
                                    Review & Confirm
                                </h3>

                                {error && (
                                    <div style={{
                                        background: 'rgba(239, 68, 68, 0.1)',
                                        border: '1px solid var(--error)',
                                        borderRadius: 'var(--radius-md)',
                                        padding: 'var(--space-4)',
                                        marginBottom: 'var(--space-6)',
                                        display: 'flex',
                                        gap: 'var(--space-3)'
                                    }}>
                                        <AlertCircle size={20} style={{ color: 'var(--error)', flexShrink: 0 }} />
                                        <p style={{ fontSize: '0.875rem', color: 'var(--error)', margin: 0 }}>
                                            {error}
                                        </p>
                                    </div>
                                )}

                                <div className="card" style={{ marginBottom: 'var(--space-6)' }}>
                                    <h4 style={{ textTransform: 'none', marginBottom: 'var(--space-6)', paddingBottom: 'var(--space-4)', borderBottom: '1px solid var(--border)' }}>
                                        Token Information
                                    </h4>
                                    <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
                                        {[
                                            { label: 'Name', value: formData.name },
                                            { label: 'Symbol', value: `$${formData.symbol}` },
                                            { label: 'Initial Supply', value: Number(formData.initialSupply).toLocaleString() },
                                            { label: 'Decimals', value: formData.decimals },
                                            { label: 'Creator Fee', value: `${formData.creatorFee}%` },
                                        ].map((item) => (
                                            <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{item.label}</span>
                                                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: '0.875rem' }}>{item.value}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="card" style={{ marginBottom: 'var(--space-6)', background: 'var(--bg-dark)', color: 'var(--text-light)' }}>
                                    <div className="flex items-center gap-2" style={{ marginBottom: 'var(--space-4)' }}>
                                        <Lock size={18} style={{ color: 'var(--accent)' }} />
                                        <h4 style={{ textTransform: 'none', color: 'var(--text-light)', margin: 0 }}>
                                            Liquidity Lock
                                        </h4>
                                    </div>
                                    <div style={{ display: 'grid', gap: 'var(--space-3)' }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                            <span style={{ color: 'var(--text-muted)' }}>Amount</span>
                                            <span style={{ color: 'var(--accent)', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
                                                {formData.lockAmount} SOL
                                            </span>
                                        </div>
                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                            <span style={{ color: 'var(--text-muted)' }}>Duration</span>
                                            <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>{formData.lockDuration} Days</span>
                                        </div>
                                    </div>
                                </div>

                                <div style={{
                                    background: 'rgba(245, 158, 11, 0.1)',
                                    border: '1px solid var(--warning)',
                                    borderRadius: 'var(--radius-md)',
                                    padding: 'var(--space-4)',
                                    marginBottom: 'var(--space-8)',
                                    display: 'flex',
                                    gap: 'var(--space-3)'
                                }}>
                                    <AlertCircle size={20} style={{ color: 'var(--warning)', flexShrink: 0 }} />
                                    <p style={{ fontSize: '0.8125rem', color: 'var(--warning)', margin: 0 }}>
                                        You will sign 2 transactions: (1) Create token, (2) Lock liquidity
                                    </p>
                                </div>

                                <div style={{ display: 'flex', gap: 'var(--space-4)' }}>
                                    <button className="btn btn-ghost" onClick={() => setStep(2)} style={{ flex: 1 }} disabled={creating}>
                                        ◂ Back
                                    </button>
                                    <button
                                        className="btn btn-accent btn-lg"
                                        style={{ flex: 2 }}
                                        onClick={handleCreateToken}
                                        disabled={creating}
                                    >
                                        {creating ? (
                                            <>
                                                <Loader2 size={18} style={{ animation: 'spin 1s linear infinite' }} />
                                                Creating...
                                            </>
                                        ) : (
                                            '▸ Create Token & Lock'
                                        )}
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Step 4: Success */}
                        {step === 4 && (
                            <div className="animate-slide-up" style={{ textAlign: 'center' }}>
                                <div style={{
                                    width: '80px',
                                    height: '80px',
                                    borderRadius: 'var(--radius-full)',
                                    background: 'var(--accent)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    margin: '0 auto var(--space-8)',
                                    color: 'var(--bg-dark)'
                                }}>
                                    <Check size={40} />
                                </div>

                                <h2 style={{ marginBottom: 'var(--space-4)' }}>Token Created!</h2>
                                <p style={{ marginBottom: 'var(--space-8)', color: 'var(--text-muted)' }}>
                                    Your token and liquidity lock have been created on Solana Devnet.
                                </p>

                                <div className="card" style={{ marginBottom: 'var(--space-6)', textAlign: 'left' }}>
                                    <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
                                        <div>
                                            <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                                                Token Name
                                            </label>
                                            <span style={{ fontWeight: 600 }}>{formData.name} (${formData.symbol})</span>
                                        </div>
                                        <div>
                                            <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                                                Mint Address
                                            </label>
                                            <code style={{
                                                fontFamily: 'var(--font-mono)',
                                                fontSize: '0.8125rem',
                                                background: 'var(--bg-secondary)',
                                                padding: '8px 12px',
                                                borderRadius: 'var(--radius-sm)',
                                                display: 'block',
                                                wordBreak: 'break-all'
                                            }}>
                                                {createdMint}
                                            </code>
                                        </div>
                                        <div>
                                            <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>
                                                Liquidity Locked
                                            </label>
                                            <span style={{ color: 'var(--accent)', fontWeight: 600 }}>
                                                {formData.lockAmount} SOL for {formData.lockDuration} days
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div style={{ display: 'flex', gap: 'var(--space-4)' }}>
                                    <button className="btn btn-ghost" onClick={() => router.push('/my-tokens')} style={{ flex: 1 }}>
                                        View My Tokens
                                    </button>
                                    <a
                                        href={`https://explorer.solana.com/address/${createdMint}?cluster=devnet`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="btn btn-primary"
                                        style={{ flex: 1 }}
                                    >
                                        View on Explorer
                                        <ExternalLink size={16} />
                                    </a>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </section>
        </div>
    );
}
