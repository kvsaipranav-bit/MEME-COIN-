'use client';

import Link from 'next/link';
import { useState, useEffect, useCallback } from 'react';
import { useWallet } from '@/providers/Providers';
import { Search, Clock, Lock, ExternalLink, TrendingUp, RefreshCw, AlertCircle, Loader2, Coins } from 'lucide-react';
import { TokenCard, TokenCardSkeleton } from '@/components/token';
import { PublicKey } from '@solana/web3.js';
import {
    fetchPlatformConfig,
    fetchTokenMetadata,
    fetchLiquidityLock,
    fetchLiquidityPool
} from '@/lib/program';
import { getPlatformConfigPDA, getTokenMetadataPDA, PROGRAM_ID } from '@/lib/solana';

interface DisplayToken {
    id: string;
    address: string;
    name: string;
    symbol: string;
    logoUrl: string | null;
    creator: string;
    initialSupply: string;
    liquidityLocked: boolean;
    lockAmount: string;
    unlockDate: string;
    createdAt: string;
    isActive: boolean;
}

export default function DashboardPage() {
    const { connection, publicKey } = useWallet();
    const [tokens, setTokens] = useState<DisplayToken[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortBy, setSortBy] = useState('newest');
    const [platformStats, setPlatformStats] = useState<{
        totalTokens: number;
        totalLockedSol: number;
    } | null>(null);

    // Fetch tokens from blockchain by scanning program accounts
    const fetchTokensFromBlockchain = useCallback(async () => {
        if (!connection) {
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);

        try {
            console.log('🔍 Fetching tokens from Solana blockchain...');

            // Get platform config first for stats
            const config = await fetchPlatformConfig(connection);
            if (config) {
                setPlatformStats({
                    totalTokens: Number(config.totalTokens),
                    totalLockedSol: Number(config.totalLockedSol) / 1e9, // Convert lamports to SOL
                });
                console.log('📊 Platform stats:', {
                    totalTokens: Number(config.totalTokens),
                    totalLockedSol: Number(config.totalLockedSol) / 1e9,
                });
            }

            // Fetch program accounts with token_metadata discriminator
            // Account discriminator is sha256("account:TokenMetadata")[0..8]
            // Base58 encoded: gnN7hSiojLQ

            const accounts = await connection.getProgramAccounts(PROGRAM_ID, {
                filters: [
                    {
                        memcmp: {
                            offset: 0,
                            bytes: 'gnN7hSiojLQ', // Base58 encoded discriminator
                        },
                    },
                ],
            });

            console.log(`📦 Found ${accounts.length} token metadata accounts`);

            const displayTokens: DisplayToken[] = [];

            for (const account of accounts) {
                try {
                    const data = account.account.data;

                    // Parse token metadata
                    // Skip discriminator (8 bytes)
                    let offset = 8;

                    const mint = new PublicKey(data.slice(offset, offset + 32));
                    offset += 32;

                    const creator = new PublicKey(data.slice(offset, offset + 32));
                    offset += 32;

                    // Read name
                    const nameLen = data.readUInt32LE(offset);
                    offset += 4;
                    const name = data.slice(offset, offset + nameLen).toString('utf8');
                    offset += nameLen;

                    // Read symbol
                    const symbolLen = data.readUInt32LE(offset);
                    offset += 4;
                    const symbol = data.slice(offset, offset + symbolLen).toString('utf8');
                    offset += symbolLen;

                    const decimals = data[offset];
                    offset += 1;

                    const initialSupply = data.readBigUInt64LE(offset);
                    offset += 8;

                    const creatorFeeBps = data.readUInt16LE(offset);
                    offset += 2;

                    const createdAt = data.readBigInt64LE(offset);
                    offset += 8;

                    const isActive = data[offset] === 1;

                    // Try to fetch liquidity lock for this token
                    let hasLock = false;
                    let lockAmount = 'No lock';
                    let unlockDate = '-';

                    try {
                        const lock = await fetchLiquidityLock(connection, mint, creator);
                        if (lock && !lock.isClaimed) {
                            hasLock = true;
                            lockAmount = `${(Number(lock.amount) / 1e9).toFixed(2)} SOL`;
                            // Use ISO string for proper date parsing in Countdown component
                            const unlockTimestamp = Number(lock.unlockDate);
                            if (unlockTimestamp > 0) {
                                unlockDate = new Date(unlockTimestamp * 1000).toISOString();
                            }
                        }
                    } catch {
                        // No lock found
                    }

                    displayTokens.push({
                        id: mint.toBase58(),
                        address: mint.toBase58(),
                        name: name,
                        symbol: symbol,
                        logoUrl: null,
                        creator: creator.toBase58(),
                        initialSupply: Number(initialSupply).toLocaleString(),
                        liquidityLocked: hasLock,
                        lockAmount: lockAmount,
                        unlockDate: unlockDate,
                        createdAt: new Date(Number(createdAt) * 1000).toLocaleDateString(),
                        isActive: isActive,
                    });

                } catch (parseErr) {
                    console.error('Failed to parse token metadata:', parseErr);
                }
            }

            console.log(`✅ Parsed ${displayTokens.length} tokens`);
            setTokens(displayTokens);

        } catch (err) {
            console.error('❌ Failed to fetch tokens:', err);
            setError('Failed to load tokens from blockchain. Please try again.');
            setTokens([]);
        } finally {
            setLoading(false);
        }
    }, [connection]);

    useEffect(() => {
        fetchTokensFromBlockchain();
    }, [fetchTokensFromBlockchain]);

    // Filter tokens based on search
    const filteredTokens = tokens.filter(token =>
        token.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        token.symbol.toLowerCase().includes(searchQuery.toLowerCase())
    );

    // Sort tokens
    const sortedTokens = [...filteredTokens].sort((a, b) => {
        if (sortBy === 'newest') {
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        } else if (sortBy === 'name') {
            return a.name.localeCompare(b.name);
        }
        return 0;
    });

    return (
        <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
            {/* Page Header */}
            <section style={{
                padding: 'var(--space-12) 0',
                borderBottom: '1px solid var(--border)',
                background: 'var(--bg-secondary)'
            }}>
                <div className="container">
                    <h1 style={{ marginBottom: 'var(--space-4)' }}>Token Dashboard</h1>
                    <p>Explore all tokens created on Team 11. Every token has verifiable liquidity lock.</p>

                    {/* Platform Stats */}
                    {platformStats && (
                        <div style={{
                            display: 'flex',
                            gap: 'var(--space-6)',
                            marginTop: 'var(--space-6)',
                            flexWrap: 'wrap'
                        }}>
                            <div style={{
                                background: 'var(--bg-dark)',
                                padding: 'var(--space-4) var(--space-6)',
                                borderRadius: 'var(--radius-md)',
                                display: 'flex',
                                alignItems: 'center',
                                gap: 'var(--space-3)'
                            }}>
                                <Coins size={20} style={{ color: 'var(--accent)' }} />
                                <div>
                                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Total Tokens</div>
                                    <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--text-light)' }}>
                                        {platformStats.totalTokens}
                                    </div>
                                </div>
                            </div>
                            <div style={{
                                background: 'var(--bg-dark)',
                                padding: 'var(--space-4) var(--space-6)',
                                borderRadius: 'var(--radius-md)',
                                display: 'flex',
                                alignItems: 'center',
                                gap: 'var(--space-3)'
                            }}>
                                <Lock size={20} style={{ color: 'var(--accent)' }} />
                                <div>
                                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Total Locked</div>
                                    <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--accent)' }}>
                                        {platformStats.totalLockedSol.toFixed(2)} SOL
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </section>

            {/* Filters */}
            <section style={{ padding: 'var(--space-6) 0', borderBottom: '1px solid var(--border)' }}>
                <div className="container">
                    <div style={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        gap: 'var(--space-4)',
                        alignItems: 'center',
                        justifyContent: 'space-between'
                    }}>
                        {/* Search */}
                        <div style={{ position: 'relative', flex: '1', maxWidth: '400px' }}>
                            <Search
                                size={18}
                                style={{
                                    position: 'absolute',
                                    left: '12px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    color: 'var(--text-muted)'
                                }}
                            />
                            <input
                                type="text"
                                className="input"
                                placeholder="Search by name or symbol..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                style={{ paddingLeft: '40px' }}
                            />
                        </div>

                        {/* Sort and Refresh */}
                        <div className="flex items-center gap-3">
                            <select
                                className="input"
                                value={sortBy}
                                onChange={(e) => setSortBy(e.target.value)}
                                style={{ width: 'auto', minWidth: '150px' }}
                            >
                                <option value="newest">Newest First</option>
                                <option value="name">Name A-Z</option>
                            </select>

                            <button
                                onClick={fetchTokensFromBlockchain}
                                className="btn btn-ghost"
                                disabled={loading}
                            >
                                <RefreshCw size={16} className={loading ? 'animate-spin' : ''} style={loading ? { animation: 'spin 1s linear infinite' } : {}} />
                            </button>

                            <span style={{
                                fontFamily: 'var(--font-mono)',
                                fontSize: '0.8125rem',
                                color: 'var(--text-muted)'
                            }}>
                                {sortedTokens.length} tokens
                            </span>
                        </div>
                    </div>
                </div>
            </section>

            {/* Error Banner */}
            {error && (
                <div style={{
                    background: 'rgba(239, 68, 68, 0.1)',
                    borderBottom: '1px solid var(--error)',
                    padding: 'var(--space-3) 0'
                }}>
                    <div className="container">
                        <div className="flex items-center gap-2" style={{ color: 'var(--error)', fontSize: '0.875rem' }}>
                            <AlertCircle size={16} />
                            <span>{error}</span>
                            <button
                                onClick={fetchTokensFromBlockchain}
                                className="flex items-center gap-1"
                                style={{
                                    marginLeft: 'auto',
                                    color: 'var(--error)',
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                    fontFamily: 'var(--font-mono)',
                                    fontSize: '0.75rem'
                                }}
                            >
                                <RefreshCw size={14} />
                                Retry
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Token Grid */}
            <section style={{ padding: 'var(--space-12) 0' }}>
                <div className="container">
                    {loading ? (
                        <div style={{ textAlign: 'center', padding: 'var(--space-16) 0' }}>
                            <Loader2 size={48} style={{
                                color: 'var(--accent)',
                                margin: '0 auto var(--space-4)',
                                animation: 'spin 1s linear infinite'
                            }} />
                            <p>Scanning Solana Devnet for tokens...</p>
                        </div>
                    ) : sortedTokens.length === 0 ? (
                        <div style={{
                            textAlign: 'center',
                            padding: 'var(--space-16) 0'
                        }}>
                            <TrendingUp
                                size={48}
                                style={{
                                    color: 'var(--text-muted)',
                                    margin: '0 auto var(--space-6)'
                                }}
                            />
                            <h3 style={{ marginBottom: 'var(--space-2)', textTransform: 'none' }}>
                                No tokens found
                            </h3>
                            <p style={{ marginBottom: 'var(--space-6)', color: 'var(--text-muted)' }}>
                                Be the first to create a token!
                            </p>
                            <Link href="/create" className="btn btn-primary">
                                ▸ Create Token
                            </Link>
                        </div>
                    ) : (
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
                            gap: 'var(--space-6)'
                        }}>
                            {sortedTokens.map((token) => (
                                <TokenCard
                                    key={token.id}
                                    address={token.address}
                                    name={token.name}
                                    symbol={token.symbol}
                                    logoUrl={token.logoUrl}
                                    creator={token.creator}
                                    initialSupply={token.initialSupply}
                                    liquidityLocked={token.liquidityLocked}
                                    lockAmount={token.lockAmount}
                                    unlockDate={token.unlockDate}
                                    createdAt={token.createdAt}
                                />
                            ))}
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
}
