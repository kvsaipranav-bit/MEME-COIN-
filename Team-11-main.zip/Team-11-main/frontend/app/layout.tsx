import type { Metadata } from 'next';
import './globals.css';
import { Providers } from '@/providers/Providers';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';

export const metadata: Metadata = {
    title: 'Team 11 | Create Meme Coins on Solana',
    description: 'Create and launch meme coins on Solana with built-in liquidity lock. Transparent, secure, and trusted by creators.',
    keywords: ['solana', 'meme coin', 'token', 'cryptocurrency', 'liquidity lock', 'SPL token'],
    authors: [{ name: 'Team 11' }],
    openGraph: {
        title: 'Team 11 | Create Meme Coins on Solana',
        description: 'Create and launch meme coins on Solana with built-in liquidity lock.',
        type: 'website',
    },
};

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en">
            <body>
                <Providers>
                    {/* Main content wrapper */}
                    <div style={{
                        display: 'flex',
                        flexDirection: 'column',
                        minHeight: '100vh',
                        position: 'relative'
                    }}>
                        <Header />
                        <main style={{ flex: 1 }}>
                            {children}
                        </main>
                        <Footer />
                    </div>
                </Providers>
            </body>
        </html>
    );
}
