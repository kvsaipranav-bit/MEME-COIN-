'use client';

import Link from 'next/link';
import { useState, useEffect, useCallback } from 'react';
import { useWallet } from '@/providers/Providers';
import { Lock, Clock, ExternalLink, Plus, Settings, Wallet, RefreshCw, AlertCircle, Coins, Loader2, TrendingUp } from 'lucide-react';
import { TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { fetchTokenMetadata, fetchLiquidityPool } from '@/lib/program';

// No mock data - fetch directly from blockchain

interface TokenAccount {
    mint: string;
    balance: string;
    decimals: number;
}

interface MyTokenDisplay {
    id: string;
    address: string;
    name: string;
    symbol: string;
    balance: string;
    decimals: number;
    createdAt: string;
    priceSol: number | null;
    valueSol: number | null;
}

export default function MyTokensPage() {
    const { connected, connect, publicKey, connection } = useWallet();
    const [tokens, setTokens] = useState<MyTokenDisplay[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [totalValue, setTotalValue] = useState<number>(0);

    // Fetch tokens owned by the wallet directly from Solana
    const fetchTokensFromBlockchain = useCallback(async () => {
        if (!publicKey || !connection) {
            setTokens([]);
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);

        try {
            console.log('🔍 Fetching tokens from Solana Devnet for:', publicKey.toBase58());

            // Get all token accounts for this wallet
            const tokenAccounts = await connection.getParsedTokenAccountsByOwner(
                publicKey,
                { programId: TOKEN_PROGRAM_ID },
                'confirmed'
            );

            console.log(`📦 Found ${tokenAccounts.value.length} token accounts`);

            // Process token accounts and fetch metadata for each
            const tokenList: MyTokenDisplay[] = await Promise.all(
                tokenAccounts.value.map(async (account, index) => {
                    const parsedInfo = account.account.data.parsed.info;
                    const mintAddress = parsedInfo.mint;
                    const balance = parsedInfo.tokenAmount.uiAmountString || '0';
                    const decimals = parsedInfo.tokenAmount.decimals;

                    // Try to fetch token metadata from our program
                    let name = `Token ${mintAddress.slice(0, 6)}...`;
                    let symbol = mintAddress.slice(0, 4).toUpperCase();
                    let createdAt = new Date().toLocaleDateString();
                    let priceSol: number | null = null;
                    let valueSol: number | null = null;

                    try {
                        const mintPubkey = new PublicKey(mintAddress);

                        // Fetch Metadata
                        const metadata = await fetchTokenMetadata(connection, mintPubkey);
                        if (metadata) {
                            name = metadata.name;
                            symbol = metadata.symbol;
                            createdAt = new Date(Number(metadata.createdAt) * 1000).toLocaleDateString();
                        }

                        // Fetch Price from Pool
                        const pool = await fetchLiquidityPool(connection, mintPubkey);
                        if (pool && Number(pool.tokenReserve) > 0) {
                            const solReserve = Number(pool.solReserve) / LAMPORTS_PER_SOL;
                            const tokenReserve = Number(pool.tokenReserve) / Math.pow(10, decimals);
                            priceSol = solReserve / tokenReserve;
                            valueSol = parseFloat(balance) * priceSol;
                        }

                    } catch {
                        // Token not from our platform, use defaults
                    }

                    return {
                        id: `${index}-${mintAddress}`,
                        address: mintAddress,
                        name: name,
                        symbol: symbol,
                        balance: balance,
                        decimals: decimals,
                        createdAt: createdAt,
                        priceSol: priceSol,
                        valueSol: valueSol
                    };
                })
            );

            // Filter out tokens with 0 balance
            const tokensWithBalance = tokenList.filter(t => parseFloat(t.balance) > 0);

            // Calculate total value
            const total = tokensWithBalance.reduce((acc, t) => acc + (t.valueSol || 0), 0);
            setTotalValue(total);

            console.log(`✅ Found ${tokensWithBalance.length} tokens with balance`);
            setTokens(tokensWithBalance);

        } catch (err) {
            console.error('❌ Failed to fetch tokens:', err);
            setError('Failed to load tokens from blockchain. Please try again.');
            setTokens([]);
        } finally {
            setLoading(false);
        }
    }, [publicKey, connection]);

    useEffect(() => {
        if (connected && publicKey) {
            fetchTokensFromBlockchain();
        } else {
            setTokens([]);
            setLoading(false);
        }
    }, [connected, publicKey, fetchTokensFromBlockchain]);

    if (!connected) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{
                        maxWidth: '500px',
                        margin: '0 auto',
                        textAlign: 'center'
                    }}>
                        <div style={{
                            width: '80px',
                            height: '80px',
                            borderRadius: 'var(--radius-full)',
                            background: 'var(--bg-dark)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto var(--space-8)',
                            color: 'var(--accent)'
                        }}>
                            <Wallet size={36} />
                        </div>
                        <h2 style={{ marginBottom: 'var(--space-4)' }}>Connect Your Wallet</h2>
                        <p style={{ marginBottom: 'var(--space-8)' }}>
                            Please connect your Phantom wallet to view your tokens.
                        </p>
                        <button onClick={connect} className="btn btn-primary btn-lg">
                            ▸ Connect Wallet
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
            {/* Page Header */}
            <section style={{
                padding: 'var(--space-12) 0',
                borderBottom: '1px solid var(--border)',
                background: 'var(--bg-secondary)'
            }}>
                <div className="container">
                    <div style={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: 'var(--space-4)'
                    }}>
                        <div>
                            <h1 style={{ marginBottom: 'var(--space-2)' }}>My Tokens</h1>
                            <p style={{ margin: 0 }}>
                                View your SPL tokens on Solana Devnet
                            </p>
                        </div>
                        <div className="flex items-center gap-4">
                            {/* Total Value Badge */}
                            <div style={{
                                background: 'var(--bg-dark)',
                                padding: 'var(--space-3) var(--space-4)',
                                borderRadius: 'var(--radius-md)',
                                display: 'flex',
                                alignItems: 'center',
                                gap: 'var(--space-2)',
                                border: '1px solid var(--border)'
                            }}>
                                <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Portfolio:</span>
                                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--accent)' }}>
                                    ≈ {totalValue.toLocaleString(undefined, { maximumFractionDigits: 4 })} SOL
                                </span>
                            </div>

                            <Link href="/create" className="btn btn-primary">
                                <Plus size={18} />
                                Create New Token
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

            {/* Wallet Info */}
            <section style={{ padding: 'var(--space-6) 0', borderBottom: '1px solid var(--border)' }}>
                <div className="container">
                    <div className="flex items-center gap-3" style={{ justifyContent: 'space-between' }}>
                        <div className="flex items-center gap-3">
                            <div style={{
                                width: '8px',
                                height: '8px',
                                borderRadius: '50%',
                                background: 'var(--accent)'
                            }} />
                            <span style={{
                                fontFamily: 'var(--font-mono)',
                                fontSize: '0.875rem',
                                color: 'var(--text-secondary)'
                            }}>
                                Connected: {publicKey?.toBase58().slice(0, 8)}...{publicKey?.toBase58().slice(-8)}
                            </span>
                        </div>
                        <button
                            onClick={fetchTokensFromBlockchain}
                            className="btn btn-ghost btn-sm"
                            disabled={loading}
                        >
                            <RefreshCw size={14} className={loading ? 'animate-spin' : ''} style={loading ? { animation: 'spin 1s linear infinite' } : {}} />
                            Refresh
                        </button>
                    </div>
                </div>
            </section>

            {/* Error Banner */}
            {error && (
                <div style={{
                    background: 'rgba(239, 68, 68, 0.1)',
                    borderBottom: '1px solid var(--error)',
                    padding: 'var(--space-3) 0'
                }}>
                    <div className="container">
                        <div className="flex items-center gap-2" style={{ color: 'var(--error)', fontSize: '0.875rem' }}>
                            <AlertCircle size={16} />
                            <span>{error}</span>
                            <button
                                onClick={fetchTokensFromBlockchain}
                                className="flex items-center gap-1"
                                style={{
                                    marginLeft: 'auto',
                                    color: 'var(--error)',
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                    fontFamily: 'var(--font-mono)',
                                    fontSize: '0.75rem'
                                }}
                            >
                                <RefreshCw size={14} />
                                Retry
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Tokens List */}
            <section style={{ padding: 'var(--space-12) 0' }}>
                <div className="container">
                    {loading ? (
                        <div style={{ textAlign: 'center', padding: 'var(--space-16) 0' }}>
                            <Loader2 size={48} style={{
                                color: 'var(--accent)',
                                margin: '0 auto var(--space-4)',
                                animation: 'spin 1s linear infinite'
                            }} />
                            <p>Scanning Solana Devnet for your tokens...</p>
                        </div>
                    ) : tokens.length === 0 ? (
                        <div style={{
                            textAlign: 'center',
                            padding: 'var(--space-16) 0'
                        }}>
                            <div style={{
                                width: '80px',
                                height: '80px',
                                borderRadius: 'var(--radius-full)',
                                background: 'var(--bg-secondary)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                margin: '0 auto var(--space-6)',
                                color: 'var(--text-muted)'
                            }}>
                                <Coins size={36} />
                            </div>
                            <h3 style={{ marginBottom: 'var(--space-2)', textTransform: 'none' }}>No Tokens Yet</h3>
                            <p style={{ marginBottom: 'var(--space-6)', color: 'var(--text-muted)' }}>
                                You haven&apos;t created any tokens yet. Create your first token to get started!
                            </p>
                            <Link href="/create" className="btn btn-accent">
                                ▸ Create Your First Token
                            </Link>
                        </div>
                    ) : (
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', // Changed to grid layout
                            gap: 'var(--space-6)'
                        }}>
                            <div style={{
                                fontFamily: 'var(--font-mono)',
                                fontSize: '0.875rem',
                                color: 'var(--text-muted)',
                                marginBottom: 'var(--space-2)',
                                gridColumn: '1 / -1'
                            }}>
                                Found {tokens.length} token{tokens.length !== 1 ? 's' : ''} in your wallet
                            </div>

                            {tokens.map((token) => (
                                <div key={token.id} className="card" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                                    <div className="flex items-center gap-4" style={{ marginBottom: 'var(--space-4)' }}>
                                        <div style={{
                                            width: '48px',
                                            height: '48px',
                                            borderRadius: 'var(--radius-lg)',
                                            background: 'var(--bg-dark)',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            color: 'var(--accent)',
                                            fontFamily: 'var(--font-mono)',
                                            fontWeight: 700,
                                            fontSize: '1.25rem'
                                        }}>
                                            {token.symbol.charAt(0)}
                                        </div>
                                        <div>
                                            <h3 style={{
                                                fontSize: '1rem',
                                                textTransform: 'none',
                                                marginBottom: '2px',
                                                whiteSpace: 'nowrap',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                maxWidth: '180px'
                                            }}>
                                                {token.name}
                                            </h3>
                                            <span style={{
                                                fontFamily: 'var(--font-mono)',
                                                fontSize: '0.75rem',
                                                color: 'var(--text-muted)'
                                            }}>
                                                {token.symbol}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Balance & Value */}
                                    <div style={{
                                        background: 'var(--bg-secondary)',
                                        borderRadius: 'var(--radius-md)',
                                        padding: 'var(--space-4)',
                                        marginBottom: 'var(--space-4)',
                                        flex: 1
                                    }}>
                                        <div className="flex justify-between items-end mb-2">
                                            <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>Balance</div>
                                            <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '1.125rem' }}>
                                                {parseFloat(token.balance).toLocaleString()}
                                            </div>
                                        </div>

                                        {token.valueSol !== null ? (
                                            <div className="flex justify-between items-end" style={{ paddingTop: '8px', borderTop: '1px dashed var(--border)' }}>
                                                <div style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>Value</div>
                                                <div style={{ color: 'var(--accent)', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
                                                    ≈ {token.valueSol.toFixed(4)} SOL
                                                </div>
                                            </div>
                                        ) : (
                                            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontStyle: 'italic', textAlign: 'right' }}>
                                                Price unavailable
                                            </div>
                                        )}
                                    </div>

                                    {/* Actions */}
                                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-3)' }}>
                                        <a
                                            href={`https://explorer.solana.com/address/${token.address}?cluster=devnet`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="btn btn-ghost btn-sm"
                                            style={{ justifyContent: 'center' }}
                                        >
                                            Explorer <ExternalLink size={12} style={{ marginLeft: '4px' }} />
                                        </a>
                                        <Link
                                            href={`/token/${token.address}`}
                                            className="btn btn-primary btn-sm"
                                            style={{ justifyContent: 'center' }}
                                        >
                                            Trade
                                        </Link>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
}
