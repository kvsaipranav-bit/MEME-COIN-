import Link from 'next/link';
import { Lock, Zap, Shield, DollarSign, ArrowRight } from 'lucide-react';

export default function Home() {
    return (
        <div className="min-h-screen">
            {/* Hero Section */}
            <section className="hero grid-bg">
                {/* Globe/Grid Illustration Background */}
                <svg
                    className="hero-illustration"
                    viewBox="0 0 800 600"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    {/* Horizontal lines */}
                    {[...Array(12)].map((_, i) => (
                        <ellipse
                            key={`h-${i}`}
                            cx="400"
                            cy="300"
                            rx={350 - i * 5}
                            ry={(i + 1) * 25}
                            stroke="currentColor"
                            strokeWidth="1"
                            fill="none"
                            opacity={0.3}
                        />
                    ))}
                    {/* Vertical lines */}
                    {[...Array(24)].map((_, i) => (
                        <line
                            key={`v-${i}`}
                            x1={400 + Math.cos((i * Math.PI) / 12) * 350}
                            y1={300 + Math.sin((i * Math.PI) / 12) * 300}
                            x2={400 - Math.cos((i * Math.PI) / 12) * 350}
                            y2={300 - Math.sin((i * Math.PI) / 12) * 300}
                            stroke="currentColor"
                            strokeWidth="1"
                            opacity={0.2}
                        />
                    ))}
                    {/* Center circle */}
                    <circle cx="400" cy="300" r="8" fill="currentColor" opacity="0.3" />
                </svg>

                <div className="container">
                    <div className="hero-content">
                        {/* News Badge */}
                        <div className="mb-8 animate-slide-up">
                            <span className="badge badge-success">
                                <span style={{
                                    width: '6px',
                                    height: '6px',
                                    borderRadius: '50%',
                                    background: 'currentColor',
                                    animation: 'pulse-dot 2s ease-in-out infinite'
                                }} />
                                ▸ NOW LIVE ON SOLANA DEVNET ◂
                            </span>
                        </div>

                        {/* Main Title */}
                        <h1 className="hero-title animate-slide-up animate-delay-1">
                            Create Meme Coins<br />
                            <span style={{ color: 'var(--text-secondary)' }}>on Solana</span>
                        </h1>

                        {/* Subtitle */}
                        <p className="hero-subtitle animate-slide-up animate-delay-2">
                            Launch your meme coin with built-in liquidity lock.
                            Transparent, secure, and trusted by creators worldwide.
                        </p>

                        {/* CTA Buttons */}
                        <div className="flex items-center justify-center gap-4 animate-slide-up animate-delay-3" style={{ flexWrap: 'wrap' }}>
                            <Link href="/create" className="btn btn-primary btn-lg">
                                ▸ Create Token
                            </Link>
                            <Link href="/dashboard" className="btn btn-ghost btn-lg">
                                ▸ Explore Tokens ◂
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

            {/* Stats Section */}
            <section className="container">
                <div className="stats-grid">
                    <div className="stat-item animate-slide-up">
                        <div className="stat-value">0</div>
                        <div className="stat-label">Tokens Created</div>
                    </div>
                    <div className="stat-item animate-slide-up animate-delay-1">
                        <div className="stat-value">0 SOL</div>
                        <div className="stat-label">Liquidity Locked</div>
                    </div>
                    <div className="stat-item animate-slide-up animate-delay-2">
                        <div className="stat-value">90+</div>
                        <div className="stat-label">Days Min Lock</div>
                    </div>
                </div>
            </section>

            {/* Features Section */}
            <section className="section">
                <div className="container">
                    <div className="text-center mb-12">
                        <h2 className="mb-4">Why Choose Team 11?</h2>
                        <p style={{ maxWidth: '600px', margin: '0 auto' }}>
                            Built for transparency and trust. Every token comes with verifiable liquidity lock.
                        </p>
                    </div>

                    <div className="feature-grid">
                        {/* Feature 1 */}
                        <div className="feature-card">
                            <div className="feature-icon">
                                <Lock size={24} />
                            </div>
                            <h4 className="feature-title">Liquidity Lock</h4>
                            <p className="feature-description">
                                Lock your initial SOL liquidity for minimum 90 days. Build trust with your community from day one.
                            </p>
                        </div>

                        {/* Feature 2 */}
                        <div className="feature-card">
                            <div className="feature-icon">
                                <DollarSign size={24} />
                            </div>
                            <h4 className="feature-title">Low Fees</h4>
                            <p className="feature-description">
                                Only 0.5% platform fee on trades. Customize your own creator fees for additional revenue.
                            </p>
                        </div>

                        {/* Feature 3 */}
                        <div className="feature-card">
                            <div className="feature-icon">
                                <Zap size={24} />
                            </div>
                            <h4 className="feature-title">Instant Deploy</h4>
                            <p className="feature-description">
                                Create and deploy your token in minutes. No coding required. Just fill in the details.
                            </p>
                        </div>

                        {/* Feature 4 */}
                        <div className="feature-card">
                            <div className="feature-icon">
                                <Shield size={24} />
                            </div>
                            <h4 className="feature-title">Audited Security</h4>
                            <p className="feature-description">
                                Built on Solana with audited smart contracts. Your funds are protected by industry-leading security.
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            {/* How It Works Section */}
            <section className="section" style={{ background: 'var(--bg-secondary)' }}>
                <div className="container">
                    <div className="text-center mb-12">
                        <h2 className="mb-4">How It Works</h2>
                        <p>Launch your token in three simple steps</p>
                    </div>

                    <div className="steps-grid">
                        {/* Step 1 */}
                        <div className="step-item">
                            <div className="step-number">1</div>
                            <h4 className="step-title">Create Token</h4>
                            <p className="step-description">
                                Set name, symbol, supply, and upload your logo
                            </p>
                        </div>

                        {/* Step 2 */}
                        <div className="step-item">
                            <div className="step-number">2</div>
                            <h4 className="step-title">Lock Liquidity</h4>
                            <p className="step-description">
                                Add SOL liquidity and lock for 90+ days
                            </p>
                        </div>

                        {/* Step 3 */}
                        <div className="step-item">
                            <div className="step-number">3</div>
                            <h4 className="step-title">Launch & Trade</h4>
                            <p className="step-description">
                                Your token goes live on Raydium for trading
                            </p>
                        </div>
                    </div>

                    {/* CTA */}
                    <div className="text-center mt-8">
                        <Link href="/create" className="btn btn-accent btn-lg">
                            ▸ Get Started Now
                            <ArrowRight size={18} />
                        </Link>
                    </div>
                </div>
            </section>

            {/* Trust Section */}
            <section className="section">
                <div className="container">
                    <div className="card" style={{
                        background: 'var(--bg-dark)',
                        color: 'var(--text-light)',
                        textAlign: 'center',
                        padding: 'var(--space-16)'
                    }}>
                        <h3 style={{ marginBottom: 'var(--space-4)', color: 'var(--text-light)' }}>
                            Trusted by Creators
                        </h3>
                        <p style={{
                            color: 'var(--text-muted)',
                            maxWidth: '500px',
                            margin: '0 auto var(--space-8)'
                        }}>
                            Join the growing community of meme coin creators who trust Team 11
                            for transparent and secure token launches.
                        </p>
                        <Link href="/dashboard" className="btn btn-accent">
                            ▸ View All Tokens
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
}
