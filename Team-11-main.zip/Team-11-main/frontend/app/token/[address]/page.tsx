'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { useState, useEffect, useCallback } from 'react';
import { useWallet } from '@/providers/Providers';
import { PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { getMint, getAccount, TOKEN_PROGRAM_ID, getAssociatedTokenAddressSync } from '@solana/spl-token';
import {
    ArrowLeft,
    ExternalLink,
    Lock,
    Copy,
    Check,
    Clock,
    User,
    Coins,
    RefreshCw,
    AlertCircle,
    Loader2,
    TrendingUp,
    TrendingDown,
    ArrowUpRight,
    ArrowDownRight,
    Zap
} from 'lucide-react';
import {
    fetchTokenMetadata,
    fetchLiquidityLock,
    fetchLiquidityPool,
    fetchPlatformConfig,
    isPoolInitialized,
    buildInitPoolTx,
    buildBuyTokensTx,
    buildSellTokensTx,
    calculateBuyAmount,
    calculateSellAmount,
    calculatePrice
} from '@/lib/program';
import { getExplorerUrl } from '@/lib/solana';

function formatAddress(address: string): string {
    if (address.length <= 10) return address;
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
}

interface TokenData {
    address: string;
    name: string;
    symbol: string;
    decimals: number;
    supply: string;
    creator: string;
    createdAt: Date | null;
    creatorFeeBps: number;
}

interface PoolData {
    solReserve: bigint;
    tokenReserve: bigint;
    totalBought: bigint;
    totalSold: bigint;
    isActive: boolean;
    priceSol?: number;
}

interface LockData {
    amount: bigint;
    unlockDate: bigint;
    isClaimed: boolean;
}

export default function TokenDetailsPage() {
    const params = useParams();
    const address = params.address as string;
    const { connection, publicKey, connected, signAndSendTransaction } = useWallet();

    const [token, setToken] = useState<TokenData | null>(null);
    const [pool, setPool] = useState<PoolData | null>(null);
    const [lock, setLock] = useState<LockData | null>(null);
    const [userBalance, setUserBalance] = useState<string>('0');
    const [userTokenBalance, setUserTokenBalance] = useState<bigint>(BigInt(0));
    const [userTokenValueSol, setUserTokenValueSol] = useState<number>(0);
    const [platformWallet, setPlatformWallet] = useState<PublicKey | null>(null);

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);

    // Trading state
    const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');
    const [tradeAmount, setTradeAmount] = useState('');
    const [trading, setTrading] = useState(false);
    const [tradeError, setTradeError] = useState<string | null>(null);
    const [tradeSuccess, setTradeSuccess] = useState<string | null>(null);

    // Create pool state
    const [showCreatePool, setShowCreatePool] = useState(false);
    const [poolTokenAmount, setPoolTokenAmount] = useState('');
    const [poolSolAmount, setPoolSolAmount] = useState('');
    const [creatingPool, setCreatingPool] = useState(false);

    const isCreator = publicKey && token?.creator === publicKey.toBase58();

    const fetchAllData = useCallback(async () => {
        if (!connection) return;

        setLoading(true);
        setError(null);

        try {
            console.log('🔍 Fetching token data from Solana:', address);

            let mintPubkey: PublicKey;
            try {
                mintPubkey = new PublicKey(address);
            } catch {
                throw new Error('Invalid token address');
            }

            // Fetch mint info
            const mintInfo = await getMint(connection, mintPubkey, 'confirmed', TOKEN_PROGRAM_ID);
            const supplyNumber = Number(mintInfo.supply) / Math.pow(10, mintInfo.decimals);

            // Fetch token metadata from our program
            const metadata = await fetchTokenMetadata(connection, mintPubkey);

            const tokenData: TokenData = {
                address: address,
                name: metadata?.name || `Token ${address.slice(0, 6)}...`,
                symbol: metadata?.symbol || address.slice(0, 4).toUpperCase(),
                decimals: mintInfo.decimals,
                supply: supplyNumber.toLocaleString(),
                creator: metadata?.creator?.toBase58() || mintInfo.mintAuthority?.toBase58() || 'Unknown',
                createdAt: metadata?.createdAt ? new Date(Number(metadata.createdAt) * 1000) : null,
                creatorFeeBps: metadata?.creatorFeeBps || 0,
            };
            setToken(tokenData);

            // Fetch platform config for wallet
            const config = await fetchPlatformConfig(connection);
            if (config) {
                setPlatformWallet(config.platformWallet);
            }

            // Fetch liquidity lock if exists
            if (metadata?.creator) {
                try {
                    const lockData = await fetchLiquidityLock(connection, mintPubkey, metadata.creator);
                    if (lockData) {
                        setLock({
                            amount: lockData.amount,
                            unlockDate: lockData.unlockDate,
                            isClaimed: lockData.isClaimed,
                        });
                    }
                } catch {
                    // No lock for this token
                }
            }

            // Fetch liquidity pool if exists
            const poolData = await fetchLiquidityPool(connection, mintPubkey);
            if (poolData) {
                const solReserve = Number(poolData.solReserve) / LAMPORTS_PER_SOL;
                const tokenReserve = Number(poolData.tokenReserve) / Math.pow(10, mintInfo.decimals);
                const currentPrice = solReserve / tokenReserve; // Price in SOL

                setPool({
                    solReserve: poolData.solReserve,
                    tokenReserve: poolData.tokenReserve,
                    totalBought: poolData.totalBought,
                    totalSold: poolData.totalSold,
                    isActive: poolData.isActive,
                    priceSol: currentPrice, // Added priceSol to the pool state
                });
                console.log('📊 Pool found:', {
                    solReserve: solReserve,
                    tokenReserve: tokenReserve
                });

                // Fetch user balance if connected
                if (publicKey) {
                    try {
                        const ata = getAssociatedTokenAddressSync(mintPubkey, publicKey);
                        const accountInfo = await getAccount(connection, ata, 'confirmed', TOKEN_PROGRAM_ID);
                        const balance = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
                        setUserBalance(balance.toLocaleString());
                        setUserTokenBalance(accountInfo.amount);

                        // Calculate REALIZABLE value (what user actually gets if they sell all)
                        // AMM Formula: dy = y - (k / (x + dx))
                        // x = pool token reserve
                        // y = pool sol reserve
                        // dx = user token balance
                        // dy = sol received
                        let realValue = 0;
                        if (accountInfo.amount > BigInt(0)) {
                            const dx = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
                            const k = solReserve * tokenReserve;
                            const newX = tokenReserve + dx;
                            const newY = k / newX;
                            realValue = solReserve - newY;
                        }
                        setUserTokenValueSol(realValue > 0 ? realValue : 0);

                    } catch {
                        setUserBalance('0');
                        setUserTokenBalance(BigInt(0));
                        setUserTokenValueSol(0);
                    }
                }
            } else {
                // If no pool, ensure userTokenValueSol is reset
                setUserTokenValueSol(0);
                if (publicKey) {
                    try {
                        const ata = getAssociatedTokenAddressSync(mintPubkey, publicKey);
                        const accountInfo = await getAccount(connection, ata, 'confirmed', TOKEN_PROGRAM_ID);
                        const balance = Number(accountInfo.amount) / Math.pow(10, mintInfo.decimals);
                        setUserBalance(balance.toLocaleString());
                        setUserTokenBalance(accountInfo.amount);
                    } catch {
                        setUserBalance('0');
                        setUserTokenBalance(BigInt(0));
                    }
                }
            }

            console.log('✅ Token data loaded successfully');

        } catch (err: any) {
            console.error('❌ Failed to fetch token:', err);
            setError(err.message || 'Token not found');
            setToken(null);
        } finally {
            setLoading(false);
        }
    }, [address, connection, publicKey]);

    useEffect(() => {
        fetchAllData();
    }, [fetchAllData]);

    const handleCopy = async () => {
        await navigator.clipboard.writeText(address);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    // Calculate preview amounts
    const getTradePreview = () => {
        if (!pool || !tradeAmount || !token) return null;

        const decimals = token.decimals;

        if (tradeType === 'buy') {
            const solInput = BigInt(Math.floor(parseFloat(tradeAmount) * LAMPORTS_PER_SOL));
            if (solInput <= 0) return null;
            const tokensOut = calculateBuyAmount(solInput, pool.solReserve, pool.tokenReserve);
            return {
                input: parseFloat(tradeAmount),
                output: Number(tokensOut) / Math.pow(10, decimals),
                inputSymbol: 'SOL',
                outputSymbol: token.symbol,
            };
        } else {
            const tokenInput = BigInt(Math.floor(parseFloat(tradeAmount) * Math.pow(10, decimals)));
            if (tokenInput <= 0) return null;
            const solOut = calculateSellAmount(tokenInput, pool.solReserve, pool.tokenReserve);
            return {
                input: parseFloat(tradeAmount),
                output: Number(solOut) / LAMPORTS_PER_SOL,
                inputSymbol: token.symbol,
                outputSymbol: 'SOL',
            };
        }
    };

    const preview = getTradePreview();

    // Handle trade execution
    const handleTrade = async () => {
        if (!connection || !publicKey || !signAndSendTransaction || !pool || !platformWallet || !token) return;

        setTrading(true);
        setTradeError(null);
        setTradeSuccess(null);

        try {
            const mintPubkey = new PublicKey(address);
            let tx;

            console.log('🔄 Starting trade...');
            console.log('📊 Trade type:', tradeType);
            console.log('💰 Amount:', tradeAmount);
            console.log('🪙 Token:', token.symbol);
            console.log('👛 User:', publicKey.toBase58());
            console.log('🏦 Platform Wallet:', platformWallet.toBase58());
            console.log('📈 Pool before:', {
                solReserve: pool ? Number(pool.solReserve) / LAMPORTS_PER_SOL : 'N/A',
                tokenReserve: pool ? Number(pool.tokenReserve) / Math.pow(10, token.decimals) : 'N/A'
            });

            if (tradeType === 'buy') {
                const solAmount = BigInt(Math.floor(parseFloat(tradeAmount) * LAMPORTS_PER_SOL));
                console.log('💵 SOL Amount (lamports):', solAmount.toString());

                // Check SOL balance
                if (platformWallet && solAmount > (await connection.getBalance(publicKey))) {
                    throw new Error('Insufficient SOL balance');
                }

                tx = await buildBuyTokensTx(connection, publicKey, mintPubkey, platformWallet, solAmount);
                console.log('📝 Buy transaction built');
            } else {
                const tokenAmount = BigInt(Math.floor(parseFloat(tradeAmount) * Math.pow(10, token.decimals)));
                console.log('🪙 Token Amount (raw):', tokenAmount.toString());

                // Check Token balance
                if (tokenAmount > userTokenBalance) {
                    const max = Number(userTokenBalance) / Math.pow(10, token.decimals);
                    throw new Error(`Insufficient token balance. You only have ${max.toLocaleString()} ${token.symbol}`);
                }

                tx = await buildSellTokensTx(connection, publicKey, mintPubkey, platformWallet, tokenAmount);
                console.log('📝 Sell transaction built');
            }

            console.log('📤 Sending transaction...');
            const sig = await signAndSendTransaction(tx);
            console.log('📜 Transaction signature:', sig);

            if (!sig) throw new Error('Transaction failed - no signature returned');

            setTradeSuccess(`Trade successful! Tx: ${sig.slice(0, 8)}...`);
            console.log('✅ Trade success! Signature:', sig);
            console.log('🔍 Check on Explorer: https://explorer.solana.com/tx/' + sig + '?cluster=devnet');

            setTradeAmount('');

            // Wait a bit before refreshing to let the transaction propagate
            console.log('⏳ Waiting 3s for transaction to propagate...');
            await new Promise(resolve => setTimeout(resolve, 3000));

            // Refresh data
            console.log('🔄 Refreshing pool data...');
            await fetchAllData();
            console.log('✅ Data refreshed');

        } catch (err: any) {
            console.error('❌ Trade failed:', err);
            console.error('❌ Error details:', JSON.stringify(err, null, 2));
            setTradeError(err.message || 'Trade failed');
        } finally {
            setTrading(false);
        }
    };

    // Handle pool creation
    const handleCreatePool = async () => {
        if (!connection || !publicKey || !signAndSendTransaction || !token) return;

        setCreatingPool(true);
        setTradeError(null);

        try {
            const mintPubkey = new PublicKey(address);
            const tokenAmount = BigInt(Math.floor(parseFloat(poolTokenAmount) * Math.pow(10, token.decimals)));
            const solAmount = BigInt(Math.floor(parseFloat(poolSolAmount) * LAMPORTS_PER_SOL));

            const tx = await buildInitPoolTx(connection, publicKey, mintPubkey, tokenAmount, solAmount);

            const sig = await signAndSendTransaction(tx);
            if (!sig) throw new Error('Transaction failed');

            setTradeSuccess(`Pool created! Tx: ${sig.slice(0, 8)}...`);
            setShowCreatePool(false);

            // Refresh data
            await fetchAllData();

        } catch (err: any) {
            console.error('Pool creation failed:', err);
            setTradeError(err.message || 'Failed to create pool');
        } finally {
            setCreatingPool(false);
        }
    };

    // Get current price
    const currentPrice = pool && token ?
        Number(pool.solReserve) / Number(pool.tokenReserve) * Math.pow(10, token.decimals) / LAMPORTS_PER_SOL : 0;

    if (loading) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{ textAlign: 'center' }}>
                        <Loader2 size={48} style={{
                            color: 'var(--accent)',
                            margin: '0 auto var(--space-4)',
                            animation: 'spin 1s linear infinite'
                        }} />
                        <p>Loading token from Solana Devnet...</p>
                    </div>
                </div>
            </div>
        );
    }

    if (error || !token) {
        return (
            <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
                <div className="container" style={{ padding: 'var(--space-24) var(--space-6)' }}>
                    <div style={{ maxWidth: '500px', margin: '0 auto', textAlign: 'center' }}>
                        <AlertCircle size={48} style={{ color: 'var(--error)', marginBottom: 'var(--space-4)' }} />
                        <h2>Error Loading Token</h2>
                        <p style={{ color: 'var(--text-muted)', marginBottom: 'var(--space-6)' }}>{error}</p>
                        <Link href="/dashboard" className="btn btn-primary">Back to Dashboard</Link>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div style={{ paddingTop: '72px', minHeight: '100vh' }}>
            {/* Header */}
            <section style={{ padding: 'var(--space-6) 0', borderBottom: '1px solid var(--border)' }}>
                <div className="container">
                    <Link href="/dashboard" className="flex items-center gap-2" style={{ color: 'var(--text-muted)', marginBottom: 'var(--space-4)' }}>
                        <ArrowLeft size={16} /> Back to Dashboard
                    </Link>

                    <div className="flex items-center gap-4">
                        <div style={{
                            width: '64px',
                            height: '64px',
                            borderRadius: 'var(--radius-lg)',
                            background: 'linear-gradient(135deg, var(--accent) 0%, var(--accent-darker) 100%)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '1.75rem',
                            fontWeight: 700,
                            color: 'var(--bg-dark)'
                        }}>
                            {token.symbol.charAt(0)}
                        </div>
                        <div>
                            <h1 style={{ margin: 0, fontSize: '1.75rem' }}>{token.name}</h1>
                            <div className="flex items-center gap-2" style={{ marginTop: '4px' }}>
                                <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--accent)', fontWeight: 600 }}>
                                    ${token.symbol}
                                </span>
                                {pool && (
                                    <span className="badge badge-success">Trading Active</span>
                                )}
                                {lock && !lock.isClaimed && (
                                    <span className="badge" style={{ background: 'var(--bg-dark)' }}>
                                        <Lock size={12} /> Locked
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="container" style={{ padding: 'var(--space-8) 0' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 400px', gap: 'var(--space-6)', alignItems: 'start' }}>

                    {/* Left Column - Token Info */}
                    <div>
                        {/* Price Card */}
                        {pool && (
                            <div className="card" style={{ marginBottom: 'var(--space-6)' }}>
                                <h3 style={{ marginBottom: 'var(--space-4)', fontSize: '1rem' }}>Current Price</h3>
                                <div style={{ fontSize: '2rem', fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--accent)' }}>
                                    {currentPrice.toFixed(9)} SOL
                                </div>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)', marginTop: 'var(--space-4)' }}>
                                    <div>
                                        <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Pool Liquidity (SOL)</p>
                                        <p style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
                                            {(Number(pool.solReserve) / LAMPORTS_PER_SOL).toFixed(4)} SOL
                                        </p>
                                    </div>
                                    <div>
                                        <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Pool Liquidity (Token)</p>
                                        <p style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
                                            {(Number(pool.tokenReserve) / Math.pow(10, token.decimals)).toLocaleString()} {token.symbol}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Token Details */}
                        <div className="card" style={{ marginBottom: 'var(--space-6)' }}>
                            <h3 style={{ marginBottom: 'var(--space-4)', fontSize: '1rem' }}>Token Details</h3>

                            <div style={{ display: 'grid', gap: 'var(--space-3)' }}>
                                <div className="flex items-center justify-between">
                                    <span style={{ color: 'var(--text-muted)' }}>Address</span>
                                    <div className="flex items-center gap-2">
                                        <code style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem' }}>
                                            {formatAddress(address)}
                                        </code>
                                        <button onClick={handleCopy} className="btn btn-ghost" style={{ padding: '4px' }}>
                                            {copied ? <Check size={14} /> : <Copy size={14} />}
                                        </button>
                                        <a href={getExplorerUrl('address', address)} target="_blank" rel="noopener noreferrer" className="btn btn-ghost" style={{ padding: '4px' }}>
                                            <ExternalLink size={14} />
                                        </a>
                                    </div>
                                </div>

                                <div className="flex items-center justify-between">
                                    <span style={{ color: 'var(--text-muted)' }}>Total Supply</span>
                                    <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>{token.supply}</span>
                                </div>

                                <div className="flex items-center justify-between">
                                    <span style={{ color: 'var(--text-muted)' }}>Decimals</span>
                                    <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>{token.decimals}</span>
                                </div>

                                <div className="flex items-center justify-between">
                                    <span style={{ color: 'var(--text-muted)' }}>Creator</span>
                                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem' }}>{formatAddress(token.creator)}</span>
                                </div>

                                {token.createdAt && (
                                    <div className="flex items-center justify-between">
                                        <span style={{ color: 'var(--text-muted)' }}>Created</span>
                                        <span style={{ fontSize: '0.875rem' }}>{token.createdAt.toLocaleDateString()}</span>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Liquidity Lock */}
                        {lock && (
                            <div className="card">
                                <h3 className="flex items-center gap-2" style={{ marginBottom: 'var(--space-4)', fontSize: '1rem' }}>
                                    <Lock size={16} />
                                    Creator Commitment
                                </h3>
                                <div style={{ display: 'grid', gap: 'var(--space-3)' }}>
                                    <div className="flex items-center justify-between">
                                        <span style={{ color: 'var(--text-muted)' }}>Locked SOL</span>
                                        <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--accent)' }}>
                                            {(Number(lock.amount) / LAMPORTS_PER_SOL).toFixed(2)} SOL
                                        </span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span style={{ color: 'var(--text-muted)' }}>Unlock Date</span>
                                        <span style={{ fontFamily: 'var(--font-mono)' }}>
                                            {new Date(Number(lock.unlockDate) * 1000).toLocaleDateString()}
                                        </span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <span style={{ color: 'var(--text-muted)' }}>Status</span>
                                        <span style={{
                                            fontFamily: 'var(--font-mono)',
                                            fontWeight: 600,
                                            color: lock.isClaimed ? 'var(--text-muted)' : (Date.now() / 1000 > Number(lock.unlockDate) ? 'var(--warning)' : 'var(--accent)')
                                        }}>
                                            {lock.isClaimed ? '✓ Claimed' : (Date.now() / 1000 > Number(lock.unlockDate) ? '🔓 Unlocked' : '🔒 Locked')}
                                        </span>
                                    </div>
                                </div>
                                <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: 'var(--space-3)', fontStyle: 'italic' }}>
                                    This is the creator&apos;s committed SOL, held in escrow until the unlock date.
                                </p>
                            </div>
                        )}
                    </div>

                    {/* Right Column - Trading Panel */}
                    <div>
                        {/* User Balance */}
                        {connected && (
                            <div className="card" style={{ marginBottom: 'var(--space-4)' }}>
                                <div className="flex items-center justify-between">
                                    <span style={{ color: 'var(--text-muted)' }}>Your Balance</span>
                                    <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--text-light)', fontSize: '1.125rem' }}>
                                        {userBalance || '0'} {token?.symbol || ''}
                                    </span>
                                </div>
                                {/* Show value in SOL */}
                                {pool && userTokenBalance > BigInt(0) && (
                                    <div style={{ marginTop: 'var(--space-3)', paddingTop: 'var(--space-3)', borderTop: '1px solid var(--border)' }}>
                                        <div className="flex items-center justify-between" style={{ marginBottom: 'var(--space-2)' }}>
                                            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Value</span>
                                            <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--accent)' }}>
                                                ≈ {userTokenValueSol.toFixed(4)} SOL
                                            </span>
                                        </div>
                                        <button
                                            className="btn btn-primary"
                                            style={{ width: '100%', marginTop: 'var(--space-2)', background: 'var(--error)' }}
                                            onClick={() => {
                                                setTradeType('sell');
                                                setTradeAmount((Number(userTokenBalance) / Math.pow(10, token?.decimals || 9)).toString());
                                            }}
                                        >
                                            Sell All for ≈ {userTokenValueSol.toFixed(4)} SOL
                                        </button>
                                    </div>
                                )}
                                {isCreator && (
                                    <p style={{ fontSize: '0.75rem', color: 'var(--accent)', marginTop: 'var(--space-2)' }}>
                                        ✨ You are the creator
                                    </p>
                                )}
                            </div>
                        )}

                        {/* Trading Panel */}
                        {pool ? (
                            <div className="card">
                                <h3 className="flex items-center gap-2" style={{ marginBottom: 'var(--space-4)', fontSize: '1rem' }}>
                                    <Zap size={16} /> Trade {token.symbol}
                                </h3>

                                {/* Buy/Sell Toggle */}
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px', marginBottom: 'var(--space-4)', background: 'var(--bg-dark)', borderRadius: 'var(--radius-md)', padding: '4px' }}>
                                    <button
                                        onClick={() => setTradeType('buy')}
                                        style={{
                                            padding: 'var(--space-3)',
                                            borderRadius: 'var(--radius-sm)',
                                            border: 'none',
                                            cursor: 'pointer',
                                            fontWeight: 600,
                                            background: tradeType === 'buy' ? 'var(--accent)' : 'transparent',
                                            color: tradeType === 'buy' ? 'var(--bg-dark)' : 'var(--text-muted)',
                                        }}
                                    >
                                        <TrendingUp size={14} style={{ marginRight: '4px' }} /> Buy
                                    </button>
                                    <button
                                        onClick={() => setTradeType('sell')}
                                        style={{
                                            padding: 'var(--space-3)',
                                            borderRadius: 'var(--radius-sm)',
                                            border: 'none',
                                            cursor: 'pointer',
                                            fontWeight: 600,
                                            background: tradeType === 'sell' ? 'var(--error)' : 'transparent',
                                            color: tradeType === 'sell' ? 'white' : 'var(--text-muted)',
                                        }}
                                    >
                                        <TrendingDown size={14} style={{ marginRight: '4px' }} /> Sell
                                    </button>
                                </div>

                                {/* Amount Input */}
                                <div style={{ marginBottom: 'var(--space-4)' }}>
                                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '4px', display: 'block' }}>
                                        {tradeType === 'buy' ? 'SOL Amount' : `${token.symbol} Amount`}
                                    </label>
                                    <input
                                        type="number"
                                        className="input"
                                        placeholder="0.0"
                                        value={tradeAmount}
                                        onChange={(e) => setTradeAmount(e.target.value)}
                                        style={{ width: '100%' }}
                                    />
                                </div>

                                {/* Preview */}
                                {preview && (
                                    <div style={{
                                        background: 'var(--bg-dark)',
                                        borderRadius: 'var(--radius-md)',
                                        padding: 'var(--space-4)',
                                        marginBottom: 'var(--space-4)'
                                    }}>
                                        <div className="flex items-center justify-between" style={{ marginBottom: '8px' }}>
                                            <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>You Pay</span>
                                            <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
                                                {preview.input.toFixed(4)} {preview.inputSymbol}
                                            </span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>You Receive</span>
                                            <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--accent)' }}>
                                                {preview.output.toFixed(4)} {preview.outputSymbol}
                                            </span>
                                        </div>
                                    </div>
                                )}

                                {/* Error/Success Messages */}
                                {tradeError && (
                                    <div style={{ padding: 'var(--space-3)', background: 'rgba(239, 68, 68, 0.1)', borderRadius: 'var(--radius-sm)', marginBottom: 'var(--space-4)', color: 'var(--error)', fontSize: '0.875rem' }}>
                                        {tradeError}
                                    </div>
                                )}
                                {tradeSuccess && (
                                    <div style={{ padding: 'var(--space-3)', background: 'rgba(46, 255, 155, 0.1)', borderRadius: 'var(--radius-sm)', marginBottom: 'var(--space-4)', color: 'var(--accent)', fontSize: '0.875rem' }}>
                                        {tradeSuccess}
                                    </div>
                                )}

                                {/* Trade Button */}
                                <button
                                    onClick={handleTrade}
                                    disabled={!connected || !tradeAmount || trading}
                                    className="btn"
                                    style={{
                                        width: '100%',
                                        padding: 'var(--space-4)',
                                        background: tradeType === 'buy' ? 'var(--accent)' : 'var(--error)',
                                        color: tradeType === 'buy' ? 'var(--bg-dark)' : 'white',
                                        fontWeight: 700,
                                        opacity: (!connected || !tradeAmount || trading) ? 0.5 : 1,
                                    }}
                                >
                                    {trading ? (
                                        <><Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Processing...</>
                                    ) : !connected ? (
                                        'Connect Wallet'
                                    ) : (
                                        `${tradeType === 'buy' ? 'Buy' : 'Sell'} ${token.symbol}`
                                    )}
                                </button>
                            </div>
                        ) : (
                            /* No Pool - Show Create Pool or Message */
                            <div className="card">
                                <div style={{ textAlign: 'center', padding: 'var(--space-6)' }}>
                                    <TrendingUp size={48} style={{ color: 'var(--text-muted)', marginBottom: 'var(--space-4)' }} />
                                    <h3 style={{ marginBottom: 'var(--space-2)' }}>No Trading Pool</h3>
                                    <p style={{ color: 'var(--text-muted)', marginBottom: 'var(--space-6)' }}>
                                        {isCreator ? 'Create a liquidity pool to enable trading' : 'Trading is not yet available for this token'}
                                    </p>

                                    {isCreator && !showCreatePool && (
                                        <button onClick={() => setShowCreatePool(true)} className="btn btn-primary">
                                            Create Trading Pool
                                        </button>
                                    )}

                                    {isCreator && showCreatePool && (
                                        <div style={{ textAlign: 'left' }}>
                                            <div style={{ marginBottom: 'var(--space-4)' }}>
                                                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '4px', display: 'block' }}>
                                                    Tokens to Add to Pool
                                                </label>
                                                <input
                                                    type="number"
                                                    className="input"
                                                    placeholder="e.g. 100000000"
                                                    value={poolTokenAmount}
                                                    onChange={(e) => setPoolTokenAmount(e.target.value)}
                                                    style={{ width: '100%' }}
                                                />
                                            </div>
                                            <div style={{ marginBottom: 'var(--space-4)' }}>
                                                <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '4px', display: 'block' }}>
                                                    SOL to Add to Pool
                                                </label>
                                                <input
                                                    type="number"
                                                    className="input"
                                                    placeholder="e.g. 1"
                                                    value={poolSolAmount}
                                                    onChange={(e) => setPoolSolAmount(e.target.value)}
                                                    style={{ width: '100%' }}
                                                />
                                            </div>

                                            {tradeError && (
                                                <div style={{ padding: 'var(--space-3)', background: 'rgba(239, 68, 68, 0.1)', borderRadius: 'var(--radius-sm)', marginBottom: 'var(--space-4)', color: 'var(--error)', fontSize: '0.875rem' }}>
                                                    {tradeError}
                                                </div>
                                            )}

                                            <div className="flex items-center gap-2">
                                                <button onClick={() => setShowCreatePool(false)} className="btn btn-ghost" style={{ flex: 1 }}>
                                                    Cancel
                                                </button>
                                                <button
                                                    onClick={handleCreatePool}
                                                    disabled={!poolTokenAmount || !poolSolAmount || creatingPool}
                                                    className="btn btn-primary"
                                                    style={{ flex: 1 }}
                                                >
                                                    {creatingPool ? <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> : 'Create Pool'}
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Refresh Button */}
                        <button
                            onClick={fetchAllData}
                            className="btn btn-ghost"
                            style={{ width: '100%', marginTop: 'var(--space-4)' }}
                        >
                            <RefreshCw size={14} /> Refresh Data
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
