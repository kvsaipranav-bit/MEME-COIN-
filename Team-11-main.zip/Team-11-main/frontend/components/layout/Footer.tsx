'use client';

import Link from 'next/link';

export function Footer() {
    return (
        <footer className="footer" style={{ borderTop: '1px solid var(--border)' }}>
            <div className="container">
                <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: 'var(--space-12) 0',
                    textAlign: 'center'
                }}>
                    {/* Brand Section */}
                    <div className="flex items-center gap-3 mb-6">
                        <div style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: 'var(--radius-sm)',
                            background: 'var(--bg-dark)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <span style={{
                                color: 'var(--accent)',
                                fontFamily: 'var(--font-mono)',
                                fontWeight: 700,
                                fontSize: '14px'
                            }}>
                                T11
                            </span>
                        </div>
                        <span style={{
                            fontFamily: 'var(--font-mono)',
                            fontSize: '1rem',
                            fontWeight: 700,
                            letterSpacing: '-0.02em'
                        }}>
                            Team 11
                        </span>
                    </div>

                    <p style={{
                        fontSize: '0.875rem',
                        lineHeight: '1.6',
                        color: 'var(--text-secondary)',
                        maxWidth: '400px',
                        marginBottom: 'var(--space-8)'
                    }}>
                        Create and launch meme coins on Solana Devnet with built-in liquidity lock.
                        Transparent, secure, and fast.
                    </p>

                    {/* Status Badge */}
                    <div className="flex items-center gap-2 mb-8">
                        <span style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            background: '#10B981', // Green dot
                            boxShadow: '0 0 8px rgba(16, 185, 129, 0.4)',
                            animation: 'pulse-dot 2s ease-in-out infinite'
                        }} />
                        <span style={{
                            fontFamily: 'var(--font-mono)',
                            fontSize: '0.75rem',
                            fontWeight: 600,
                            textTransform: 'uppercase',
                            letterSpacing: '0.05em',
                            color: 'var(--text-secondary)'
                        }}>
                            Solana Devnet Operational
                        </span>
                    </div>

                    {/* Bottom Bar */}
                    <div style={{
                        width: '100%',
                        maxWidth: '400px',
                        paddingTop: 'var(--space-8)',
                        borderTop: '1px solid var(--border)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center', // Centered nicely since icons are gone
                        gap: 'var(--space-4)'
                    }}>
                        <p style={{
                            fontFamily: 'var(--font-mono)',
                            fontSize: '0.8125rem',
                            fontWeight: 500,
                            color: 'var(--text-muted)'
                        }}>
                            © 2026 Team 11
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    );
}
