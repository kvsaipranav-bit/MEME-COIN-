'use client';

import Link from 'next/link';
import { Lock, Clock, ExternalLink, TrendingUp } from 'lucide-react';
import { Countdown } from '../ui/Countdown';

export interface TokenCardProps {
    address: string;
    name: string;
    symbol: string;
    logoUrl?: string | null;
    creator: string;
    initialSupply: string;
    liquidityLocked: boolean;
    lockAmount?: string;
    unlockDate?: string;
    createdAt: string;
    isActive?: boolean;
}

function formatAddress(address: string): string {
    if (address.length <= 10) return address;
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
}

function isExpired(unlockDate: string): boolean {
    return new Date(unlockDate) <= new Date();
}

export function TokenCard({
    address,
    name,
    symbol,
    logoUrl,
    creator,
    initialSupply,
    liquidityLocked,
    lockAmount,
    unlockDate,
    createdAt,
    isActive = true
}: TokenCardProps) {
    const expired = unlockDate ? isExpired(unlockDate) : false;

    return (
        <Link
            href={`/token/${address}`}
            className="card"
            style={{
                display: 'block',
                textDecoration: 'none',
                transition: 'all 0.2s',
                opacity: isActive ? 1 : 0.6,
            }}
        >
            {/* Header */}
            <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: 'var(--space-4)',
                marginBottom: 'var(--space-4)'
            }}>
                {/* Logo */}
                <div style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: 'var(--radius-md)',
                    background: logoUrl
                        ? `url(${logoUrl}) center/cover`
                        : 'linear-gradient(135deg, var(--accent) 0%, var(--accent-darker) 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.25rem',
                    fontWeight: 700,
                    color: 'var(--bg-dark)',
                    fontFamily: 'var(--font-mono)',
                    flexShrink: 0
                }}>
                    {!logoUrl && symbol.charAt(0)}
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="flex items-center gap-2" style={{ marginBottom: '2px' }}>
                        <h4 style={{
                            margin: 0,
                            textTransform: 'none',
                            fontSize: '1rem',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                        }}>
                            {name}
                        </h4>
                        {!isActive && (
                            <span className="badge badge-error" style={{ fontSize: '0.625rem' }}>
                                Inactive
                            </span>
                        )}
                    </div>
                    <span style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.8125rem',
                        color: 'var(--accent)',
                        fontWeight: 600
                    }}>
                        ${symbol}
                    </span>
                </div>

                {/* Lock Status */}
                {liquidityLocked && (
                    <div style={{
                        padding: '4px 8px',
                        borderRadius: 'var(--radius-sm)',
                        background: expired
                            ? 'rgba(46, 255, 155, 0.15)'
                            : 'var(--bg-dark)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        fontSize: '0.75rem',
                        fontWeight: 600,
                        color: expired ? 'var(--accent)' : 'var(--text-light)'
                    }}>
                        {expired ? (
                            <>✓ Unlocked</>
                        ) : (
                            <>
                                <Lock size={12} />
                                Locked
                            </>
                        )}
                    </div>
                )}
            </div>

            {/* Stats */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: 'var(--space-3)',
                marginBottom: 'var(--space-4)'
            }}>
                <div>
                    <p style={{
                        fontSize: '0.6875rem',
                        color: 'var(--text-muted)',
                        textTransform: 'uppercase',
                        marginBottom: '2px'
                    }}>
                        Supply
                    </p>
                    <p style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.8125rem',
                        fontWeight: 600,
                        margin: 0
                    }}>
                        {initialSupply}
                    </p>
                </div>
                <div>
                    <p style={{
                        fontSize: '0.6875rem',
                        color: 'var(--text-muted)',
                        textTransform: 'uppercase',
                        marginBottom: '2px'
                    }}>
                        Creator
                    </p>
                    <p style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.8125rem',
                        fontWeight: 600,
                        margin: 0
                    }}>
                        {formatAddress(creator)}
                    </p>
                </div>
            </div>

            {/* Lock Info */}
            {liquidityLocked && lockAmount && unlockDate && (
                <div style={{
                    background: 'var(--bg-secondary)',
                    borderRadius: 'var(--radius-sm)',
                    padding: 'var(--space-3)',
                    marginBottom: 'var(--space-4)'
                }}>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: 'var(--space-2)'
                    }}>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            Locked
                        </span>
                        <span style={{
                            fontFamily: 'var(--font-mono)',
                            fontSize: '0.8125rem',
                            fontWeight: 600,
                            color: 'var(--accent)'
                        }}>
                            {lockAmount}
                        </span>
                    </div>
                    {!expired && unlockDate !== '-' && (
                        <div style={{ textAlign: 'center' }}>
                            {/* Only show countdown if unlockDate is a valid ISO date */}
                            {unlockDate.includes('T') ? (
                                <Countdown
                                    targetDate={unlockDate}
                                    size="sm"
                                    variant="compact"
                                />
                            ) : (
                                <span style={{
                                    fontFamily: 'var(--font-mono)',
                                    fontSize: '0.8125rem',
                                    color: 'var(--text-muted)'
                                }}>
                                    Unlocks: {unlockDate}
                                </span>
                            )}
                        </div>
                    )}
                </div>
            )}

            {/* Footer */}
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                fontSize: '0.75rem',
                color: 'var(--text-muted)'
            }}>
                <span className="flex items-center gap-1">
                    <Clock size={12} />
                    {createdAt}
                </span>
                <span className="flex items-center gap-1">
                    View Details
                    <ExternalLink size={12} />
                </span>
            </div>
        </Link>
    );
}

// Skeleton loader for TokenCard
export function TokenCardSkeleton() {
    return (
        <div
            className="card"
            style={{ animation: 'pulse 2s infinite' }}
        >
            <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: 'var(--space-4)',
                marginBottom: 'var(--space-4)'
            }}>
                <div style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: 'var(--radius-md)',
                    background: 'var(--bg-secondary)'
                }} />
                <div style={{ flex: 1 }}>
                    <div style={{
                        width: '70%',
                        height: '16px',
                        background: 'var(--bg-secondary)',
                        borderRadius: 'var(--radius-sm)',
                        marginBottom: '8px'
                    }} />
                    <div style={{
                        width: '40%',
                        height: '14px',
                        background: 'var(--bg-secondary)',
                        borderRadius: 'var(--radius-sm)'
                    }} />
                </div>
            </div>
            <div style={{
                height: '60px',
                background: 'var(--bg-secondary)',
                borderRadius: 'var(--radius-sm)'
            }} />
        </div>
    );
}
