import { clsx } from 'clsx';

interface BadgeProps {
    variant?: 'success' | 'warning' | 'error' | 'neutral' | 'info';
    children: React.ReactNode;
    className?: string;
}

export function Badge({ variant = 'neutral', children, className }: BadgeProps) {
    const variants = {
        success: 'bg-[var(--accent-subtle)] text-[var(--accent)] border-[var(--accent)]',
        warning: 'bg-[rgba(255,184,0,0.1)] text-[var(--warning)] border-[var(--warning)]',
        error: 'bg-[rgba(255,68,68,0.1)] text-[var(--error)] border-[var(--error)]',
        neutral: 'bg-[var(--bg-tertiary)] text-[var(--text-secondary)] border-[var(--border)]',
        info: 'bg-[rgba(74,158,255,0.1)] text-[var(--info)] border-[var(--info)]',
    };

    return (
        <span
            className={clsx(
                `
          inline-flex items-center gap-1
          font-[var(--font-mono)] text-[10px] font-semibold
          uppercase tracking-wide
          px-2 py-0.5
          rounded-sm border
        `,
                variants[variant],
                className
            )}
        >
            {children}
        </span>
    );
}
