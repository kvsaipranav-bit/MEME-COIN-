import { ButtonHTMLAttributes, forwardRef } from 'react';
import { clsx } from 'clsx';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: 'primary' | 'accent' | 'ghost' | 'danger';
    size?: 'sm' | 'md' | 'lg';
    loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
    ({ className, variant = 'primary', size = 'md', loading, disabled, children, ...props }, ref) => {
        const baseStyles = `
      font-[var(--font-mono)] font-semibold uppercase tracking-wide
      inline-flex items-center justify-center gap-2
      rounded-sm cursor-pointer
      transition-all duration-150
      disabled:opacity-50 disabled:cursor-not-allowed
    `;

        const variants = {
            primary: `
        bg-[var(--bg-secondary)] border border-[var(--border)]
        text-[var(--text-primary)]
        shadow-[0_4px_0_0_var(--border)]
        hover:translate-y-[2px] hover:shadow-[0_2px_0_0_var(--border)]
        active:translate-y-[4px] active:shadow-none
      `,
            accent: `
        bg-[var(--accent)] border-none
        text-[var(--bg-primary)]
        shadow-[0_4px_0_0_var(--accent-dark)]
        hover:translate-y-[2px] hover:shadow-[0_2px_0_0_var(--accent-dark)]
        active:translate-y-[4px] active:shadow-none
      `,
            ghost: `
        bg-transparent border border-[var(--accent)]
        text-[var(--accent)]
        hover:border-[var(--text-primary)] hover:text-[var(--text-primary)]
      `,
            danger: `
        bg-[var(--error)] border-none
        text-white
        shadow-[0_4px_0_0_#cc3636]
        hover:translate-y-[2px] hover:shadow-[0_2px_0_0_#cc3636]
        active:translate-y-[4px] active:shadow-none
      `,
        };

        const sizes = {
            sm: 'px-3 py-1.5 text-xs',
            md: 'px-4 py-2 text-sm',
            lg: 'px-6 py-3 text-base',
        };

        return (
            <button
                ref={ref}
                className={clsx(baseStyles, variants[variant], sizes[size], className)}
                disabled={disabled || loading}
                {...props}
            >
                {loading && (
                    <span className="animate-spin">⟳</span>
                )}
                {children}
            </button>
        );
    }
);

Button.displayName = 'Button';
