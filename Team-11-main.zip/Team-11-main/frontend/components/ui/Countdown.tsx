'use client';

import { useState, useEffect } from 'react';

interface CountdownProps {
    targetDate: string | Date;
    onComplete?: () => void;
    showLabels?: boolean;
    size?: 'sm' | 'md' | 'lg';
    variant?: 'default' | 'compact' | 'card';
}

interface TimeRemaining {
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    expired: boolean;
}

function calculateTimeRemaining(targetDate: string | Date): TimeRemaining {
    const target = new Date(targetDate);
    const now = new Date();
    const diff = target.getTime() - now.getTime();

    if (diff <= 0) {
        return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true };
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    return { days, hours, minutes, seconds, expired: false };
}

export function Countdown({
    targetDate,
    onComplete,
    showLabels = true,
    size = 'md',
    variant = 'default'
}: CountdownProps) {
    const [time, setTime] = useState<TimeRemaining>(calculateTimeRemaining(targetDate));

    useEffect(() => {
        const timer = setInterval(() => {
            const newTime = calculateTimeRemaining(targetDate);
            setTime(newTime);

            if (newTime.expired && onComplete) {
                onComplete();
                clearInterval(timer);
            }
        }, 1000);

        return () => clearInterval(timer);
    }, [targetDate, onComplete]);

    if (time.expired) {
        return (
            <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 'var(--space-2)',
                color: 'var(--accent)',
                fontWeight: 600,
                fontFamily: 'var(--font-mono)',
            }}>
                ✓ Unlocked
            </div>
        );
    }

    const sizes = {
        sm: { number: '1rem', label: '0.625rem', gap: 'var(--space-2)' },
        md: { number: '1.5rem', label: '0.75rem', gap: 'var(--space-3)' },
        lg: { number: '2.5rem', label: '0.875rem', gap: 'var(--space-4)' },
    };

    const currentSize = sizes[size];

    const units = [
        { value: time.days, label: 'Days' },
        { value: time.hours, label: 'Hours' },
        { value: time.minutes, label: 'Mins' },
        { value: time.seconds, label: 'Secs' },
    ];

    if (variant === 'compact') {
        return (
            <span style={{
                fontFamily: 'var(--font-mono)',
                fontWeight: 600,
                fontSize: currentSize.number,
            }}>
                {String(time.days).padStart(2, '0')}:
                {String(time.hours).padStart(2, '0')}:
                {String(time.minutes).padStart(2, '0')}:
                {String(time.seconds).padStart(2, '0')}
            </span>
        );
    }

    if (variant === 'card') {
        return (
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(4, 1fr)',
                gap: currentSize.gap,
            }}>
                {units.map((unit) => (
                    <div
                        key={unit.label}
                        style={{
                            background: 'rgba(255,255,255,0.05)',
                            borderRadius: 'var(--radius-md)',
                            padding: 'var(--space-3)',
                            textAlign: 'center',
                        }}
                    >
                        <p style={{
                            fontSize: currentSize.number,
                            fontWeight: 700,
                            fontFamily: 'var(--font-mono)',
                            margin: 0,
                            lineHeight: 1.2,
                        }}>
                            {String(unit.value).padStart(2, '0')}
                        </p>
                        {showLabels && (
                            <p style={{
                                fontSize: currentSize.label,
                                textTransform: 'uppercase',
                                color: 'var(--text-muted)',
                                margin: 0,
                                marginTop: '4px',
                            }}>
                                {unit.label}
                            </p>
                        )}
                    </div>
                ))}
            </div>
        );
    }

    // Default variant
    return (
        <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: currentSize.gap,
        }}>
            {units.map((unit, index) => (
                <div key={unit.label} style={{ display: 'flex', alignItems: 'center', gap: currentSize.gap }}>
                    <div style={{ textAlign: 'center' }}>
                        <p style={{
                            fontSize: currentSize.number,
                            fontWeight: 700,
                            fontFamily: 'var(--font-mono)',
                            margin: 0,
                            lineHeight: 1,
                        }}>
                            {String(unit.value).padStart(2, '0')}
                        </p>
                        {showLabels && (
                            <p style={{
                                fontSize: currentSize.label,
                                textTransform: 'uppercase',
                                color: 'var(--text-muted)',
                                margin: 0,
                                marginTop: '4px',
                            }}>
                                {unit.label}
                            </p>
                        )}
                    </div>
                    {index < units.length - 1 && (
                        <span style={{
                            fontSize: currentSize.number,
                            fontWeight: 700,
                            color: 'var(--text-muted)',
                            marginBottom: showLabels ? '20px' : 0,
                        }}>
                            :
                        </span>
                    )}
                </div>
            ))}
        </div>
    );
}

// Helper hook for countdown state
export function useCountdown(targetDate: string | Date) {
    const [time, setTime] = useState<TimeRemaining>(calculateTimeRemaining(targetDate));

    useEffect(() => {
        const timer = setInterval(() => {
            setTime(calculateTimeRemaining(targetDate));
        }, 1000);

        return () => clearInterval(timer);
    }, [targetDate]);

    return time;
}
