import { InputHTMLAttributes, TextareaHTMLAttributes, forwardRef } from 'react';
import { clsx } from 'clsx';

// Input
interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
    error?: string;
    label?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
    ({ className, error, label, ...props }, ref) => {
        return (
            <div className="w-full">
                {label && (
                    <label className="block font-[var(--font-mono)] text-xs font-semibold uppercase tracking-wide text-[var(--text-secondary)] mb-2">
                        {label}
                    </label>
                )}
                <input
                    ref={ref}
                    className={clsx(
                        `
              w-full font-[var(--font-mono)] text-sm
              px-4 py-3
              bg-[var(--bg-tertiary)] border border-[var(--border)]
              rounded-sm
              text-[var(--text-primary)]
              placeholder:text-[var(--text-muted)]
              transition-all duration-150
              focus:outline-none focus:border-[var(--accent)]
              focus:shadow-[0_0_0_2px_var(--accent-glow)]
              disabled:opacity-50 disabled:cursor-not-allowed
            `,
                        error && 'border-[var(--error)] focus:border-[var(--error)] focus:shadow-[0_0_0_2px_rgba(255,68,68,0.2)]',
                        className
                    )}
                    {...props}
                />
                {error && (
                    <p className="mt-1 text-xs text-[var(--error)]">{error}</p>
                )}
            </div>
        );
    }
);

Input.displayName = 'Input';

// Textarea
interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
    error?: string;
    label?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
    ({ className, error, label, ...props }, ref) => {
        return (
            <div className="w-full">
                {label && (
                    <label className="block font-[var(--font-mono)] text-xs font-semibold uppercase tracking-wide text-[var(--text-secondary)] mb-2">
                        {label}
                    </label>
                )}
                <textarea
                    ref={ref}
                    className={clsx(
                        `
              w-full min-h-[100px] font-[var(--font-mono)] text-sm
              px-4 py-3
              bg-[var(--bg-tertiary)] border border-[var(--border)]
              rounded-sm
              text-[var(--text-primary)]
              placeholder:text-[var(--text-muted)]
              transition-all duration-150
              focus:outline-none focus:border-[var(--accent)]
              focus:shadow-[0_0_0_2px_var(--accent-glow)]
              disabled:opacity-50 disabled:cursor-not-allowed
              resize-y
            `,
                        error && 'border-[var(--error)]',
                        className
                    )}
                    {...props}
                />
                {error && (
                    <p className="mt-1 text-xs text-[var(--error)]">{error}</p>
                )}
            </div>
        );
    }
);

Textarea.displayName = 'Textarea';
