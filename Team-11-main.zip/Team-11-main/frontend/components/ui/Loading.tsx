import { clsx } from 'clsx';

interface LoadingProps {
    size?: 'sm' | 'md' | 'lg';
    className?: string;
}

export function Loading({ size = 'md', className }: LoadingProps) {
    const sizes = {
        sm: 'w-4 h-4 border-2',
        md: 'w-8 h-8 border-3',
        lg: 'w-12 h-12 border-4',
    };

    return (
        <div
            className={clsx(
                'animate-spin rounded-full border-[var(--accent)] border-t-transparent',
                sizes[size],
                className
            )}
        />
    );
}

// Full page loading
export function LoadingPage() {
    return (
        <div className="flex items-center justify-center min-h-[60vh]">
            <div className="text-center">
                <Loading size="lg" className="mx-auto mb-4" />
                <p className="mono text-sm text-[var(--text-secondary)]">Loading...</p>
            </div>
        </div>
    );
}

// Skeleton loader
interface SkeletonProps {
    className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
    return (
        <div
            className={clsx(
                'animate-pulse bg-[var(--bg-tertiary)] rounded-sm',
                className
            )}
        />
    );
}
