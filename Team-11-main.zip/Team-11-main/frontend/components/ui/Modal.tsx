'use client';

import { useEffect, useRef, ReactNode } from 'react';
import { X } from 'lucide-react';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title?: string;
    children: ReactNode;
    size?: 'sm' | 'md' | 'lg' | 'xl';
    showCloseButton?: boolean;
    closeOnOverlayClick?: boolean;
    closeOnEscape?: boolean;
}

const sizeClasses = {
    sm: '400px',
    md: '500px',
    lg: '640px',
    xl: '800px',
};

export function Modal({
    isOpen,
    onClose,
    title,
    children,
    size = 'md',
    showCloseButton = true,
    closeOnOverlayClick = true,
    closeOnEscape = true,
}: ModalProps) {
    const modalRef = useRef<HTMLDivElement>(null);

    // Handle escape key
    useEffect(() => {
        if (!closeOnEscape) return;

        const handleEscape = (e: KeyboardEvent) => {
            if (e.key === 'Escape' && isOpen) {
                onClose();
            }
        };

        document.addEventListener('keydown', handleEscape);
        return () => document.removeEventListener('keydown', handleEscape);
    }, [isOpen, onClose, closeOnEscape]);

    // Prevent body scroll when modal is open
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }

        return () => {
            document.body.style.overflow = '';
        };
    }, [isOpen]);

    // Focus trap
    useEffect(() => {
        if (isOpen && modalRef.current) {
            modalRef.current.focus();
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleOverlayClick = (e: React.MouseEvent) => {
        if (closeOnOverlayClick && e.target === e.currentTarget) {
            onClose();
        }
    };

    return (
        <div
            className="modal-overlay"
            onClick={handleOverlayClick}
            style={{
                position: 'fixed',
                inset: 0,
                zIndex: 1000,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: 'var(--space-4)',
                background: 'rgba(0, 0, 0, 0.6)',
                backdropFilter: 'blur(4px)',
                animation: 'fadeIn 0.2s ease-out',
            }}
        >
            <div
                ref={modalRef}
                role="dialog"
                aria-modal="true"
                aria-labelledby={title ? 'modal-title' : undefined}
                tabIndex={-1}
                className="modal-content"
                style={{
                    background: 'var(--bg-card)',
                    border: '1px solid var(--border)',
                    borderRadius: 'var(--radius-xl)',
                    width: '100%',
                    maxWidth: sizeClasses[size],
                    maxHeight: '90vh',
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
                    animation: 'slideUp 0.3s ease-out',
                }}
            >
                {/* Header */}
                {(title || showCloseButton) && (
                    <div
                        className="modal-header"
                        style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            padding: 'var(--space-6)',
                            borderBottom: '1px solid var(--border)',
                        }}
                    >
                        {title && (
                            <h3
                                id="modal-title"
                                style={{
                                    fontFamily: 'var(--font-mono)',
                                    fontSize: '1.125rem',
                                    fontWeight: 700,
                                    textTransform: 'uppercase',
                                    letterSpacing: '-0.02em',
                                    margin: 0,
                                }}
                            >
                                {title}
                            </h3>
                        )}
                        {showCloseButton && (
                            <button
                                onClick={onClose}
                                aria-label="Close modal"
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                    padding: 'var(--space-2)',
                                    borderRadius: 'var(--radius-sm)',
                                    color: 'var(--text-muted)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    transition: 'all var(--transition-fast)',
                                    marginLeft: 'auto',
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.color = 'var(--text-primary)';
                                    e.currentTarget.style.background = 'var(--bg-secondary)';
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.color = 'var(--text-muted)';
                                    e.currentTarget.style.background = 'none';
                                }}
                            >
                                <X size={20} />
                            </button>
                        )}
                    </div>
                )}

                {/* Body */}
                <div
                    className="modal-body"
                    style={{
                        padding: 'var(--space-6)',
                        overflowY: 'auto',
                        flex: 1,
                    }}
                >
                    {children}
                </div>
            </div>
        </div>
    );
}

// Modal Footer component for action buttons
interface ModalFooterProps {
    children: ReactNode;
    align?: 'left' | 'center' | 'right';
}

export function ModalFooter({ children, align = 'right' }: ModalFooterProps) {
    const alignMap = {
        left: 'flex-start',
        center: 'center',
        right: 'flex-end',
    };

    return (
        <div
            className="modal-footer"
            style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: alignMap[align],
                gap: 'var(--space-3)',
                padding: 'var(--space-6)',
                paddingTop: 0,
            }}
        >
            {children}
        </div>
    );
}

// Confirmation Modal - a preset for common use cases
interface ConfirmModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    variant?: 'default' | 'danger';
    loading?: boolean;
}

export function ConfirmModal({
    isOpen,
    onClose,
    onConfirm,
    title,
    message,
    confirmText = 'Confirm',
    cancelText = 'Cancel',
    variant = 'default',
    loading = false,
}: ConfirmModalProps) {
    return (
        <Modal isOpen={isOpen} onClose={onClose} title={title} size="sm">
            <p style={{ color: 'var(--text-secondary)', marginBottom: 'var(--space-6)' }}>
                {message}
            </p>
            <ModalFooter>
                <button
                    className="btn btn-ghost"
                    onClick={onClose}
                    disabled={loading}
                >
                    {cancelText}
                </button>
                <button
                    className={`btn ${variant === 'danger' ? 'btn-primary' : 'btn-accent'}`}
                    onClick={onConfirm}
                    disabled={loading}
                    style={variant === 'danger' ? {
                        background: 'var(--error)',
                        boxShadow: '0 4px 0 0 #b91c1c',
                    } : undefined}
                >
                    {loading ? '▸ Processing...' : `▸ ${confirmText}`}
                </button>
            </ModalFooter>
        </Modal>
    );
}
