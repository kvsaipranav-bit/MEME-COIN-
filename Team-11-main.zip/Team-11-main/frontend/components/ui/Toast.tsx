'use client';

import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info' | 'warning';

interface Toast {
    id: string;
    type: ToastType;
    message: string;
    duration?: number;
}

interface ToastContextType {
    toasts: Toast[];
    addToast: (type: ToastType, message: string, duration?: number) => void;
    removeToast: (id: string) => void;
}

const ToastContext = createContext<ToastContextType>({
    toasts: [],
    addToast: () => { },
    removeToast: () => { },
});

export const useToast = () => useContext(ToastContext);

export function ToastProvider({ children }: { children: ReactNode }) {
    const [toasts, setToasts] = useState<Toast[]>([]);

    const removeToast = useCallback((id: string) => {
        setToasts(prev => prev.filter(t => t.id !== id));
    }, []);

    const addToast = useCallback((type: ToastType, message: string, duration = 5000) => {
        const id = Math.random().toString(36).slice(2);
        const toast: Toast = { id, type, message, duration };

        setToasts(prev => [...prev, toast]);

        if (duration > 0) {
            setTimeout(() => removeToast(id), duration);
        }
    }, [removeToast]);

    return (
        <ToastContext.Provider value={{ toasts, addToast, removeToast }}>
            {children}
            <ToastContainer />
        </ToastContext.Provider>
    );
}

function ToastContainer() {
    const { toasts, removeToast } = useToast();

    if (toasts.length === 0) return null;

    return (
        <div style={{
            position: 'fixed',
            bottom: '24px',
            right: '24px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            zIndex: 9999,
            maxWidth: '400px',
        }}>
            {toasts.map(toast => (
                <ToastItem key={toast.id} toast={toast} onClose={() => removeToast(toast.id)} />
            ))}
        </div>
    );
}

function ToastItem({ toast, onClose }: { toast: Toast; onClose: () => void }) {
    const icons = {
        success: <CheckCircle size={20} />,
        error: <AlertCircle size={20} />,
        info: <Info size={20} />,
        warning: <AlertTriangle size={20} />,
    };

    const colors = {
        success: { bg: 'rgba(46, 255, 155, 0.15)', border: 'var(--accent)', icon: 'var(--accent)' },
        error: { bg: 'rgba(239, 68, 68, 0.15)', border: 'var(--error)', icon: 'var(--error)' },
        info: { bg: 'rgba(59, 130, 246, 0.15)', border: 'var(--info)', icon: 'var(--info)' },
        warning: { bg: 'rgba(245, 158, 11, 0.15)', border: 'var(--warning)', icon: 'var(--warning)' },
    };

    const style = colors[toast.type];

    return (
        <div
            className="animate-slide-up"
            style={{
                background: 'var(--bg-primary)',
                border: `1px solid ${style.border}`,
                borderRadius: 'var(--radius-md)',
                padding: 'var(--space-4)',
                display: 'flex',
                alignItems: 'flex-start',
                gap: 'var(--space-3)',
                boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
            }}
        >
            <div style={{ color: style.icon, flexShrink: 0 }}>
                {icons[toast.type]}
            </div>
            <p style={{
                flex: 1,
                margin: 0,
                fontSize: '0.875rem',
                lineHeight: 1.5
            }}>
                {toast.message}
            </p>
            <button
                onClick={onClose}
                style={{
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    cursor: 'pointer',
                    color: 'var(--text-muted)',
                    flexShrink: 0,
                }}
            >
                <X size={16} />
            </button>
        </div>
    );
}

// Convenience hook for common toast operations
export function useNotifications() {
    const { addToast } = useToast();

    return {
        success: (message: string) => addToast('success', message),
        error: (message: string) => addToast('error', message),
        info: (message: string) => addToast('info', message),
        warning: (message: string) => addToast('warning', message),
    };
}
