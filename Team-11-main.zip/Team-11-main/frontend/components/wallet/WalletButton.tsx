'use client';

import { useWallet } from '@/providers/Providers';
import { Connection, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { Wallet, LogOut, Copy, Check } from 'lucide-react';
import { useState, useCallback, useEffect } from 'react';

// Devnet RPC URL
const DEVNET_RPC = process.env.NEXT_PUBLIC_SOLANA_RPC_URL || 'https://api.devnet.solana.com';

export function WalletButton() {
    const { publicKey, disconnect, connected, connecting, connect } = useWallet();
    const [copied, setCopied] = useState(false);
    const [balance, setBalance] = useState<number | null>(null);
    const [loadingBalance, setLoadingBalance] = useState(false);

    // Fetch SOL balance from Devnet
    const fetchBalance = useCallback(async () => {
        if (!publicKey) {
            setBalance(null);
            return;
        }

        setLoadingBalance(true);
        try {
            const connection = new Connection(DEVNET_RPC, 'confirmed');
            const balanceLamports = await connection.getBalance(publicKey);
            setBalance(balanceLamports / LAMPORTS_PER_SOL);
        } catch (error) {
            console.error('Failed to fetch balance:', error);
            setBalance(null);
        } finally {
            setLoadingBalance(false);
        }
    }, [publicKey]);

    // Fetch balance when wallet connects
    useEffect(() => {
        if (connected && publicKey) {
            fetchBalance();
            // Refresh balance every 30 seconds
            const interval = setInterval(fetchBalance, 30000);
            return () => clearInterval(interval);
        }
    }, [connected, publicKey, fetchBalance]);

    const handleClick = useCallback(() => {
        if (!connected) {
            connect();
        }
    }, [connected, connect]);

    const handleCopy = useCallback(async () => {
        if (publicKey) {
            await navigator.clipboard.writeText(publicKey.toBase58());
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    }, [publicKey]);

    const truncatedAddress = publicKey
        ? `${publicKey.toBase58().slice(0, 4)}...${publicKey.toBase58().slice(-4)}`
        : '';

    const formattedBalance = balance !== null
        ? balance.toFixed(4)
        : '-.----';

    if (connecting) {
        return (
            <button
                className="btn btn-ghost btn-sm"
                disabled
                style={{ opacity: 0.7 }}
            >
                <span style={{
                    display: 'inline-block',
                    animation: 'spin 1s linear infinite'
                }}>
                    ⟳
                </span>
                Connecting...
            </button>
        );
    }

    if (connected && publicKey) {
        return (
            <div className="flex items-center gap-2">
                {/* SOL Balance display */}
                <div
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                        padding: '8px 12px',
                        background: 'linear-gradient(135deg, rgba(46, 255, 155, 0.1) 0%, rgba(46, 255, 155, 0.05) 100%)',
                        border: '2px solid var(--accent)',
                        borderRadius: 'var(--radius-sm)',
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.8125rem',
                        fontWeight: 600,
                        color: 'var(--accent)'
                    }}
                    title={`Devnet Balance: ${formattedBalance} SOL`}
                >
                    {/* SOL Icon */}
                    <svg width="14" height="14" viewBox="0 0 101 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M100.48 69.38L83.12 87.74C82.74 88.12 82.21 88.34 81.66 88.34H1.46C0.44 88.34 -0.07 87.11 0.65 86.39L18.01 68.03C18.39 67.65 18.92 67.43 19.47 67.43H99.67C100.69 67.43 101.2 68.66 100.48 69.38Z" fill="currentColor" />
                        <path d="M100.48 1.95L83.12 -16.41C82.74 -16.79 82.21 -17.01 81.66 -17.01H1.46C0.44 -17.01 -0.07 -15.78 0.65 -15.06L18.01 3.30C18.39 3.68 18.92 3.90 19.47 3.90H99.67C100.69 3.90 101.2 2.67 100.48 1.95Z" fill="currentColor" transform="translate(0, 17)" />
                        <path d="M18.01 35.69L0.65 54.05C-0.07 54.77 0.44 56 1.46 56H81.66C82.21 56 82.74 55.78 83.12 55.40L100.48 37.04C101.2 36.32 100.69 35.09 99.67 35.09H19.47C18.92 35.09 18.39 35.31 18.01 35.69Z" fill="currentColor" />
                    </svg>
                    {loadingBalance ? (
                        <span style={{ opacity: 0.5 }}>...</span>
                    ) : (
                        <span>{formattedBalance}</span>
                    )}
                    <span style={{
                        fontSize: '0.625rem',
                        color: 'var(--accent)',
                        opacity: 0.7,
                        marginLeft: '2px'
                    }}>
                        SOL
                    </span>
                </div>

                {/* Address display */}
                <button
                    onClick={handleCopy}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '8px 12px',
                        background: 'var(--bg-card)',
                        border: '2px solid var(--border)',
                        borderRadius: 'var(--radius-sm)',
                        cursor: 'pointer',
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.8125rem',
                        fontWeight: 500,
                        color: 'var(--text-primary)',
                        transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = 'var(--text-primary)';
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border)';
                    }}
                >
                    <span style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        background: 'var(--accent)'
                    }} />
                    {truncatedAddress}
                    {copied ? (
                        <Check size={14} style={{ color: 'var(--accent-darker)' }} />
                    ) : (
                        <Copy size={14} style={{ color: 'var(--text-muted)' }} />
                    )}
                </button>

                {/* Disconnect button */}
                <button
                    onClick={() => disconnect()}
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: '36px',
                        height: '36px',
                        background: 'var(--bg-card)',
                        border: '2px solid var(--border)',
                        borderRadius: 'var(--radius-sm)',
                        cursor: 'pointer',
                        color: 'var(--text-primary)',
                        transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = 'var(--error)';
                        e.currentTarget.style.color = 'var(--error)';
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = 'var(--border)';
                        e.currentTarget.style.color = 'var(--text-primary)';
                    }}
                    title="Disconnect wallet"
                >
                    <LogOut size={16} />
                </button>
            </div>
        );
    }

    return (
        <button onClick={handleClick} className="btn btn-primary btn-sm">
            <Wallet size={16} />
            ▸ Connect
        </button>
    );
}
