'use client';

import { useState, useCallback, useEffect } from 'react';
import { useWallet } from '@/providers/Providers';
import { api, ApiError } from '@/lib/api';

const AUTH_TOKEN_KEY = 'team11_auth_token';

interface AuthState {
    token: string | null;
    isAdmin: boolean;
    isAuthenticated: boolean;
    isLoading: boolean;
    error: string | null;
}

export function useAuth() {
    const { publicKey, connected, signMessage } = useWallet();
    const [state, setState] = useState<AuthState>({
        token: null,
        isAdmin: false,
        isAuthenticated: false,
        isLoading: false,
        error: null,
    });

    // Load token from localStorage on mount
    useEffect(() => {
        if (typeof window !== 'undefined') {
            const savedToken = localStorage.getItem(AUTH_TOKEN_KEY);
            if (savedToken) {
                setState(prev => ({ ...prev, token: savedToken, isAuthenticated: true }));
                // Verify token is still valid
                api.users.getProfile(savedToken)
                    .then(user => {
                        setState(prev => ({ ...prev, isAdmin: user.is_admin }));
                    })
                    .catch(() => {
                        // Token invalid, clear it
                        localStorage.removeItem(AUTH_TOKEN_KEY);
                        setState(prev => ({ ...prev, token: null, isAuthenticated: false }));
                    });
            }
        }
    }, []);

    // Clear auth when wallet disconnects
    useEffect(() => {
        if (!connected) {
            logout();
        }
    }, [connected]);

    const login = useCallback(async () => {
        if (!publicKey || !connected) {
            setState(prev => ({ ...prev, error: 'Wallet not connected' }));
            return false;
        }

        setState(prev => ({ ...prev, isLoading: true, error: null }));

        try {
            // Get nonce from backend
            const { nonce, message } = await api.users.getNonce(publicKey.toBase58());

            // Sign the message with wallet
            const encodedMessage = new TextEncoder().encode(message);
            const signature = await signMessage(encodedMessage);

            if (!signature) {
                throw new Error('Failed to sign message');
            }

            // Convert signature to base64
            const signatureBase64 = Buffer.from(signature).toString('base64');

            // Verify signature with backend
            const { token, user } = await api.users.verify(publicKey.toBase58(), signatureBase64);

            // Save token
            localStorage.setItem(AUTH_TOKEN_KEY, token);

            setState({
                token,
                isAdmin: user.is_admin,
                isAuthenticated: true,
                isLoading: false,
                error: null,
            });

            return true;
        } catch (error) {
            const message = error instanceof ApiError ? error.message : 'Authentication failed';
            setState(prev => ({
                ...prev,
                isLoading: false,
                error: message
            }));
            return false;
        }
    }, [publicKey, connected, signMessage]);

    const logout = useCallback(() => {
        localStorage.removeItem(AUTH_TOKEN_KEY);
        setState({
            token: null,
            isAdmin: false,
            isAuthenticated: false,
            isLoading: false,
            error: null,
        });
    }, []);

    return {
        ...state,
        login,
        logout,
        walletAddress: publicKey?.toBase58() ?? null,
    };
}
