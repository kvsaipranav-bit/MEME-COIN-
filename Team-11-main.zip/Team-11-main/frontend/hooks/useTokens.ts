'use client';

import { useState, useEffect, useCallback } from 'react';
import { api, Token, LiquidityLock, ApiError } from '@/lib/api';

interface UseTokensOptions {
    page?: number;
    limit?: number;
    autoFetch?: boolean;
}

interface UseTokensResult {
    tokens: Token[];
    loading: boolean;
    error: string | null;
    total: number;
    page: number;
    refetch: () => Promise<void>;
    setPage: (page: number) => void;
}

export function useTokens(options: UseTokensOptions = {}): UseTokensResult {
    const { page: initialPage = 1, limit = 20, autoFetch = true } = options;
    const [tokens, setTokens] = useState<Token[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [total, setTotal] = useState(0);
    const [page, setPage] = useState(initialPage);

    const fetchTokens = useCallback(async () => {
        setLoading(true);
        setError(null);

        try {
            const response = await api.tokens.getAll({ page, limit });
            setTokens(response.tokens);
            setTotal(response.total);
        } catch (err) {
            const message = err instanceof ApiError ? err.message : 'Failed to fetch tokens';
            setError(message);
        } finally {
            setLoading(false);
        }
    }, [page, limit]);

    useEffect(() => {
        if (autoFetch) {
            fetchTokens();
        }
    }, [autoFetch, fetchTokens]);

    return {
        tokens,
        loading,
        error,
        total,
        page,
        refetch: fetchTokens,
        setPage,
    };
}

export function useToken(address: string | null) {
    const [token, setToken] = useState<Token | null>(null);
    const [lock, setLock] = useState<LiquidityLock | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const fetchToken = useCallback(async () => {
        if (!address) return;

        setLoading(true);
        setError(null);

        try {
            const [tokenData, lockData] = await Promise.all([
                api.tokens.getByAddress(address),
                api.liquidity.getByToken(address).catch(() => null),
            ]);

            setToken(tokenData);
            setLock(lockData);
        } catch (err) {
            const message = err instanceof ApiError ? err.message : 'Failed to fetch token';
            setError(message);
        } finally {
            setLoading(false);
        }
    }, [address]);

    useEffect(() => {
        fetchToken();
    }, [fetchToken]);

    return {
        token,
        lock,
        loading,
        error,
        refetch: fetchToken,
    };
}

export function useMyTokens(walletAddress: string | null) {
    const [tokens, setTokens] = useState<Token[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const fetchTokens = useCallback(async () => {
        if (!walletAddress) return;

        setLoading(true);
        setError(null);

        try {
            const response = await api.tokens.getByCreator(walletAddress);
            setTokens(response?.tokens || []);
        } catch (err) {
            const message = err instanceof ApiError ? err.message : 'Failed to fetch tokens';
            setError(message);
        } finally {
            setLoading(false);
        }
    }, [walletAddress]);

    useEffect(() => {
        fetchTokens();
    }, [fetchTokens]);

    return {
        tokens,
        loading,
        error,
        refetch: fetchTokens,
    };
}
