/**
 * API Client
 * Handles all API requests to the backend
 */

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';

interface RequestOptions {
    method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
    body?: Record<string, unknown>;
    token?: string;
}

class ApiError extends Error {
    status: number;

    constructor(message: string, status: number) {
        super(message);
        this.status = status;
        this.name = 'ApiError';
    }
}

async function request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    const { method = 'GET', body, token } = options;

    const headers: HeadersInit = {
        'Content-Type': 'application/json',
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const config: RequestInit = {
        method,
        headers,
    };

    if (body) {
        config.body = JSON.stringify(body);
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);

    if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'An error occurred' }));
        throw new ApiError(error.message || 'API request failed', response.status);
    }

    return response.json();
}

// Token types
export interface Token {
    id: string;
    mint_address: string;
    name: string;
    symbol: string;
    description?: string;
    logo_url?: string;
    initial_supply: string;
    decimals: number;
    creator_wallet: string;
    creator_fee_bps: number;
    is_active: boolean;
    created_at: string;
}

export interface LiquidityLock {
    id: string;
    token_id: string;
    owner_wallet: string;
    amount_sol: number;
    lock_date: string;
    unlock_date: string;
    status: 'locked' | 'unlocked' | 'claimed';
}

export interface PlatformStats {
    totalTokens: number;
    activeLocks: number;
    totalLockedSol: number;
    totalUsers: number;
    recentTokens: number;
    timestamp: string;
}

export interface PlatformConfig {
    platform_fee_percentage: number;
    min_lock_period_days: number;
    is_maintenance: boolean;
}

// API Methods
export const api = {
    // Health check
    health: () => request<{ status: string; timestamp: string }>('/health'),

    // Tokens
    tokens: {
        getAll: (params?: { page?: number; limit?: number }) => {
            const query = params ? `?page=${params.page || 1}&limit=${params.limit || 20}` : '';
            return request<{ tokens: Token[]; total: number }>(`/tokens${query}`);
        },

        getByAddress: (address: string) =>
            request<Token>(`/tokens/${address}`),

        getByCreator: (wallet: string) =>
            request<{ tokens: Token[] }>(`/tokens/creator/${wallet}`),

        create: (data: {
            name: string;
            symbol: string;
            description?: string;
            initial_supply: string;
            decimals: number;
            creator_fee_bps: number;
            mint_address: string;
        }, token: string) =>
            request<Token>('/tokens', { method: 'POST', body: data, token }),

        updateFees: (address: string, feeBps: number, token: string) =>
            request<Token>(`/tokens/${address}/fees`, { method: 'PUT', body: { creator_fee_bps: feeBps }, token }),
    },

    // Liquidity
    liquidity: {
        getAll: (params?: { status?: string }) => {
            const query = params?.status ? `?status=${params.status}` : '';
            return request<{ locks: LiquidityLock[] }>(`/liquidity/all${query}`);
        },

        getByToken: (tokenAddress: string) =>
            request<LiquidityLock>(`/liquidity/${tokenAddress}`),

        create: (data: {
            token_address: string;
            amount_sol: number;
            lock_duration_days: number;
        }, token: string) =>
            request<LiquidityLock>('/liquidity/lock', { method: 'POST', body: data, token }),

        claim: (lockId: string, token: string) =>
            request<LiquidityLock>(`/liquidity/claim/${lockId}`, { method: 'POST', token }),
    },

    // Users / Auth
    users: {
        getNonce: (wallet: string) =>
            request<{ nonce: string; message: string }>('/users/nonce', { method: 'POST', body: { wallet } }),

        verify: (wallet: string, signature: string) =>
            request<{ token: string; user: { wallet_address: string; is_admin: boolean } }>('/users/verify', { method: 'POST', body: { wallet, signature } }),

        getProfile: (token: string) =>
            request<{ wallet_address: string; is_admin: boolean; created_at: string }>('/users/profile', { token }),

        getByWallet: (wallet: string) =>
            request<{ wallet_address: string; created_at: string }>(`/users/${wallet}`),
    },

    // Admin
    admin: {
        getStats: (token: string) =>
            request<PlatformStats>('/admin/stats', { token }),

        getConfig: (token: string) =>
            request<PlatformConfig>('/admin/config', { token }),

        updateConfig: (config: Partial<PlatformConfig>, token: string) =>
            request<PlatformConfig>('/admin/config', { method: 'PUT', body: config, token }),

        getAllTokens: (token: string, params?: { page?: number }) => {
            const query = params ? `?page=${params.page || 1}` : '';
            return request<{ tokens: Token[]; total: number }>(`/admin/tokens${query}`, { token });
        },

        updateTokenStatus: (address: string, isActive: boolean, token: string) =>
            request<Token>(`/admin/tokens/${address}/status`, { method: 'PUT', body: { is_active: isActive }, token }),
    },

    // Upload
    upload: {
        logo: async (file: File, token: string): Promise<{ url: string; path: string }> => {
            const formData = new FormData();
            formData.append('logo', file);

            const response = await fetch(`${API_BASE_URL}/upload/logo`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
                body: formData,
            });

            if (!response.ok) {
                throw new ApiError('Upload failed', response.status);
            }

            const result = await response.json();
            return result.data;
        },
    },
};

export { ApiError };
export default api;
