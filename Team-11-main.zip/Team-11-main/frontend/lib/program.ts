/**
 * Team-11 Program Client
 * Handles interactions with the deployed Anchor program on Solana Devnet
 */

import { Connection, PublicKey, Keypair, Transaction, SystemProgram, LAMPORTS_PER_SOL, SYSVAR_RENT_PUBKEY } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, ASSOCIATED_TOKEN_PROGRAM_ID, getAssociatedTokenAddressSync } from '@solana/spl-token';
import { PROGRAM_ID, getPlatformConfigPDA, getTokenMetadataPDA, getLiquidityLockPDA, getLiquidityPoolPDA, getPoolTokenVaultPDA, SEEDS } from './solana';

// ===== INSTRUCTION DISCRIMINATORS =====
// Anchor uses sha256("global:<instruction_name>")[0..8]
// Pre-computed using: crypto.createHash('sha256').update('global:' + name).digest().slice(0, 8)

const DISCRIMINATORS: { [key: string]: number[] } = {
    'initialize': [175, 175, 109, 31, 13, 152, 155, 237],
    'create_token': [84, 52, 204, 228, 24, 140, 234, 75],
    'lock_liquidity': [179, 201, 236, 158, 212, 98, 70, 182],
    'lock_liquidity_with_pool': [37, 129, 75, 229, 114, 189, 206, 163],
    'unlock_liquidity': [154, 98, 151, 31, 8, 180, 144, 1],
    'update_fees': [36, 233, 241, 110, 152, 108, 248, 211],
    'update_config': [29, 158, 252, 191, 10, 83, 219, 99],
    'set_maintenance': [228, 192, 150, 8, 254, 212, 55, 150],
    'init_pool': [116, 233, 199, 204, 115, 159, 171, 36],
    'buy_tokens': [189, 21, 230, 133, 247, 2, 110, 42],
    'sell_tokens': [114, 242, 25, 12, 62, 126, 92, 2],
};

function getDiscriminator(name: string): Uint8Array {
    return new Uint8Array(DISCRIMINATORS[name] || []);
}

// ===== HELPER: Encode string for Anchor =====
function encodeString(str: string): Buffer {
    const strBytes = Buffer.from(str, 'utf8');
    const lenBuffer = Buffer.alloc(4);
    lenBuffer.writeUInt32LE(strBytes.length);
    return Buffer.concat([lenBuffer, strBytes]);
}

// ===== HELPER: Encode u64 =====
function encodeU64(value: bigint): Buffer {
    const buf = Buffer.alloc(8);
    buf.writeBigUInt64LE(value);
    return buf;
}

// ===== HELPER: Encode u16 =====
function encodeU16(value: number): Buffer {
    const buf = Buffer.alloc(2);
    buf.writeUInt16LE(value);
    return buf;
}

// ===== CHECK IF PLATFORM IS INITIALIZED =====
export async function isPlatformInitialized(connection: Connection): Promise<boolean> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const accountInfo = await connection.getAccountInfo(platformConfigPDA);
    return accountInfo !== null;
}

// ===== INITIALIZE PLATFORM =====
export async function buildInitializeTx(
    connection: Connection,
    admin: PublicKey,
    platformWallet: PublicKey,
    platformFeeBps: number,
    minLockPeriodDays: number
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();

    const data = Buffer.concat([
        Buffer.from(getDiscriminator('initialize')),
        platformWallet.toBuffer(),
        encodeU16(platformFeeBps),
        encodeU16(minLockPeriodDays),
    ]);

    const transaction = new Transaction().add({
        keys: [
            { pubkey: admin, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: true },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== CREATE TOKEN VIA PROGRAM =====
export async function buildCreateTokenTx(
    connection: Connection,
    creator: PublicKey,
    tokenMint: Keypair,
    name: string,
    symbol: string,
    decimals: number,
    initialSupply: bigint,
    creatorFeeBps: number
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const [tokenMetadataPDA] = getTokenMetadataPDA(tokenMint.publicKey);
    const creatorTokenAccount = getAssociatedTokenAddressSync(
        tokenMint.publicKey,
        creator,
        false,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const data = Buffer.concat([
        Buffer.from(getDiscriminator('create_token')),
        encodeString(name),
        encodeString(symbol),
        Buffer.from([decimals]),
        encodeU64(initialSupply),
        encodeU16(creatorFeeBps),
    ]);

    const transaction = new Transaction().add({
        keys: [
            { pubkey: creator, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: true },
            { pubkey: tokenMint.publicKey, isSigner: true, isWritable: true },
            { pubkey: creatorTokenAccount, isSigner: false, isWritable: true },
            { pubkey: tokenMetadataPDA, isSigner: false, isWritable: true },
            { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: ASSOCIATED_TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
            { pubkey: SYSVAR_RENT_PUBKEY, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== LOCK LIQUIDITY =====
export async function buildLockLiquidityTx(
    connection: Connection,
    owner: PublicKey,
    tokenMint: PublicKey,
    platformWallet: PublicKey,
    amountLamports: bigint,
    lockDurationDays: number
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const [tokenMetadataPDA] = getTokenMetadataPDA(tokenMint);
    const [liquidityLockPDA] = getLiquidityLockPDA(tokenMint, owner);

    const data = Buffer.concat([
        Buffer.from(getDiscriminator('lock_liquidity')),
        encodeU64(amountLamports),
        encodeU16(lockDurationDays),
    ]);

    const transaction = new Transaction().add({
        keys: [
            { pubkey: owner, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: true },
            { pubkey: tokenMint, isSigner: false, isWritable: false },
            { pubkey: tokenMetadataPDA, isSigner: false, isWritable: false },
            { pubkey: liquidityLockPDA, isSigner: false, isWritable: true },
            { pubkey: platformWallet, isSigner: false, isWritable: true },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== LOCK LIQUIDITY WITH POOL (COMBINED) =====
// This creates both the liquidity lock AND the trading pool in one step!
export async function buildLockLiquidityWithPoolTx(
    connection: Connection,
    owner: PublicKey,
    tokenMint: PublicKey,
    platformWallet: PublicKey,
    solAmountLamports: bigint,
    tokenAmount: bigint,
    lockDurationDays: number
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const [tokenMetadataPDA] = getTokenMetadataPDA(tokenMint);
    const [liquidityLockPDA] = getLiquidityLockPDA(tokenMint, owner);
    const [liquidityPoolPDA] = getLiquidityPoolPDA(tokenMint);
    const [poolTokenVaultPDA] = getPoolTokenVaultPDA(tokenMint);

    // Get owner's token account
    const { getAssociatedTokenAddressSync } = await import('@solana/spl-token');
    const ownerTokenAccount = getAssociatedTokenAddressSync(tokenMint, owner);

    // Build instruction data: discriminator + sol_amount (u64) + token_amount (u64) + lock_duration_days (u16)
    const data = Buffer.concat([
        getDiscriminator('lock_liquidity_with_pool'),
        encodeU64(solAmountLamports),
        encodeU64(tokenAmount),
        encodeU16(lockDurationDays),
    ]);

    const transaction = new Transaction().add({
        keys: [
            { pubkey: owner, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: true },
            { pubkey: tokenMint, isSigner: false, isWritable: false },
            { pubkey: tokenMetadataPDA, isSigner: false, isWritable: false },
            { pubkey: ownerTokenAccount, isSigner: false, isWritable: true },
            { pubkey: poolTokenVaultPDA, isSigner: false, isWritable: true },
            { pubkey: liquidityLockPDA, isSigner: false, isWritable: true },
            { pubkey: liquidityPoolPDA, isSigner: false, isWritable: true },
            { pubkey: platformWallet, isSigner: false, isWritable: true },
            { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: ASSOCIATED_TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
            { pubkey: SYSVAR_RENT_PUBKEY, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== UNLOCK LIQUIDITY =====
export async function buildUnlockLiquidityTx(
    owner: PublicKey,
    tokenMint: PublicKey
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const [liquidityLockPDA] = getLiquidityLockPDA(tokenMint, owner);

    const data = Buffer.from(getDiscriminator('unlock_liquidity'));

    const transaction = new Transaction().add({
        keys: [
            { pubkey: owner, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: true },
            { pubkey: tokenMint, isSigner: false, isWritable: false },
            { pubkey: liquidityLockPDA, isSigner: false, isWritable: true },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== FETCH PLATFORM CONFIG =====
export async function fetchPlatformConfig(connection: Connection): Promise<{
    admin: PublicKey;
    platformWallet: PublicKey;
    platformFeeBps: number;
    minLockPeriodDays: number;
    totalTokens: bigint;
    totalLockedSol: bigint;
    isMaintenance: boolean;
} | null> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const accountInfo = await connection.getAccountInfo(platformConfigPDA);

    if (!accountInfo) return null;

    const data = accountInfo.data;
    // Skip discriminator (8 bytes)
    let offset = 8;

    const admin = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const platformWallet = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const platformFeeBps = data.readUInt16LE(offset);
    offset += 2;

    const minLockPeriodDays = data.readUInt16LE(offset);
    offset += 2;

    const totalTokens = data.readBigUInt64LE(offset);
    offset += 8;

    const totalLockedSol = data.readBigUInt64LE(offset);
    offset += 8;

    const isMaintenance = data[offset] === 1;

    return {
        admin,
        platformWallet,
        platformFeeBps,
        minLockPeriodDays,
        totalTokens,
        totalLockedSol,
        isMaintenance,
    };
}

// ===== FETCH TOKEN METADATA =====
export async function fetchTokenMetadata(connection: Connection, tokenMint: PublicKey): Promise<{
    mint: PublicKey;
    creator: PublicKey;
    name: string;
    symbol: string;
    decimals: number;
    initialSupply: bigint;
    creatorFeeBps: number;
    createdAt: bigint;
    isActive: boolean;
} | null> {
    const [tokenMetadataPDA] = getTokenMetadataPDA(tokenMint);
    const accountInfo = await connection.getAccountInfo(tokenMetadataPDA);

    if (!accountInfo) return null;

    const data = accountInfo.data;
    // Skip discriminator (8 bytes)
    let offset = 8;

    const mint = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const creator = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    // Read name (4 bytes length + string)
    const nameLen = data.readUInt32LE(offset);
    offset += 4;
    const name = data.slice(offset, offset + nameLen).toString('utf8');
    offset += nameLen;

    // Read symbol
    const symbolLen = data.readUInt32LE(offset);
    offset += 4;
    const symbol = data.slice(offset, offset + symbolLen).toString('utf8');
    offset += symbolLen;

    const decimals = data[offset];
    offset += 1;

    const initialSupply = data.readBigUInt64LE(offset);
    offset += 8;

    const creatorFeeBps = data.readUInt16LE(offset);
    offset += 2;

    const createdAt = data.readBigInt64LE(offset);
    offset += 8;

    const isActive = data[offset] === 1;

    return {
        mint,
        creator,
        name,
        symbol,
        decimals,
        initialSupply,
        creatorFeeBps,
        createdAt,
        isActive,
    };
}

// ===== FETCH LIQUIDITY LOCK =====
export async function fetchLiquidityLock(connection: Connection, tokenMint: PublicKey, owner: PublicKey): Promise<{
    tokenMint: PublicKey;
    owner: PublicKey;
    amount: bigint;
    lockDate: bigint;
    unlockDate: bigint;
    isClaimed: boolean;
} | null> {
    const [liquidityLockPDA] = getLiquidityLockPDA(tokenMint, owner);
    const accountInfo = await connection.getAccountInfo(liquidityLockPDA);

    if (!accountInfo) return null;

    const data = accountInfo.data;
    // Skip discriminator (8 bytes)
    let offset = 8;

    const mint = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const ownerPubkey = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const amount = data.readBigUInt64LE(offset);
    offset += 8;

    const lockDate = data.readBigInt64LE(offset);
    offset += 8;

    const unlockDate = data.readBigInt64LE(offset);
    offset += 8;

    const isClaimed = data[offset] === 1;

    return {
        tokenMint: mint,
        owner: ownerPubkey,
        amount,
        lockDate,
        unlockDate,
        isClaimed,
    };
}

// ===== CHECK IF POOL IS INITIALIZED =====
export async function isPoolInitialized(connection: Connection, tokenMint: PublicKey): Promise<boolean> {
    const [poolPDA] = getLiquidityPoolPDA(tokenMint);
    const accountInfo = await connection.getAccountInfo(poolPDA);
    return accountInfo !== null;
}

// ===== INIT POOL TRANSACTION =====
export async function buildInitPoolTx(
    connection: Connection,
    creator: PublicKey,
    tokenMint: PublicKey,
    tokenAmount: bigint,
    solAmount: bigint
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const [tokenMetadataPDA] = getTokenMetadataPDA(tokenMint);
    const [liquidityPoolPDA] = getLiquidityPoolPDA(tokenMint);
    const [poolTokenVaultPDA] = getPoolTokenVaultPDA(tokenMint);
    const creatorTokenAccount = getAssociatedTokenAddressSync(
        tokenMint,
        creator,
        false,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const data = Buffer.concat([
        Buffer.from(getDiscriminator('init_pool')),
        encodeU64(tokenAmount),
        encodeU64(solAmount),
    ]);

    const transaction = new Transaction().add({
        keys: [
            { pubkey: creator, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: false },
            { pubkey: tokenMint, isSigner: false, isWritable: false },
            { pubkey: tokenMetadataPDA, isSigner: false, isWritable: false },
            { pubkey: creatorTokenAccount, isSigner: false, isWritable: true },
            { pubkey: poolTokenVaultPDA, isSigner: false, isWritable: true },
            { pubkey: liquidityPoolPDA, isSigner: false, isWritable: true },
            { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: ASSOCIATED_TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
            { pubkey: SYSVAR_RENT_PUBKEY, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== BUY TOKENS TRANSACTION =====
export async function buildBuyTokensTx(
    connection: Connection,
    buyer: PublicKey,
    tokenMint: PublicKey,
    platformWallet: PublicKey,
    solAmountLamports: bigint
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const [liquidityPoolPDA] = getLiquidityPoolPDA(tokenMint);
    const [poolTokenVaultPDA] = getPoolTokenVaultPDA(tokenMint);
    const buyerTokenAccount = getAssociatedTokenAddressSync(
        tokenMint,
        buyer,
        false,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const data = Buffer.concat([
        Buffer.from(getDiscriminator('buy_tokens')),
        encodeU64(solAmountLamports),
    ]);

    const transaction = new Transaction().add({
        keys: [
            { pubkey: buyer, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: true },
            { pubkey: platformWallet, isSigner: false, isWritable: true },
            { pubkey: tokenMint, isSigner: false, isWritable: false },
            { pubkey: liquidityPoolPDA, isSigner: false, isWritable: true },
            { pubkey: poolTokenVaultPDA, isSigner: false, isWritable: true },
            { pubkey: buyerTokenAccount, isSigner: false, isWritable: true },
            { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: ASSOCIATED_TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== SELL TOKENS TRANSACTION =====
export async function buildSellTokensTx(
    connection: Connection,
    seller: PublicKey,
    tokenMint: PublicKey,
    platformWallet: PublicKey,
    tokenAmount: bigint
): Promise<Transaction> {
    const [platformConfigPDA] = getPlatformConfigPDA();
    const [liquidityPoolPDA] = getLiquidityPoolPDA(tokenMint);
    const [poolTokenVaultPDA] = getPoolTokenVaultPDA(tokenMint);
    const sellerTokenAccount = getAssociatedTokenAddressSync(
        tokenMint,
        seller,
        false,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID
    );

    const data = Buffer.concat([
        Buffer.from(getDiscriminator('sell_tokens')),
        encodeU64(tokenAmount),
    ]);

    const transaction = new Transaction().add({
        keys: [
            { pubkey: seller, isSigner: true, isWritable: true },
            { pubkey: platformConfigPDA, isSigner: false, isWritable: true },
            { pubkey: platformWallet, isSigner: false, isWritable: true },
            { pubkey: tokenMint, isSigner: false, isWritable: false },
            { pubkey: liquidityPoolPDA, isSigner: false, isWritable: true },
            { pubkey: poolTokenVaultPDA, isSigner: false, isWritable: true },
            { pubkey: sellerTokenAccount, isSigner: false, isWritable: true },
            { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
            { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
    });

    return transaction;
}

// ===== FETCH LIQUIDITY POOL =====
export async function fetchLiquidityPool(connection: Connection, tokenMint: PublicKey): Promise<{
    tokenMint: PublicKey;
    creator: PublicKey;
    tokenVault: PublicKey;
    solReserve: bigint;
    tokenReserve: bigint;
    totalBought: bigint;
    totalSold: bigint;
    isActive: boolean;
} | null> {
    const [poolPDA] = getLiquidityPoolPDA(tokenMint);
    const accountInfo = await connection.getAccountInfo(poolPDA);

    if (!accountInfo) return null;

    const data = accountInfo.data;
    // Skip discriminator (8 bytes)
    let offset = 8;

    const mint = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const creator = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const tokenVault = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;

    const solReserve = data.readBigUInt64LE(offset);
    offset += 8;

    const tokenReserve = data.readBigUInt64LE(offset);
    offset += 8;

    const totalBought = data.readBigUInt64LE(offset);
    offset += 8;

    const totalSold = data.readBigUInt64LE(offset);
    offset += 8;

    const isActive = data[offset] === 1;

    return {
        tokenMint: mint,
        creator,
        tokenVault,
        solReserve,
        tokenReserve,
        totalBought,
        totalSold,
        isActive,
    };
}

// ===== CALCULATE TRADE AMOUNTS =====
export function calculateBuyAmount(solAmount: bigint, solReserve: bigint, tokenReserve: bigint): bigint {
    // tokens_out = (token_reserve * sol_in) / (sol_reserve + sol_in)
    return (tokenReserve * solAmount) / (solReserve + solAmount);
}

export function calculateSellAmount(tokenAmount: bigint, solReserve: bigint, tokenReserve: bigint): bigint {
    // sol_out = (sol_reserve * token_in) / (token_reserve + token_in)
    return (solReserve * tokenAmount) / (tokenReserve + tokenAmount);
}

export function calculatePrice(solReserve: bigint, tokenReserve: bigint): number {
    // Price in SOL per token
    if (tokenReserve === BigInt(0)) return 0;
    return Number(solReserve) / Number(tokenReserve);
}

export default {
    isPlatformInitialized,
    buildInitializeTx,
    buildCreateTokenTx,
    buildLockLiquidityTx,
    buildUnlockLiquidityTx,
    fetchPlatformConfig,
    fetchTokenMetadata,
    fetchLiquidityLock,
    isPoolInitialized,
    buildInitPoolTx,
    buildBuyTokensTx,
    buildSellTokensTx,
    fetchLiquidityPool,
    calculateBuyAmount,
    calculateSellAmount,
    calculatePrice,
};
