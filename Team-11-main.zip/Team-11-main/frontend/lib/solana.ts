/**
 * Solana Program Configuration
 * Integration with the Team-11 Meme Coin Platform smart contract
 */

import { Connection, PublicKey, clusterApiUrl } from '@solana/web3.js';

// ===== DEPLOYED PROGRAM ID =====
export const PROGRAM_ID = new PublicKey('63eKfsfRtuSjQXsrZKKQBqdDyFFwRYnLRPZ83MWDMg5u');

// ===== NETWORK CONFIGURATION =====
export const SOLANA_NETWORK = process.env.NEXT_PUBLIC_SOLANA_NETWORK || 'devnet';
export const SOLANA_RPC_URL = process.env.NEXT_PUBLIC_SOLANA_RPC_URL || 'https://api.devnet.solana.com';

// ===== CONNECTION =====
export const getConnection = (): Connection => {
    return new Connection(SOLANA_RPC_URL, 'confirmed');
};

// ===== PDA SEEDS =====
export const SEEDS = {
    PLATFORM_CONFIG: 'platform_config',
    TOKEN_METADATA: 'token_metadata',
    LIQUIDITY_LOCK: 'liquidity_lock',
    LIQUIDITY_POOL: 'liquidity_pool',
    POOL_TOKEN_VAULT: 'pool_token_vault',
} as const;

// ===== PDA DERIVATION HELPERS =====
export const getPlatformConfigPDA = (): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [Buffer.from(SEEDS.PLATFORM_CONFIG)],
        PROGRAM_ID
    );
};

export const getTokenMetadataPDA = (tokenMint: PublicKey): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [Buffer.from(SEEDS.TOKEN_METADATA), tokenMint.toBuffer()],
        PROGRAM_ID
    );
};

export const getLiquidityLockPDA = (tokenMint: PublicKey, owner: PublicKey): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [
            Buffer.from(SEEDS.LIQUIDITY_LOCK),
            tokenMint.toBuffer(),
            owner.toBuffer()
        ],
        PROGRAM_ID
    );
};

export const getLiquidityPoolPDA = (tokenMint: PublicKey): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [Buffer.from(SEEDS.LIQUIDITY_POOL), tokenMint.toBuffer()],
        PROGRAM_ID
    );
};

export const getPoolTokenVaultPDA = (tokenMint: PublicKey): [PublicKey, number] => {
    return PublicKey.findProgramAddressSync(
        [Buffer.from(SEEDS.POOL_TOKEN_VAULT), tokenMint.toBuffer()],
        PROGRAM_ID
    );
};

// ===== PLATFORM CONSTANTS =====
export const PLATFORM_CONSTANTS = {
    MAX_PLATFORM_FEE_BPS: 1000,      // 10%
    MAX_CREATOR_FEE_BPS: 1000,       // 10%
    DEFAULT_MIN_LOCK_DAYS: 90,
    MAX_TOKEN_NAME_LEN: 50,
    MAX_TOKEN_SYMBOL_LEN: 10,
    SECONDS_PER_DAY: 86400,
    LAMPORTS_PER_SOL: 1_000_000_000,
};

// ===== EXPLORER LINKS =====
export const getExplorerUrl = (type: 'address' | 'tx', value: string): string => {
    const cluster = SOLANA_NETWORK === 'mainnet-beta' ? '' : `?cluster=${SOLANA_NETWORK}`;
    return `https://explorer.solana.com/${type}/${value}${cluster}`;
};

export const getProgramExplorerUrl = (): string => {
    return getExplorerUrl('address', PROGRAM_ID.toBase58());
};

// ===== HELPER FUNCTIONS =====
export const bpsToPercentage = (bps: number): number => {
    return bps / 100;
};

export const percentageToBps = (percentage: number): number => {
    return Math.round(percentage * 100);
};

export const lamportsToSol = (lamports: number): number => {
    return lamports / PLATFORM_CONSTANTS.LAMPORTS_PER_SOL;
};

export const solToLamports = (sol: number): number => {
    return Math.round(sol * PLATFORM_CONSTANTS.LAMPORTS_PER_SOL);
};

export const formatSol = (lamports: number, decimals: number = 4): string => {
    return lamportsToSol(lamports).toFixed(decimals);
};

export const shortenAddress = (address: string, chars: number = 4): string => {
    return `${address.slice(0, chars)}...${address.slice(-chars)}`;
};

// ===== TYPE DEFINITIONS =====
export interface PlatformConfigAccount {
    admin: PublicKey;
    platformWallet: PublicKey;
    platformFeeBps: number;
    minLockPeriodDays: number;
    totalTokens: bigint;
    totalLockedSol: bigint;
    isMaintenance: boolean;
    bump: number;
}

export interface TokenMetadataAccount {
    mint: PublicKey;
    creator: PublicKey;
    name: string;
    symbol: string;
    decimals: number;
    initialSupply: bigint;
    creatorFeeBps: number;
    createdAt: bigint;
    isActive: boolean;
    bump: number;
}

export interface LiquidityLockAccount {
    tokenMint: PublicKey;
    owner: PublicKey;
    amount: bigint;
    lockDate: bigint;
    unlockDate: bigint;
    isClaimed: boolean;
    bump: number;
}

export default {
    PROGRAM_ID,
    SOLANA_NETWORK,
    SOLANA_RPC_URL,
    getConnection,
    SEEDS,
    getPlatformConfigPDA,
    getTokenMetadataPDA,
    getLiquidityLockPDA,
    PLATFORM_CONSTANTS,
    getExplorerUrl,
    getProgramExplorerUrl,
    bpsToPercentage,
    percentageToBps,
    lamportsToSol,
    solToLamports,
    formatSol,
    shortenAddress,
};
