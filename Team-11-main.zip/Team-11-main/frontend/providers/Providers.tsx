'use client';

import { ReactNode, createContext, useContext, useState, useCallback, useEffect, useMemo } from 'react';
import { Connection, PublicKey, Transaction, clusterApiUrl, Commitment, ComputeBudgetProgram } from '@solana/web3.js';
import { PROGRAM_ID, SOLANA_NETWORK, SOLANA_RPC_URL } from '@/lib/solana';

// ===== DEVNET CONFIGURATION =====
const DEVNET_RPC_URL = SOLANA_RPC_URL || 'https://api.devnet.solana.com';
const DEVNET_CLUSTER = 'devnet';

interface WalletContextType {
    publicKey: PublicKey | null;
    connected: boolean;
    connecting: boolean;
    connect: () => Promise<void>;
    disconnect: () => void;
    signMessage: (message: Uint8Array) => Promise<Uint8Array | null>;
    signTransaction: (transaction: Transaction) => Promise<Transaction | null>;
    signAndSendTransaction: (transaction: Transaction) => Promise<string | null>;
    connection: Connection;
    network: string;
    programId: PublicKey;
}

const defaultConnection = new Connection(DEVNET_RPC_URL, 'confirmed');

const WalletContext = createContext<WalletContextType>({
    publicKey: null,
    connected: false,
    connecting: false,
    connect: async () => { },
    disconnect: () => { },
    signMessage: async () => null,
    signTransaction: async () => null,
    signAndSendTransaction: async () => null,
    connection: defaultConnection,
    network: DEVNET_CLUSTER,
    programId: PROGRAM_ID,
});

export const useWallet = () => useContext(WalletContext);

interface PhantomProvider {
    isPhantom?: boolean;
    publicKey?: { toBase58: () => string };
    connect: (opts?: { onlyIfTrusted?: boolean }) => Promise<{ publicKey: { toBase58: () => string } }>;
    disconnect: () => Promise<void>;
    signMessage: (message: Uint8Array, encoding: string) => Promise<{ signature: Uint8Array }>;
    signTransaction: (transaction: Transaction) => Promise<Transaction>;
    signAndSendTransaction: (transaction: Transaction, opts?: { skipPreflight?: boolean }) => Promise<{ signature: string }>;
    on: (event: string, callback: () => void) => void;
    off: (event: string, callback: () => void) => void;
    request: (params: { method: string; params?: unknown }) => Promise<unknown>;
}

declare global {
    interface Window {
        solana?: PhantomProvider;
    }
}

export function Providers({ children }: { children: ReactNode }) {
    const [publicKey, setPublicKey] = useState<PublicKey | null>(null);
    const [connected, setConnected] = useState(false);
    const [connecting, setConnecting] = useState(false);

    // Devnet connection - memoized to prevent recreating
    const connection = useMemo(() => {
        console.log('🔗 Connecting to Solana Devnet:', DEVNET_RPC_URL);
        return new Connection(DEVNET_RPC_URL, {
            commitment: 'confirmed' as Commitment,
            confirmTransactionInitialTimeout: 60000,
        });
    }, []);

    const getProvider = (): PhantomProvider | undefined => {
        if (typeof window !== 'undefined' && 'solana' in window) {
            const provider = window.solana;
            if (provider?.isPhantom) {
                return provider;
            }
        }
        return undefined;
    };

    // Switch Phantom to Devnet if needed
    const ensureDevnetNetwork = useCallback(async (provider: PhantomProvider) => {
        try {
            // Request Phantom to switch to Devnet
            // Phantom automatically handles this, but we can check
            console.log('🌐 Ensuring wallet is on Devnet...');
            // Phantom doesn't have a direct "switch network" API,
            // but it detects the network from the dApp's connection
            // The wallet will show the current network in its UI
        } catch (error) {
            console.warn('Could not ensure Devnet network:', error);
        }
    }, []);

    const connect = useCallback(async () => {
        const provider = getProvider();
        if (!provider) {
            window.open('https://phantom.app/', '_blank');
            return;
        }

        try {
            setConnecting(true);

            // Ensure we're on Devnet
            await ensureDevnetNetwork(provider);

            const response = await provider.connect();
            const pubKey = new PublicKey(response.publicKey.toBase58());
            setPublicKey(pubKey);
            setConnected(true);

            console.log('✅ Wallet connected to Devnet:', pubKey.toBase58());
            console.log('📍 Network:', DEVNET_CLUSTER);
            console.log('🔗 RPC:', DEVNET_RPC_URL);
            console.log('📜 Program ID:', PROGRAM_ID.toBase58());
        } catch (error) {
            console.error('Failed to connect:', error);
        } finally {
            setConnecting(false);
        }
    }, [ensureDevnetNetwork]);

    const disconnect = useCallback(() => {
        const provider = getProvider();
        if (provider) {
            provider.disconnect();
        }
        setPublicKey(null);
        setConnected(false);
        console.log('👋 Wallet disconnected');
    }, []);

    const signMessage = useCallback(async (message: Uint8Array): Promise<Uint8Array | null> => {
        const provider = getProvider();
        if (!provider || !connected) return null;

        try {
            const { signature } = await provider.signMessage(message, 'utf8');
            return signature;
        } catch (error) {
            console.error('Failed to sign message:', error);
            return null;
        }
    }, [connected]);

    // Sign a transaction (for offline signing)
    const signTransaction = useCallback(async (transaction: Transaction): Promise<Transaction | null> => {
        const provider = getProvider();
        if (!provider || !connected || !publicKey) return null;

        try {
            // Get recent blockhash for the transaction
            const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('confirmed');
            transaction.recentBlockhash = blockhash;
            transaction.feePayer = publicKey;

            // Sign the transaction
            const signedTransaction = await provider.signTransaction(transaction);
            console.log('✅ Transaction signed');
            return signedTransaction;
        } catch (error) {
            console.error('Failed to sign transaction:', error);
            return null;
        }
    }, [connected, publicKey, connection]);

    // Sign and send a transaction to Devnet
    const signAndSendTransaction = useCallback(async (transaction: Transaction): Promise<string | null> => {
        const provider = getProvider();
        if (!provider || !connected || !publicKey) return null;

        try {
            // Get recent blockhash for the transaction
            const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('finalized');
            console.log('📋 Got blockhash:', blockhash.slice(0, 16) + '...');
            console.log('📊 Last valid block height:', lastValidBlockHeight);

            // Add VERY HIGH priority fees - Devnet is extremely congested
            const priorityFeeIx = ComputeBudgetProgram.setComputeUnitPrice({
                microLamports: 1000000, // 1M microLamports = very high priority
            });
            const computeUnitsIx = ComputeBudgetProgram.setComputeUnitLimit({
                units: 500000, // More compute units for complex transactions
            });

            // Prepend priority instructions
            transaction.instructions = [priorityFeeIx, computeUnitsIx, ...transaction.instructions];

            transaction.recentBlockhash = blockhash;
            transaction.feePayer = publicKey;

            console.log('🚀 Sending transaction with HIGH priority fees (1M microLamports)...');
            console.log('📝 Transaction has', transaction.instructions.length, 'instructions');

            // Sign the transaction ONCE
            const signedTransaction = await provider.signTransaction(transaction);
            const rawTransaction = signedTransaction.serialize();

            console.log('🚀 Sending transaction with HIGH priority fees (1M microLamports)...');

            // AGGRESSIVE RE-SEND STRATEGY
            // Send the SAME transaction repeatedly to ensure it lands
            let signature = '';
            let confirmed = false;
            let attempt = 0;
            const maxAttempts = 15; // Try for 30 seconds

            while (!confirmed && attempt < maxAttempts) {
                attempt++;
                try {
                    // Send/Re-send the raw transaction
                    if (attempt === 1 || attempt % 2 === 0) {
                        console.log(`📤 Sending transaction attempt ${attempt}/${maxAttempts}...`);
                        signature = await connection.sendRawTransaction(rawTransaction, {
                            skipPreflight: true,
                            maxRetries: 0 // We handle retries manually
                        });
                    }

                    // On first attempt, log the link
                    if (attempt === 1) {
                        console.log('✅ Transaction signature generated:', signature);
                        console.log('🔍 View on Explorer:', `https://explorer.solana.com/tx/${signature}?cluster=devnet`);
                    }

                    // Check status
                    const status = await connection.getSignatureStatus(signature);

                    if (status.value?.confirmationStatus === 'confirmed' || status.value?.confirmationStatus === 'finalized') {
                        console.log('✅ Transaction confirmed!');
                        confirmed = true;
                        return signature;
                    }

                    // Wait 2 seconds before checking/sending again
                    await new Promise(resolve => setTimeout(resolve, 2000));

                } catch (e: any) {
                    console.warn(`⚠️ Attempt ${attempt} warning:`, e.message);
                    // Ignore "Blockhash not found" on re-sends, just keep checking/sending
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }

            if (!confirmed) {
                console.error('❌ Transaction failed to land after multiple attempts');
                return null;
            }

            return signature;
        } catch (error) {
            console.error('Failed to sign and send transaction:', error);
            return null;
        }
    }, [connected, publicKey, connection]);

    // Check if already connected on mount
    useEffect(() => {
        const provider = getProvider();
        if (provider?.publicKey) {
            setPublicKey(new PublicKey(provider.publicKey.toBase58()));
            setConnected(true);
            console.log('🔄 Wallet auto-connected:', provider.publicKey.toBase58());
        }

        // Listen for account changes
        const handleAccountChange = () => {
            const currentProvider = getProvider();
            if (currentProvider?.publicKey) {
                setPublicKey(new PublicKey(currentProvider.publicKey.toBase58()));
                setConnected(true);
            } else {
                setPublicKey(null);
                setConnected(false);
            }
        };

        provider?.on('accountChanged', handleAccountChange);
        return () => {
            provider?.off('accountChanged', handleAccountChange);
        };
    }, []);

    // Log network info on mount
    useEffect(() => {
        console.log('');
        console.log('═══════════════════════════════════════════');
        console.log('  🌐 SOLANA DEVNET CONFIGURATION');
        console.log('═══════════════════════════════════════════');
        console.log('  Network:    ', DEVNET_CLUSTER.toUpperCase());
        console.log('  RPC URL:    ', DEVNET_RPC_URL);
        console.log('  Program ID: ', PROGRAM_ID.toBase58());
        console.log('═══════════════════════════════════════════');
        console.log('');
    }, []);

    return (
        <WalletContext.Provider value={{
            publicKey,
            connected,
            connecting,
            connect,
            disconnect,
            signMessage,
            signTransaction,
            signAndSendTransaction,
            connection,
            network: DEVNET_CLUSTER,
            programId: PROGRAM_ID,
        }}>
            {children}
        </WalletContext.Provider>
    );
}
