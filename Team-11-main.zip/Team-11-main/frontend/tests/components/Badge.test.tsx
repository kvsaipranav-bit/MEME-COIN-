/**
 * Badge Component Tests
 */

import React from 'react';
import { render, screen } from '@testing-library/react';
import { Badge } from '@/components/ui/Badge';

describe('Badge Component', () => {
    describe('Rendering', () => {
        it('should render badge with text', () => {
            render(<Badge>Status</Badge>);
            expect(screen.getByText('Status')).toBeInTheDocument();
        });

        it('should render as a span element', () => {
            render(<Badge>Default</Badge>);
            const badge = screen.getByText('Default');
            expect(badge.tagName.toLowerCase()).toBe('span');
        });
    });

    describe('Variants', () => {
        it('should render success variant', () => {
            render(<Badge variant="success">Success</Badge>);
            expect(screen.getByText('Success')).toBeInTheDocument();
        });

        it('should render warning variant', () => {
            render(<Badge variant="warning">Warning</Badge>);
            expect(screen.getByText('Warning')).toBeInTheDocument();
        });

        it('should render error variant', () => {
            render(<Badge variant="error">Error</Badge>);
            expect(screen.getByText('Error')).toBeInTheDocument();
        });

        it('should render neutral variant', () => {
            render(<Badge variant="neutral">Neutral</Badge>);
            expect(screen.getByText('Neutral')).toBeInTheDocument();
        });

        it('should render info variant', () => {
            render(<Badge variant="info">Info</Badge>);
            expect(screen.getByText('Info')).toBeInTheDocument();
        });
    });

    describe('Custom Styling', () => {
        it('should accept custom className', () => {
            render(<Badge className="custom-badge">Custom</Badge>);
            const badge = screen.getByText('Custom');
            expect(badge).toHaveClass('custom-badge');
        });
    });
});
