/**
 * Button Component Tests
 */

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Button } from '@/components/ui/Button';

describe('Button Component', () => {
    describe('Rendering', () => {
        it('should render button with text', () => {
            render(<Button>Click Me</Button>);
            expect(screen.getByRole('button', { name: /click me/i })).toBeInTheDocument();
        });

        it('should render with primary variant by default', () => {
            render(<Button>Primary</Button>);
            const button = screen.getByRole('button');
            expect(button).toBeInTheDocument();
        });

        it('should render with accent variant', () => {
            render(<Button variant="accent">Accent</Button>);
            const button = screen.getByRole('button');
            expect(button).toBeInTheDocument();
        });

        it('should render with ghost variant', () => {
            render(<Button variant="ghost">Ghost</Button>);
            const button = screen.getByRole('button');
            expect(button).toBeInTheDocument();
        });
    });

    describe('Sizes', () => {
        it('should render small size', () => {
            render(<Button size="sm">Small</Button>);
            expect(screen.getByRole('button')).toBeInTheDocument();
        });

        it('should render medium size by default', () => {
            render(<Button>Medium</Button>);
            expect(screen.getByRole('button')).toBeInTheDocument();
        });

        it('should render large size', () => {
            render(<Button size="lg">Large</Button>);
            expect(screen.getByRole('button')).toBeInTheDocument();
        });
    });

    describe('States', () => {
        it('should handle disabled state', () => {
            render(<Button disabled>Disabled</Button>);
            expect(screen.getByRole('button')).toBeDisabled();
        });

        it('should show loading state', () => {
            render(<Button loading>Loading</Button>);
            expect(screen.getByRole('button')).toBeDisabled();
        });

        it('should handle click events', () => {
            const handleClick = jest.fn();
            render(<Button onClick={handleClick}>Click</Button>);

            fireEvent.click(screen.getByRole('button'));
            expect(handleClick).toHaveBeenCalledTimes(1);
        });

        it('should not fire click when disabled', () => {
            const handleClick = jest.fn();
            render(<Button onClick={handleClick} disabled>Click</Button>);

            fireEvent.click(screen.getByRole('button'));
            expect(handleClick).not.toHaveBeenCalled();
        });
    });

    describe('Custom Props', () => {
        it('should accept custom className', () => {
            render(<Button className="custom-class">Custom</Button>);
            expect(screen.getByRole('button')).toHaveClass('custom-class');
        });

        it('should pass through other HTML attributes', () => {
            render(<Button data-testid="test-button" type="submit">Submit</Button>);
            expect(screen.getByTestId('test-button')).toHaveAttribute('type', 'submit');
        });
    });
});
