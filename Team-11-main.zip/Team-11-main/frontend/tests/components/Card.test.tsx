/**
 * Card Component Tests
 */

import React from 'react';
import { render, screen } from '@testing-library/react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';

describe('Card Component', () => {
    describe('Card', () => {
        it('should render card with children', () => {
            render(<Card>Card Content</Card>);
            expect(screen.getByText('Card Content')).toBeInTheDocument();
        });

        it('should accept custom className', () => {
            render(<Card className="custom-card" data-testid="card">Content</Card>);
            expect(screen.getByTestId('card')).toHaveClass('custom-card');
        });

        it('should render default variant', () => {
            render(<Card data-testid="card">Content</Card>);
            expect(screen.getByTestId('card')).toBeInTheDocument();
        });

        it('should render elevated variant', () => {
            render(<Card variant="elevated" data-testid="card">Content</Card>);
            expect(screen.getByTestId('card')).toBeInTheDocument();
        });

        it('should render interactive variant', () => {
            render(<Card variant="interactive" data-testid="card">Content</Card>);
            expect(screen.getByTestId('card')).toBeInTheDocument();
        });
    });

    describe('CardHeader', () => {
        it('should render header with children', () => {
            render(
                <Card>
                    <CardHeader>Header Content</CardHeader>
                </Card>
            );
            expect(screen.getByText('Header Content')).toBeInTheDocument();
        });
    });

    describe('CardTitle', () => {
        it('should render title as h3 by default', () => {
            render(
                <Card>
                    <CardTitle>Title Text</CardTitle>
                </Card>
            );
            expect(screen.getByRole('heading', { level: 3 })).toHaveTextContent('Title Text');
        });
    });

    describe('CardContent', () => {
        it('should render content with children', () => {
            render(
                <Card>
                    <CardContent>Body Content</CardContent>
                </Card>
            );
            expect(screen.getByText('Body Content')).toBeInTheDocument();
        });
    });

    describe('Full Card', () => {
        it('should render complete card structure', () => {
            render(
                <Card data-testid="full-card">
                    <CardHeader>
                        <CardTitle>Card Title</CardTitle>
                    </CardHeader>
                    <CardContent>Card body content here</CardContent>
                </Card>
            );

            expect(screen.getByTestId('full-card')).toBeInTheDocument();
            expect(screen.getByText('Card Title')).toBeInTheDocument();
            expect(screen.getByText('Card body content here')).toBeInTheDocument();
        });
    });
});
