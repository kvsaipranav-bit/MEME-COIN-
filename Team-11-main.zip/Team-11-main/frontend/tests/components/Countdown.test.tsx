import React from 'react';
import { render, screen, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Countdown } from '../../components/ui/Countdown';

// Mock date
const mockDate = new Date('2026-01-15T12:00:00Z');
const futureDate = new Date('2026-01-20T12:00:00Z');
const pastDate = new Date('2026-01-10T12:00:00Z');

describe('Countdown Component', () => {
    beforeEach(() => {
        jest.useFakeTimers();
        jest.setSystemTime(mockDate);
    });

    afterEach(() => {
        jest.useRealTimers();
    });

    describe('Rendering', () => {
        it('renders countdown for future date', () => {
            render(<Countdown targetDate={futureDate.toISOString()} />);
            // Should show days
            expect(screen.getByText('05')).toBeInTheDocument(); // 5 days
        });

        it('shows Unlocked for past date', () => {
            render(<Countdown targetDate={pastDate.toISOString()} />);
            expect(screen.getByText(/Unlocked/)).toBeInTheDocument();
        });

        it('renders compact variant', () => {
            render(<Countdown targetDate={futureDate.toISOString()} variant="compact" />);
            // Compact shows time in DD:HH:MM:SS format
            expect(screen.getByText(/:/)).toBeInTheDocument();
        });

        it('renders card variant', () => {
            render(<Countdown targetDate={futureDate.toISOString()} variant="card" />);
            expect(screen.getByText('Days')).toBeInTheDocument();
            expect(screen.getByText('Hours')).toBeInTheDocument();
        });
    });

    describe('Labels', () => {
        it('shows labels by default', () => {
            render(<Countdown targetDate={futureDate.toISOString()} />);
            expect(screen.getByText('Days')).toBeInTheDocument();
        });

        it('hides labels when showLabels is false', () => {
            render(<Countdown targetDate={futureDate.toISOString()} showLabels={false} />);
            expect(screen.queryByText('Days')).not.toBeInTheDocument();
        });
    });

    describe('Sizes', () => {
        it('renders small size', () => {
            render(<Countdown targetDate={futureDate.toISOString()} size="sm" />);
            // Component should render without error
            expect(screen.getByText('Days')).toBeInTheDocument();
        });

        it('renders large size', () => {
            render(<Countdown targetDate={futureDate.toISOString()} size="lg" />);
            expect(screen.getByText('Days')).toBeInTheDocument();
        });
    });

    describe('Callback', () => {
        it('calls onComplete when countdown expires', () => {
            const onComplete = jest.fn();
            render(<Countdown targetDate={pastDate.toISOString()} onComplete={onComplete} />);

            // Fast-forward timers
            act(() => {
                jest.advanceTimersByTime(1000);
            });

            expect(onComplete).toHaveBeenCalled();
        });
    });
});
