/**
 * Header Component Tests
 */

import React from 'react';
import { render, screen } from '@testing-library/react';
import { Header } from '@/components/layout/Header';

// Mock the wallet context
jest.mock('@/providers/Providers', () => ({
    useWallet: () => ({
        connected: false,
        connecting: false,
        publicKey: null,
        connect: jest.fn(),
        disconnect: jest.fn(),
    }),
}));

describe('Header Component', () => {
    describe('Navigation', () => {
        it('should render header', () => {
            render(<Header />);
            expect(screen.getByText(/team 11/i)).toBeInTheDocument();
        });

        it('should have dashboard link', () => {
            render(<Header />);
            expect(screen.getByRole('link', { name: /dashboard/i })).toBeInTheDocument();
        });

        it('should have create link', () => {
            render(<Header />);
            expect(screen.getByRole('link', { name: /create/i })).toBeInTheDocument();
        });

        it('should have my tokens link', () => {
            render(<Header />);
            expect(screen.getByRole('link', { name: /my tokens/i })).toBeInTheDocument();
        });

        it('should have docs link', () => {
            render(<Header />);
            expect(screen.getByRole('link', { name: /docs/i })).toBeInTheDocument();
        });
    });

    describe('Logo', () => {
        it('should have logo link to home', () => {
            render(<Header />);
            const logoLink = screen.getByRole('link', { name: /team 11/i });
            expect(logoLink).toHaveAttribute('href', '/');
        });
    });

    describe('Wallet Button', () => {
        it('should render connect button when not connected', () => {
            render(<Header />);
            // The WalletButton should show "Connect" when not connected
            expect(screen.getByText(/connect/i)).toBeInTheDocument();
        });
    });
});
