/**
 * Input Component Tests
 */

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Input, Textarea } from '@/components/ui/Input';

describe('Input Component', () => {
    describe('Rendering', () => {
        it('should render input element', () => {
            render(<Input placeholder="Enter text" />);
            expect(screen.getByPlaceholderText('Enter text')).toBeInTheDocument();
        });

        it('should render with label', () => {
            render(<Input label="Email" />);
            expect(screen.getByText('Email')).toBeInTheDocument();
        });

        it('should render input when label is provided', () => {
            render(<Input label="Username" id="username" placeholder="Enter username" />);
            const input = screen.getByPlaceholderText('Enter username');
            expect(input).toBeInTheDocument();
        });
    });

    describe('Types', () => {
        it('should render with default type as text', () => {
            render(<Input data-testid="input" placeholder="test" />);
            // Default HTML input type is "text" when not specified
            const input = screen.getByTestId('input');
            expect(input.tagName.toLowerCase()).toBe('input');
        });

        it('should render password input', () => {
            render(<Input type="password" data-testid="input" />);
            expect(screen.getByTestId('input')).toHaveAttribute('type', 'password');
        });

        it('should render email input', () => {
            render(<Input type="email" data-testid="input" />);
            expect(screen.getByTestId('input')).toHaveAttribute('type', 'email');
        });
    });

    describe('Error State', () => {
        it('should display error message', () => {
            render(<Input error="This field is required" />);
            expect(screen.getByText('This field is required')).toBeInTheDocument();
        });

        it('should have error styling when error prop is set', () => {
            render(<Input error="Error" data-testid="input" />);
            // The input should be rendered
            expect(screen.getByTestId('input')).toBeInTheDocument();
        });
    });

    describe('Controlled Input', () => {
        it('should handle value changes', () => {
            const handleChange = jest.fn();
            render(<Input onChange={handleChange} data-testid="input" />);

            fireEvent.change(screen.getByTestId('input'), { target: { value: 'test' } });
            expect(handleChange).toHaveBeenCalled();
        });

        it('should respect value prop', () => {
            render(<Input value="initial value" onChange={() => { }} data-testid="input" />);
            expect(screen.getByTestId('input')).toHaveValue('initial value');
        });
    });

    describe('Disabled State', () => {
        it('should be disabled when disabled prop is true', () => {
            render(<Input disabled data-testid="input" />);
            expect(screen.getByTestId('input')).toBeDisabled();
        });
    });
});

describe('Textarea Component', () => {
    it('should render textarea element', () => {
        render(<Textarea placeholder="Enter description" />);
        expect(screen.getByPlaceholderText('Enter description')).toBeInTheDocument();
    });

    it('should render with label', () => {
        render(<Textarea label="Description" />);
        expect(screen.getByText('Description')).toBeInTheDocument();
    });

    it('should display error message', () => {
        render(<Textarea error="Description is required" />);
        expect(screen.getByText('Description is required')).toBeInTheDocument();
    });

    it('should handle value changes', () => {
        const handleChange = jest.fn();
        render(<Textarea onChange={handleChange} data-testid="textarea" />);

        fireEvent.change(screen.getByTestId('textarea'), { target: { value: 'test text' } });
        expect(handleChange).toHaveBeenCalled();
    });
});
