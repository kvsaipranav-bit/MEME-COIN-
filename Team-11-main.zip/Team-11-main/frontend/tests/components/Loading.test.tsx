/**
 * Loading Component Tests
 */

import React from 'react';
import { render, screen } from '@testing-library/react';
import { Loading, LoadingPage, Skeleton } from '@/components/ui/Loading';

describe('Loading Component', () => {
    describe('Loading Spinner', () => {
        it('should render loading spinner', () => {
            const { container } = render(<Loading />);
            const spinner = container.firstChild;
            expect(spinner).toBeInTheDocument();
        });

        it('should render with small size class', () => {
            const { container } = render(<Loading size="sm" />);
            const spinner = container.firstChild;
            expect(spinner).toHaveClass('w-4');
        });

        it('should render with medium size class', () => {
            const { container } = render(<Loading size="md" />);
            const spinner = container.firstChild;
            expect(spinner).toHaveClass('w-8');
        });

        it('should render with large size class', () => {
            const { container } = render(<Loading size="lg" />);
            const spinner = container.firstChild;
            expect(spinner).toHaveClass('w-12');
        });

        it('should accept custom className', () => {
            const { container } = render(<Loading className="custom-spinner" />);
            const spinner = container.firstChild;
            expect(spinner).toHaveClass('custom-spinner');
        });

        it('should have spin animation class', () => {
            const { container } = render(<Loading />);
            const spinner = container.firstChild;
            expect(spinner).toHaveClass('animate-spin');
        });
    });

    describe('LoadingPage', () => {
        it('should render full page loading', () => {
            render(<LoadingPage />);
            expect(screen.getByText(/loading/i)).toBeInTheDocument();
        });

        it('should render a loading spinner', () => {
            const { container } = render(<LoadingPage />);
            const spinner = container.querySelector('.animate-spin');
            expect(spinner).toBeInTheDocument();
        });
    });

    describe('Skeleton', () => {
        it('should render skeleton element', () => {
            const { container } = render(<Skeleton />);
            const skeleton = container.firstChild;
            expect(skeleton).toBeInTheDocument();
        });

        it('should have pulse animation', () => {
            const { container } = render(<Skeleton />);
            const skeleton = container.firstChild;
            expect(skeleton).toHaveClass('animate-pulse');
        });

        it('should accept custom className', () => {
            const { container } = render(<Skeleton className="w-full h-20" />);
            const skeleton = container.firstChild;
            expect(skeleton).toHaveClass('w-full');
            expect(skeleton).toHaveClass('h-20');
        });
    });
});
