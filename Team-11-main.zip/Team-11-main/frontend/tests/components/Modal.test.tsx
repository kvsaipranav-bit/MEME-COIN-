/**
 * Modal Component Tests
 */

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Modal, ModalFooter, ConfirmModal } from '@/components/ui/Modal';

describe('Modal Component', () => {
    const mockOnClose = jest.fn();

    beforeEach(() => {
        mockOnClose.mockClear();
    });

    describe('Visibility', () => {
        it('should not render when isOpen is false', () => {
            render(
                <Modal isOpen={false} onClose={mockOnClose}>
                    <p>Modal Content</p>
                </Modal>
            );
            expect(screen.queryByText('Modal Content')).not.toBeInTheDocument();
        });

        it('should render when isOpen is true', () => {
            render(
                <Modal isOpen={true} onClose={mockOnClose}>
                    <p>Modal Content</p>
                </Modal>
            );
            expect(screen.getByText('Modal Content')).toBeInTheDocument();
        });

        it('should render title when provided', () => {
            render(
                <Modal isOpen={true} onClose={mockOnClose} title="Test Modal">
                    <p>Modal Content</p>
                </Modal>
            );
            expect(screen.getByText('Test Modal')).toBeInTheDocument();
        });
    });

    describe('Close Behavior', () => {
        it('should call onClose when close button is clicked', () => {
            render(
                <Modal isOpen={true} onClose={mockOnClose} title="Test">
                    <p>Content</p>
                </Modal>
            );
            const closeButton = screen.getByLabelText('Close modal');
            fireEvent.click(closeButton);
            expect(mockOnClose).toHaveBeenCalledTimes(1);
        });

        it('should call onClose when Escape key is pressed', () => {
            render(
                <Modal isOpen={true} onClose={mockOnClose}>
                    <p>Content</p>
                </Modal>
            );
            fireEvent.keyDown(document, { key: 'Escape' });
            expect(mockOnClose).toHaveBeenCalledTimes(1);
        });

        it('should not call onClose when closeOnEscape is false', () => {
            render(
                <Modal isOpen={true} onClose={mockOnClose} closeOnEscape={false}>
                    <p>Content</p>
                </Modal>
            );
            fireEvent.keyDown(document, { key: 'Escape' });
            expect(mockOnClose).not.toHaveBeenCalled();
        });
    });

    describe('Accessibility', () => {
        it('should have dialog role', () => {
            render(
                <Modal isOpen={true} onClose={mockOnClose}>
                    <p>Content</p>
                </Modal>
            );
            expect(screen.getByRole('dialog')).toBeInTheDocument();
        });

        it('should have aria-modal attribute', () => {
            render(
                <Modal isOpen={true} onClose={mockOnClose}>
                    <p>Content</p>
                </Modal>
            );
            expect(screen.getByRole('dialog')).toHaveAttribute('aria-modal', 'true');
        });
    });
});

describe('ModalFooter Component', () => {
    it('should render children', () => {
        render(
            <ModalFooter>
                <button>Action</button>
            </ModalFooter>
        );
        expect(screen.getByText('Action')).toBeInTheDocument();
    });
});

describe('ConfirmModal Component', () => {
    const mockOnClose = jest.fn();
    const mockOnConfirm = jest.fn();

    beforeEach(() => {
        mockOnClose.mockClear();
        mockOnConfirm.mockClear();
    });

    it('should render title and message', () => {
        render(
            <ConfirmModal
                isOpen={true}
                onClose={mockOnClose}
                onConfirm={mockOnConfirm}
                title="Confirm Action"
                message="Are you sure?"
            />
        );
        expect(screen.getByText('Confirm Action')).toBeInTheDocument();
        expect(screen.getByText('Are you sure?')).toBeInTheDocument();
    });

    it('should call onConfirm when confirm button is clicked', () => {
        render(
            <ConfirmModal
                isOpen={true}
                onClose={mockOnClose}
                onConfirm={mockOnConfirm}
                title="Confirm"
                message="Sure?"
            />
        );
        // Button text includes "▸ Confirm" so we use partial match
        const buttons = screen.getAllByRole('button');
        const confirmButton = buttons.find(btn => btn.textContent?.includes('Confirm'));
        fireEvent.click(confirmButton!);
        expect(mockOnConfirm).toHaveBeenCalledTimes(1);
    });

    it('should call onClose when cancel button is clicked', () => {
        render(
            <ConfirmModal
                isOpen={true}
                onClose={mockOnClose}
                onConfirm={mockOnConfirm}
                title="Confirm"
                message="Sure?"
            />
        );
        fireEvent.click(screen.getByText('Cancel'));
        expect(mockOnClose).toHaveBeenCalledTimes(1);
    });
});
