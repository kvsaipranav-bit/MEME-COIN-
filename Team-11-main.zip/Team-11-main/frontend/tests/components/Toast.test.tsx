import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import { ToastProvider, useToast, useNotifications } from '../../components/ui/Toast';

// Test component that uses toast hooks
function TestComponent() {
    const { addToast, removeToast, toasts } = useToast();
    const { success, error, info, warning } = useNotifications();

    return (
        <div>
            <button onClick={() => addToast('success', 'Test success message')}>
                Add Toast
            </button>
            <button onClick={() => success('Quick success')}>Success</button>
            <button onClick={() => error('Quick error')}>Error</button>
            <button onClick={() => info('Quick info')}>Info</button>
            <button onClick={() => warning('Quick warning')}>Warning</button>
            <span data-testid="toast-count">{toasts.length}</span>
        </div>
    );
}

describe('Toast Component', () => {
    beforeEach(() => {
        jest.useFakeTimers();
    });

    afterEach(() => {
        jest.useRealTimers();
    });

    describe('ToastProvider', () => {
        it('renders children', () => {
            render(
                <ToastProvider>
                    <div data-testid="child">Child Content</div>
                </ToastProvider>
            );
            expect(screen.getByTestId('child')).toBeInTheDocument();
        });
    });

    describe('useToast', () => {
        it('adds a toast', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            fireEvent.click(screen.getByText('Add Toast'));
            expect(screen.getByText('Test success message')).toBeInTheDocument();
        });

        it('shows toast count', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            expect(screen.getByTestId('toast-count')).toHaveTextContent('0');
            fireEvent.click(screen.getByText('Add Toast'));
            expect(screen.getByTestId('toast-count')).toHaveTextContent('1');
        });

        it('auto-removes toast after duration', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            fireEvent.click(screen.getByText('Add Toast'));
            expect(screen.getByTestId('toast-count')).toHaveTextContent('1');

            // Fast-forward past the default duration (5000ms)
            act(() => {
                jest.advanceTimersByTime(6000);
            });

            expect(screen.getByTestId('toast-count')).toHaveTextContent('0');
        });
    });

    describe('useNotifications', () => {
        it('creates success toast', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            fireEvent.click(screen.getByText('Success'));
            expect(screen.getByText('Quick success')).toBeInTheDocument();
        });

        it('creates error toast', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            fireEvent.click(screen.getByText('Error'));
            expect(screen.getByText('Quick error')).toBeInTheDocument();
        });

        it('creates info toast', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            fireEvent.click(screen.getByText('Info'));
            expect(screen.getByText('Quick info')).toBeInTheDocument();
        });

        it('creates warning toast', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            fireEvent.click(screen.getByText('Warning'));
            expect(screen.getByText('Quick warning')).toBeInTheDocument();
        });
    });

    describe('Toast dismissal', () => {
        it('removes toast when close button clicked', () => {
            render(
                <ToastProvider>
                    <TestComponent />
                </ToastProvider>
            );

            fireEvent.click(screen.getByText('Add Toast'));
            expect(screen.getByText('Test success message')).toBeInTheDocument();

            // Find and click the X button
            const closeButtons = screen.getAllByRole('button');
            const closeButton = closeButtons.find(btn => {
                return btn.querySelector('svg'); // Find button with X icon
            });

            if (closeButton) {
                fireEvent.click(closeButton);
            }
        });
    });
});
