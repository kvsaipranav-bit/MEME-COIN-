import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { TokenCard, TokenCardSkeleton } from '../../components/token/TokenCard';

const mockToken = {
    address: '9x4KjL8mTestAddress12345',
    name: 'Test Token',
    symbol: 'TEST',
    creator: '7xKXsAsU1234TestCreator',
    initialSupply: '1,000,000,000',
    liquidityLocked: true,
    lockAmount: '10.5 SOL',
    unlockDate: '2026-04-01',
    createdAt: '2026-01-05',
};

// Mock next/link
jest.mock('next/link', () => {
    return ({ children, href }: { children: React.ReactNode; href: string }) => (
        <a href={href} data-testid="card-link">{children}</a>
    );
});

describe('TokenCard Component', () => {
    describe('Rendering', () => {
        it('renders token name', () => {
            render(<TokenCard {...mockToken} />);
            expect(screen.getByText('Test Token')).toBeInTheDocument();
        });

        it('renders token symbol', () => {
            render(<TokenCard {...mockToken} />);
            expect(screen.getByText('$TEST')).toBeInTheDocument();
        });

        it('renders initial supply', () => {
            render(<TokenCard {...mockToken} />);
            expect(screen.getByText('1,000,000,000')).toBeInTheDocument();
        });

        it('renders creator address (formatted)', () => {
            render(<TokenCard {...mockToken} />);
            expect(screen.getByText('7xKX...ator')).toBeInTheDocument();
        });

        it('renders created date', () => {
            render(<TokenCard {...mockToken} />);
            expect(screen.getByText('2026-01-05')).toBeInTheDocument();
        });
    });

    describe('Lock Status', () => {
        it('shows locked badge when liquidity is locked', () => {
            render(<TokenCard {...mockToken} />);
            expect(screen.getByText('Locked')).toBeInTheDocument();
        });

        it('shows lock amount', () => {
            render(<TokenCard {...mockToken} />);
            expect(screen.getByText('10.5 SOL')).toBeInTheDocument();
        });

        it('does not show lock info when not locked', () => {
            render(<TokenCard {...mockToken} liquidityLocked={false} />);
            expect(screen.queryByText('Locked')).not.toBeInTheDocument();
        });
    });

    describe('Active Status', () => {
        it('does not show inactive badge for active tokens', () => {
            render(<TokenCard {...mockToken} isActive={true} />);
            expect(screen.queryByText('Inactive')).not.toBeInTheDocument();
        });

        it('shows inactive badge for inactive tokens', () => {
            render(<TokenCard {...mockToken} isActive={false} />);
            expect(screen.getByText('Inactive')).toBeInTheDocument();
        });
    });

    describe('Link', () => {
        it('links to token details page', () => {
            render(<TokenCard {...mockToken} />);
            const link = screen.getByTestId('card-link');
            expect(link).toHaveAttribute('href', `/token/${mockToken.address}`);
        });
    });

    describe('Logo', () => {
        it('shows first letter when no logo', () => {
            render(<TokenCard {...mockToken} logoUrl={null} />);
            // The first letter of the symbol should be shown
            const logoContainer = document.querySelector('[style*="background: linear-gradient"]');
            expect(logoContainer).toBeInTheDocument();
        });
    });
});

describe('TokenCardSkeleton Component', () => {
    it('renders skeleton loader', () => {
        render(<TokenCardSkeleton />);
        const skeleton = document.querySelector('.card');
        expect(skeleton).toBeInTheDocument();
    });

    it('has pulse animation', () => {
        render(<TokenCardSkeleton />);
        const skeleton = document.querySelector('.card');
        expect(skeleton).toHaveStyle({ animation: 'pulse 2s infinite' });
    });
});
