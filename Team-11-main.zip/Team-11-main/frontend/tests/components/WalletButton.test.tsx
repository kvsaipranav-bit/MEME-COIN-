/**
 * WalletButton Component Tests
 */

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';

// We need to mock the providers before importing WalletButton
const mockConnect = jest.fn();
const mockDisconnect = jest.fn();

let mockConnected = false;
let mockConnecting = false;
let mockPublicKey: { toBase58: () => string } | null = null;

jest.mock('@/providers/Providers', () => ({
    useWallet: () => ({
        connected: mockConnected,
        connecting: mockConnecting,
        publicKey: mockPublicKey,
        connect: mockConnect,
        disconnect: mockDisconnect,
    }),
}));

import { WalletButton } from '@/components/wallet/WalletButton';

describe('WalletButton Component', () => {
    beforeEach(() => {
        // Reset mocks
        mockConnect.mockClear();
        mockDisconnect.mockClear();
        mockConnected = false;
        mockConnecting = false;
        mockPublicKey = null;
    });

    describe('Disconnected State', () => {
        it('should show connect button when disconnected', () => {
            render(<WalletButton />);
            expect(screen.getByText(/connect/i)).toBeInTheDocument();
        });

        it('should call connect when clicked while disconnected', () => {
            render(<WalletButton />);
            const button = screen.getByRole('button');
            fireEvent.click(button);
            expect(mockConnect).toHaveBeenCalled();
        });
    });

    describe('Connecting State', () => {
        beforeEach(() => {
            mockConnecting = true;
        });

        it('should show connecting text', () => {
            render(<WalletButton />);
            expect(screen.getByText(/connecting/i)).toBeInTheDocument();
        });

        it('should be disabled while connecting', () => {
            render(<WalletButton />);
            const button = screen.getByRole('button');
            expect(button).toBeDisabled();
        });
    });

    describe('Connected State', () => {
        beforeEach(() => {
            mockConnected = true;
            mockPublicKey = {
                toBase58: () => '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
            };
        });

        it('should show truncated address when connected', () => {
            render(<WalletButton />);
            // Should show first 4 and last 4 characters
            expect(screen.getByText(/7xKX/i)).toBeInTheDocument();
        });

        it('should have disconnect button when connected', () => {
            render(<WalletButton />);
            // Should have a disconnect button (LogOut icon button)
            const buttons = screen.getAllByRole('button');
            expect(buttons.length).toBeGreaterThanOrEqual(1);
        });
    });
});
