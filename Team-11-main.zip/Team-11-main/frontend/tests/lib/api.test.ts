import { api, ApiError } from '../../lib/api';

// Mock fetch
global.fetch = jest.fn();

const mockFetch = global.fetch as jest.Mock;

describe('API Client', () => {
    beforeEach(() => {
        mockFetch.mockClear();
    });

    describe('Health Check', () => {
        it('fetches health status', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ status: 'healthy', timestamp: '2026-01-01' }),
            });

            const result = await api.health();
            expect(result.status).toBe('healthy');
        });
    });

    describe('Tokens API', () => {
        it('fetches all tokens', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ tokens: [], total: 0 }),
            });

            const result = await api.tokens.getAll();
            expect(result.tokens).toEqual([]);
            expect(mockFetch).toHaveBeenCalledWith(
                expect.stringContaining('/tokens'),
                expect.any(Object)
            );
        });

        it('fetches tokens with pagination', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ tokens: [], total: 0 }),
            });

            await api.tokens.getAll({ page: 2, limit: 10 });
            expect(mockFetch).toHaveBeenCalledWith(
                expect.stringContaining('page=2'),
                expect.any(Object)
            );
        });

        it('fetches token by address', async () => {
            const mockToken = { mint_address: 'test', name: 'Test' };
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => mockToken,
            });

            const result = await api.tokens.getByAddress('test');
            expect(result.mint_address).toBe('test');
        });

        it('creates a token', async () => {
            const mockToken = { name: 'New Token' };
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => mockToken,
            });

            const result = await api.tokens.create(
                { name: 'New Token', symbol: 'NT', initial_supply: '1000', decimals: 9, creator_fee_bps: 100, mint_address: 'addr' },
                'test-token'
            );
            expect(result.name).toBe('New Token');
            expect(mockFetch).toHaveBeenCalledWith(
                expect.stringContaining('/tokens'),
                expect.objectContaining({
                    method: 'POST',
                    headers: expect.objectContaining({
                        'Authorization': 'Bearer test-token'
                    })
                })
            );
        });
    });

    describe('Liquidity API', () => {
        it('fetches all locks', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ locks: [] }),
            });

            const result = await api.liquidity.getAll();
            expect(result.locks).toEqual([]);
        });

        it('fetches lock by token', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ owner_wallet: 'test', amount_sol: 10 }),
            });

            const result = await api.liquidity.getByToken('test');
            expect(result.owner_wallet).toBe('test');
        });

        it('creates a lock', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ id: '1', amount_sol: 10 }),
            });

            const result = await api.liquidity.create(
                { token_address: 'test', amount_sol: 10, lock_duration_days: 90 },
                'test-token'
            );
            expect(result.amount_sol).toBe(10);
        });
    });

    describe('Users API', () => {
        it('gets nonce', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ nonce: 'abc123', message: 'Sign this' }),
            });

            const result = await api.users.getNonce('wallet123');
            expect(result.nonce).toBe('abc123');
        });

        it('verifies signature', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ token: 'jwt123', user: { wallet_address: 'wallet', is_admin: false } }),
            });

            const result = await api.users.verify('wallet', 'signature');
            expect(result.token).toBe('jwt123');
        });
    });

    describe('Admin API', () => {
        it('fetches stats', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ totalTokens: 10, activeLocks: 5 }),
            });

            const result = await api.admin.getStats('admin-token');
            expect(result.totalTokens).toBe(10);
        });

        it('updates config', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: true,
                json: async () => ({ platform_fee_percentage: 1 }),
            });

            const result = await api.admin.updateConfig({ platform_fee_percentage: 1 }, 'admin-token');
            expect(result.platform_fee_percentage).toBe(1);
        });
    });

    describe('Error Handling', () => {
        it('throws ApiError on failed request', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: false,
                status: 400,
                json: async () => ({ message: 'Bad request' }),
            });

            await expect(api.tokens.getAll()).rejects.toThrow(ApiError);
        });

        it('includes status code in error', async () => {
            mockFetch.mockResolvedValueOnce({
                ok: false,
                status: 404,
                json: async () => ({ message: 'Not found' }),
            });

            try {
                await api.tokens.getByAddress('nonexistent');
            } catch (error) {
                expect(error).toBeInstanceOf(ApiError);
                expect((error as ApiError).status).toBe(404);
            }
        });
    });
});
