/**
 * Frontend Type Definitions
 * Shared types used across the application
 */

// Token Types
export interface Token {
    id: string;
    mint_address: string;
    name: string;
    symbol: string;
    description?: string;
    logo_url?: string;
    initial_supply: string;
    decimals: number;
    creator_wallet: string;
    creator_fee_bps: number;
    is_active: boolean;
    created_at: string;
    updated_at?: string;
}

export interface TokenFormData {
    name: string;
    symbol: string;
    description: string;
    initialSupply: string;
    decimals: string;
    creatorFee: string;
    lockDuration: string;
    lockAmount: string;
    logoFile?: File;
}

// Liquidity Lock Types
export interface LiquidityLock {
    id: string;
    token_id: string;
    token_address: string;
    owner_wallet: string;
    amount_sol: number;
    lock_date: string;
    unlock_date: string;
    status: LockStatus;
    tx_signature?: string;
    created_at: string;
}

export type LockStatus = 'locked' | 'unlocked' | 'claimed';

// User Types
export interface User {
    id: string;
    wallet_address: string;
    is_admin: boolean;
    created_at: string;
    last_login?: string;
}

export interface AuthState {
    token: string | null;
    isAdmin: boolean;
    isAuthenticated: boolean;
    isLoading: boolean;
    error: string | null;
    walletAddress: string | null;
}

// Platform Types
export interface PlatformStats {
    totalTokens: number;
    activeLocks: number;
    claimedLocks: number;
    totalLockedSol: number;
    totalUsers: number;
    recentTokens: number;
    timestamp: string;
}

export interface PlatformConfig {
    platform_fee_percentage: number;
    min_lock_period_days: number;
    is_maintenance: boolean;
}

// API Response Types
export interface ApiResponse<T> {
    success: boolean;
    data: T;
    message?: string;
}

export interface PaginatedResponse<T> {
    items: T[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
}

// Component Props Types
export interface PageProps {
    params: Record<string, string>;
    searchParams?: Record<string, string | string[] | undefined>;
}

// Toast Types
export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface Toast {
    id: string;
    type: ToastType;
    message: string;
    duration?: number;
}

// Filter Types
export interface TokenFilters {
    search?: string;
    status?: 'all' | 'active' | 'inactive';
    lockStatus?: 'all' | 'locked' | 'unlocked';
    sortBy?: 'created' | 'name' | 'supply';
    sortOrder?: 'asc' | 'desc';
}

// Time Types
export interface TimeRemaining {
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    expired: boolean;
}

// Wallet Types
export interface WalletState {
    publicKey: string | null;
    connected: boolean;
    connecting: boolean;
}

// Form Validation Types
export interface ValidationError {
    field: string;
    message: string;
}

export interface FormState<T> {
    data: T;
    errors: ValidationError[];
    isValid: boolean;
    isSubmitting: boolean;
}
