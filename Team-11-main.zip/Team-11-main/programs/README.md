# 🦀 Team 11 - Solana Programs

This directory contains the Anchor-based Solana programs for the Team 11 meme coin creation platform.

## Prerequisites

Before you can build and deploy the programs, you need to install:

1. **Rust & Cargo**
   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   ```

2. **Solana CLI**
   ```bash
   sh -c "$(curl -sSfL https://release.solana.com/stable/install)"
   ```

3. **Anchor Framework**
   ```bash
   cargo install --git https://github.com/coral-xyz/anchor anchor-cli --locked
   ```

## Project Structure

```
programs/
├── Anchor.toml           # Anchor configuration
└── team-11/
    ├── Cargo.toml        # Rust dependencies
    └── src/
        ├── lib.rs        # Program entry point
        ├── state.rs      # Account state definitions
        ├── errors.rs     # Custom error types
        ├── constants.rs  # Program constants
        └── instructions/ # Instruction handlers
            ├── mod.rs
            ├── initialize.rs
            ├── create_token.rs
            ├── lock_liquidity.rs
            ├── unlock_liquidity.rs
            └── update_config.rs
```

## Instructions

### Initialize
Sets up the platform configuration with:
- Platform wallet for fee collection
- Platform fee percentage (max 10%)
- Minimum lock period (default 90 days)

### Create Token
Creates a new SPL token with:
- Token name and symbol
- Initial supply
- Creator fee percentage (max 5%)

### Lock Liquidity
Locks SOL liquidity for a token:
- Must meet minimum lock period
- Platform fee is deducted automatically
- Creates a LiquidityLock PDA

### Unlock Liquidity
Claims locked liquidity after lock period:
- Only owner can claim
- Lock period must be expired
- Funds returned to owner

### Update Config (Admin Only)
Updates platform settings:
- Platform wallet
- Platform fee
- Minimum lock period

## Building

```bash
# Build the program
anchor build

# Get the program ID
anchor keys list

# Update the program ID in Anchor.toml and lib.rs
```

## Testing

```bash
# Run tests
anchor test
```

## Deployment

```bash
# Deploy to devnet
anchor deploy --provider.cluster devnet

# Deploy to mainnet (use with caution!)
anchor deploy --provider.cluster mainnet
```

## Security Considerations

- All fees are capped with maximum limits
- Lock periods are enforced on-chain
- Only owners can claim their locked liquidity
- Admin functions require proper authorization
- Platform can be put in maintenance mode

## License

MIT
