//! Program constants

/// Platform configuration PDA seed
pub const PLATFORM_CONFIG_SEED: &[u8] = b"platform_config";

/// Token metadata PDA seed
pub const TOKEN_METADATA_SEED: &[u8] = b"token_metadata";

/// Liquidity lock PDA seed
pub const LIQUIDITY_LOCK_SEED: &[u8] = b"liquidity_lock";

/// Liquidity pool PDA seed
pub const LIQUIDITY_POOL_SEED: &[u8] = b"liquidity_pool";

/// Pool token vault PDA seed
pub const POOL_TOKEN_VAULT_SEED: &[u8] = b"pool_token_vault";

/// Maximum platform fee in basis points (10%)
pub const MAX_PLATFORM_FEE_BPS: u16 = 1000;

/// Maximum creator fee in basis points (10%)
pub const MAX_CREATOR_FEE_BPS: u16 = 1000;

/// Default minimum lock period in days
pub const DEFAULT_MIN_LOCK_DAYS: u16 = 90;

/// Maximum token name length
pub const MAX_TOKEN_NAME_LEN: usize = 50;

/// Maximum token symbol length
pub const MAX_TOKEN_SYMBOL_LEN: usize = 10;

/// Seconds per day
pub const SECONDS_PER_DAY: i64 = 86400;
