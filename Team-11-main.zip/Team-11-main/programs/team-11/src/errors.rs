//! Custom error definitions for the Team 11 program

use anchor_lang::prelude::*;

#[error_code]
pub enum Team11Error {
    /// Invalid platform fee (must be <= 1000 bps = 10%)
    #[msg("Platform fee must be 10% or less (1000 basis points)")]
    InvalidPlatformFee,

    /// Invalid creator fee (must be <= 1000 bps = 10%)
    #[msg("Creator fee must be 10% or less (1000 basis points)")]
    InvalidCreatorFee,

    /// Lock period too short
    #[msg("Lock period must be at least the minimum required days")]
    LockPeriodTooShort,

    /// Liquidity still locked
    #[msg("Liquidity is still locked and cannot be withdrawn")]
    LiquidityStillLocked,

    /// Liquidity already claimed
    #[msg("Liquidity has already been claimed")]
    LiquidityAlreadyClaimed,

    /// Not authorized
    #[msg("You are not authorized to perform this action")]
    Unauthorized,

    /// Platform in maintenance mode
    #[msg("Platform is currently in maintenance mode")]
    MaintenanceMode,

    /// Token name too long
    #[msg("Token name must be 50 characters or less")]
    TokenNameTooLong,

    /// Token name empty
    #[msg("Token name cannot be empty")]
    TokenNameEmpty,

    /// Token symbol too long
    #[msg("Token symbol must be 10 characters or less")]
    TokenSymbolTooLong,

    /// Token symbol empty
    #[msg("Token symbol cannot be empty")]
    TokenSymbolEmpty,

    /// Invalid initial supply
    #[msg("Initial supply must be greater than zero")]
    InvalidInitialSupply,

    /// Insufficient funds
    #[msg("Insufficient funds for this operation")]
    InsufficientFunds,

    /// Math overflow
    #[msg("Mathematical operation resulted in overflow")]
    MathOverflow,

    /// Invalid lock amount
    #[msg("Lock amount must be greater than zero")]
    InvalidLockAmount,

    /// Token not found
    #[msg("Token not found")]
    TokenNotFound,

    /// Token already exists
    #[msg("Token with this mint already exists")]
    TokenAlreadyExists,

    /// Invalid decimals
    #[msg("Decimals must be between 0 and 9")]
    InvalidDecimals,

    /// Pool is not active
    #[msg("Liquidity pool is not active for trading")]
    PoolInactive,

    /// Invalid token vault
    #[msg("Invalid token vault for this pool")]
    InvalidTokenVault,

    /// Insufficient liquidity in pool
    #[msg("Insufficient liquidity in pool for this trade")]
    InsufficientLiquidity,

    /// Pool already exists
    #[msg("Liquidity pool already exists for this token")]
    PoolAlreadyExists,
}

