//! Buy tokens instruction
//! User swaps SOL for tokens from the liquidity pool

use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint, Transfer};
use anchor_spl::associated_token::AssociatedToken;
use crate::state::{PlatformConfig, LiquidityPool};
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct BuyTokens<'info> {
    #[account(mut)]
    pub buyer: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump,
        constraint = !platform_config.is_maintenance @ Team11Error::MaintenanceMode
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    /// CHECK: Platform wallet to receive fees
    #[account(mut, address = platform_config.platform_wallet)]
    pub platform_wallet: AccountInfo<'info>,

    /// The token mint
    pub token_mint: Account<'info, Mint>,

    /// Liquidity pool
    #[account(
        mut,
        seeds = [LIQUIDITY_POOL_SEED, token_mint.key().as_ref()],
        bump = liquidity_pool.bump,
        constraint = liquidity_pool.is_active @ Team11Error::PoolInactive
    )]
    pub liquidity_pool: Account<'info, LiquidityPool>,

    /// Pool token vault (source of tokens)
    #[account(
        mut,
        seeds = [POOL_TOKEN_VAULT_SEED, token_mint.key().as_ref()],
        bump,
        constraint = pool_token_vault.key() == liquidity_pool.token_vault @ Team11Error::InvalidTokenVault
    )]
    pub pool_token_vault: Account<'info, TokenAccount>,

    /// Buyer's token account (destination)
    #[account(
        init_if_needed,
        payer = buyer,
        associated_token::mint = token_mint,
        associated_token::authority = buyer
    )]
    pub buyer_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<BuyTokens>, sol_amount: u64) -> Result<()> {
    require!(sol_amount > 0, Team11Error::InvalidLockAmount);

    let pool = &ctx.accounts.liquidity_pool;
    
    // Check pool has liquidity
    require!(pool.token_reserve > 0, Team11Error::InsufficientLiquidity);
    require!(pool.sol_reserve > 0, Team11Error::InsufficientLiquidity);

    // Calculate platform fee
    let platform_fee = sol_amount
        .checked_mul(ctx.accounts.platform_config.platform_fee_bps as u64)
        .ok_or(Team11Error::MathOverflow)?
        .checked_div(10000)
        .ok_or(Team11Error::MathOverflow)?;

    let sol_for_swap = sol_amount
        .checked_sub(platform_fee)
        .ok_or(Team11Error::MathOverflow)?;

    // Calculate tokens out using constant product formula: x * y = k
    // tokens_out = token_reserve - (k / (sol_reserve + sol_in))
    // Simplified: tokens_out = (token_reserve * sol_in) / (sol_reserve + sol_in)
    let tokens_out = (pool.token_reserve as u128)
        .checked_mul(sol_for_swap as u128)
        .ok_or(Team11Error::MathOverflow)?
        .checked_div(
            (pool.sol_reserve as u128)
                .checked_add(sol_for_swap as u128)
                .ok_or(Team11Error::MathOverflow)?
        )
        .ok_or(Team11Error::MathOverflow)? as u64;

    require!(tokens_out > 0, Team11Error::InsufficientLiquidity);
    require!(tokens_out <= pool.token_reserve, Team11Error::InsufficientLiquidity);

    // Transfer platform fee to platform wallet
    if platform_fee > 0 {
        let cpi_context = CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            anchor_lang::system_program::Transfer {
                from: ctx.accounts.buyer.to_account_info(),
                to: ctx.accounts.platform_wallet.to_account_info(),
            },
        );
        anchor_lang::system_program::transfer(cpi_context, platform_fee)?;
    }

    // Transfer SOL from buyer to pool
    let cpi_context = CpiContext::new(
        ctx.accounts.system_program.to_account_info(),
        anchor_lang::system_program::Transfer {
            from: ctx.accounts.buyer.to_account_info(),
            to: ctx.accounts.liquidity_pool.to_account_info(),
        },
    );
    anchor_lang::system_program::transfer(cpi_context, sol_for_swap)?;

    // Transfer tokens from pool vault to buyer
    // Need to use PDA seeds for signing
    let token_mint_key = ctx.accounts.token_mint.key();
    let seeds = &[
        LIQUIDITY_POOL_SEED,
        token_mint_key.as_ref(),
        &[ctx.accounts.liquidity_pool.bump],
    ];
    let signer = &[&seeds[..]];

    let cpi_accounts = Transfer {
        from: ctx.accounts.pool_token_vault.to_account_info(),
        to: ctx.accounts.buyer_token_account.to_account_info(),
        authority: ctx.accounts.liquidity_pool.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    let cpi_ctx = CpiContext::new_with_signer(cpi_program, cpi_accounts, signer);
    token::transfer(cpi_ctx, tokens_out)?;

    // Update pool reserves
    let pool = &mut ctx.accounts.liquidity_pool;
    pool.sol_reserve = pool.sol_reserve
        .checked_add(sol_for_swap)
        .ok_or(Team11Error::MathOverflow)?;
    pool.token_reserve = pool.token_reserve
        .checked_sub(tokens_out)
        .ok_or(Team11Error::MathOverflow)?;
    pool.total_bought = pool.total_bought
        .checked_add(tokens_out)
        .ok_or(Team11Error::MathOverflow)?;

    msg!("Bought {} tokens for {} lamports SOL (fee: {} lamports)", 
         tokens_out, sol_for_swap, platform_fee);

    Ok(())
}
