//! Create token instruction

use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount, MintTo};
use anchor_spl::associated_token::AssociatedToken;
use crate::state::{PlatformConfig, TokenMetadata};
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
#[instruction(name: String, symbol: String)]
pub struct CreateToken<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump,
        constraint = !platform_config.is_maintenance @ Team11Error::MaintenanceMode
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    #[account(
        init,
        payer = creator,
        mint::decimals = 9,
        mint::authority = creator
    )]
    pub token_mint: Account<'info, Mint>,

    #[account(
        init,
        payer = creator,
        associated_token::mint = token_mint,
        associated_token::authority = creator
    )]
    pub creator_token_account: Account<'info, TokenAccount>,

    #[account(
        init,
        payer = creator,
        space = TokenMetadata::LEN,
        seeds = [TOKEN_METADATA_SEED, token_mint.key().as_ref()],
        bump
    )]
    pub token_metadata: Account<'info, TokenMetadata>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

pub fn handler(
    ctx: Context<CreateToken>,
    name: String,
    symbol: String,
    decimals: u8,
    initial_supply: u64,
    creator_fee_bps: u16,
) -> Result<()> {
    // Validate inputs
    require!(!name.is_empty(), Team11Error::TokenNameEmpty);
    require!(name.len() <= MAX_TOKEN_NAME_LEN, Team11Error::TokenNameTooLong);
    require!(!symbol.is_empty(), Team11Error::TokenSymbolEmpty);
    require!(symbol.len() <= MAX_TOKEN_SYMBOL_LEN, Team11Error::TokenSymbolTooLong);
    require!(initial_supply > 0, Team11Error::InvalidInitialSupply);
    require!(creator_fee_bps <= MAX_CREATOR_FEE_BPS, Team11Error::InvalidCreatorFee);
    require!(decimals <= 9, Team11Error::InvalidDecimals);

    let clock = Clock::get()?;
    
    // Store token metadata
    let metadata = &mut ctx.accounts.token_metadata;
    metadata.mint = ctx.accounts.token_mint.key();
    metadata.creator = ctx.accounts.creator.key();
    metadata.name = name.clone();
    metadata.symbol = symbol.clone();
    metadata.decimals = decimals;
    metadata.initial_supply = initial_supply;
    metadata.creator_fee_bps = creator_fee_bps;
    metadata.created_at = clock.unix_timestamp;
    metadata.is_active = true;
    metadata.bump = ctx.bumps.token_metadata;

    // Mint initial supply to creator
    let cpi_accounts = MintTo {
        mint: ctx.accounts.token_mint.to_account_info(),
        to: ctx.accounts.creator_token_account.to_account_info(),
        authority: ctx.accounts.creator.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
    
    // Calculate actual amount with decimals
    let mint_amount = initial_supply
        .checked_mul(10u64.pow(decimals as u32))
        .ok_or(Team11Error::MathOverflow)?;
    
    token::mint_to(cpi_ctx, mint_amount)?;

    // Increment total tokens counter
    let config = &mut ctx.accounts.platform_config;
    config.total_tokens = config.total_tokens
        .checked_add(1)
        .ok_or(Team11Error::MathOverflow)?;

    msg!("Token created: {} ({}) with supply {} and {} bps creator fee", 
         name, symbol, initial_supply, creator_fee_bps);
    msg!("Total tokens on platform: {}", config.total_tokens);

    Ok(())
}
