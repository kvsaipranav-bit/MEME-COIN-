//! Initialize liquidity pool instruction
//! Creates a trading pool for a token with initial SOL and token liquidity

use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint, Transfer};
use anchor_spl::associated_token::AssociatedToken;
use crate::state::{PlatformConfig, TokenMetadata, LiquidityPool};
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct InitPool<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,

    #[account(
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump,
        constraint = !platform_config.is_maintenance @ Team11Error::MaintenanceMode
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    /// The token mint for this pool
    pub token_mint: Account<'info, Mint>,

    /// Verify that the token was created on our platform
    #[account(
        seeds = [TOKEN_METADATA_SEED, token_mint.key().as_ref()],
        bump = token_metadata.bump,
        constraint = token_metadata.is_active @ Team11Error::TokenNotFound,
        constraint = token_metadata.creator == creator.key() @ Team11Error::Unauthorized
    )]
    pub token_metadata: Account<'info, TokenMetadata>,

    /// Creator's token account (source of initial pool tokens)
    #[account(
        mut,
        associated_token::mint = token_mint,
        associated_token::authority = creator
    )]
    pub creator_token_account: Account<'info, TokenAccount>,

    /// Pool token vault (holds pool's tokens)
    #[account(
        init,
        payer = creator,
        token::mint = token_mint,
        token::authority = liquidity_pool,
        seeds = [POOL_TOKEN_VAULT_SEED, token_mint.key().as_ref()],
        bump
    )]
    pub pool_token_vault: Account<'info, TokenAccount>,

    /// Liquidity pool account
    #[account(
        init,
        payer = creator,
        space = LiquidityPool::LEN,
        seeds = [LIQUIDITY_POOL_SEED, token_mint.key().as_ref()],
        bump
    )]
    pub liquidity_pool: Account<'info, LiquidityPool>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

pub fn handler(
    ctx: Context<InitPool>,
    token_amount: u64,
    sol_amount: u64,
) -> Result<()> {
    // Validate amounts
    require!(token_amount > 0, Team11Error::InvalidInitialSupply);
    require!(sol_amount > 0, Team11Error::InvalidLockAmount);

    // Transfer tokens from creator to pool vault
    let cpi_accounts = Transfer {
        from: ctx.accounts.creator_token_account.to_account_info(),
        to: ctx.accounts.pool_token_vault.to_account_info(),
        authority: ctx.accounts.creator.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
    token::transfer(cpi_ctx, token_amount)?;

    // Transfer SOL from creator to liquidity pool PDA
    let cpi_context = CpiContext::new(
        ctx.accounts.system_program.to_account_info(),
        anchor_lang::system_program::Transfer {
            from: ctx.accounts.creator.to_account_info(),
            to: ctx.accounts.liquidity_pool.to_account_info(),
        },
    );
    anchor_lang::system_program::transfer(cpi_context, sol_amount)?;

    // Initialize liquidity pool
    let pool = &mut ctx.accounts.liquidity_pool;
    pool.token_mint = ctx.accounts.token_mint.key();
    pool.creator = ctx.accounts.creator.key();
    pool.token_vault = ctx.accounts.pool_token_vault.key();
    pool.sol_reserve = sol_amount;
    pool.token_reserve = token_amount;
    pool.total_bought = 0;
    pool.total_sold = 0;
    pool.is_active = true;
    pool.bump = ctx.bumps.liquidity_pool;

    msg!("Liquidity pool initialized with {} tokens and {} lamports SOL", 
         token_amount, sol_amount);

    Ok(())
}
