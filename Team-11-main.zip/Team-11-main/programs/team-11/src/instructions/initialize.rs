//! Initialize platform configuration

use anchor_lang::prelude::*;
use crate::state::PlatformConfig;
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,

    #[account(
        init,
        payer = admin,
        space = PlatformConfig::LEN,
        seeds = [PLATFORM_CONFIG_SEED],
        bump
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    pub system_program: Program<'info, System>,
}

pub fn handler(
    ctx: Context<Initialize>,
    platform_wallet: Pubkey,
    platform_fee_bps: u16,
    min_lock_period_days: u16,
) -> Result<()> {
    // Validate platform fee
    require!(
        platform_fee_bps <= MAX_PLATFORM_FEE_BPS,
        Team11Error::InvalidPlatformFee
    );

    // Validate minimum lock period (at least 1 day)
    require!(
        min_lock_period_days >= 1,
        Team11Error::LockPeriodTooShort
    );

    let config = &mut ctx.accounts.platform_config;
    config.admin = ctx.accounts.admin.key();
    config.platform_wallet = platform_wallet;
    config.platform_fee_bps = platform_fee_bps;
    config.min_lock_period_days = min_lock_period_days;
    config.total_tokens = 0;
    config.total_locked_sol = 0;
    config.is_maintenance = false;
    config.bump = ctx.bumps.platform_config;

    msg!("Platform initialized with fee: {} bps, min lock: {} days", 
         platform_fee_bps, min_lock_period_days);

    Ok(())
}
