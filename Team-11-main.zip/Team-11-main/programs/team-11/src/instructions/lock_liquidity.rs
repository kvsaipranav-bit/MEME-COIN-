//! Lock liquidity instruction

use anchor_lang::prelude::*;
use crate::state::{PlatformConfig, LiquidityLock, TokenMetadata};
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct LockLiquidity<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump,
        constraint = !platform_config.is_maintenance @ Team11Error::MaintenanceMode
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    /// CHECK: Token mint for the liquidity lock
    pub token_mint: AccountInfo<'info>,

    /// Verify that the token exists on our platform
    #[account(
        seeds = [TOKEN_METADATA_SEED, token_mint.key().as_ref()],
        bump = token_metadata.bump,
        constraint = token_metadata.is_active @ Team11Error::TokenNotFound
    )]
    pub token_metadata: Account<'info, TokenMetadata>,

    #[account(
        init,
        payer = owner,
        space = LiquidityLock::LEN,
        seeds = [LIQUIDITY_LOCK_SEED, token_mint.key().as_ref(), owner.key().as_ref()],
        bump
    )]
    pub liquidity_lock: Account<'info, LiquidityLock>,

    /// CHECK: Platform wallet to receive fees
    #[account(mut, address = platform_config.platform_wallet)]
    pub platform_wallet: AccountInfo<'info>,

    pub system_program: Program<'info, System>,
}

pub fn handler(
    ctx: Context<LockLiquidity>,
    amount: u64,
    lock_duration_days: u16,
) -> Result<()> {
    // Validate amount
    require!(amount > 0, Team11Error::InvalidLockAmount);

    let config = &ctx.accounts.platform_config;

    // Validate lock duration
    require!(
        lock_duration_days >= config.min_lock_period_days,
        Team11Error::LockPeriodTooShort
    );

    // Calculate platform fee
    let fee_amount = amount
        .checked_mul(config.platform_fee_bps as u64)
        .ok_or(Team11Error::MathOverflow)?
        .checked_div(10000)
        .ok_or(Team11Error::MathOverflow)?;

    let lock_amount = amount
        .checked_sub(fee_amount)
        .ok_or(Team11Error::MathOverflow)?;

    // Transfer the full amount to the lock PDA (this will hold the locked SOL)
    // First transfer fee to platform wallet
    if fee_amount > 0 {
        let cpi_context = CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            anchor_lang::system_program::Transfer {
                from: ctx.accounts.owner.to_account_info(),
                to: ctx.accounts.platform_wallet.to_account_info(),
            },
        );
        anchor_lang::system_program::transfer(cpi_context, fee_amount)?;
    }

    // Transfer lock amount to the lock PDA account
    let cpi_context = CpiContext::new(
        ctx.accounts.system_program.to_account_info(),
        anchor_lang::system_program::Transfer {
            from: ctx.accounts.owner.to_account_info(),
            to: ctx.accounts.liquidity_lock.to_account_info(),
        },
    );
    anchor_lang::system_program::transfer(cpi_context, lock_amount)?;

    // Set up the liquidity lock
    let clock = Clock::get()?;
    let lock = &mut ctx.accounts.liquidity_lock;

    lock.token_mint = ctx.accounts.token_mint.key();
    lock.owner = ctx.accounts.owner.key();
    lock.amount = lock_amount;
    lock.lock_date = clock.unix_timestamp;
    lock.unlock_date = clock.unix_timestamp + (lock_duration_days as i64 * SECONDS_PER_DAY);
    lock.is_claimed = false;
    lock.bump = ctx.bumps.liquidity_lock;

    // Update platform total locked SOL
    let config = &mut ctx.accounts.platform_config;
    config.total_locked_sol = config.total_locked_sol
        .checked_add(lock_amount)
        .ok_or(Team11Error::MathOverflow)?;

    msg!("Liquidity locked: {} lamports for {} days (fee: {} lamports)", 
         lock_amount, lock_duration_days, fee_amount);
    msg!("Total SOL locked on platform: {} lamports", config.total_locked_sol);

    Ok(())
}
