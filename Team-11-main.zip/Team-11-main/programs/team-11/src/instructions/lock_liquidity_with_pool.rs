//! Lock liquidity with pool instruction
//! Combines locking SOL + tokens into a trading pool in ONE step
//! After this, trading begins immediately!

use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint, Transfer};
use anchor_spl::associated_token::AssociatedToken;
use crate::state::{PlatformConfig, LiquidityLock, TokenMetadata, LiquidityPool};
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct LockLiquidityWithPool<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump,
        constraint = !platform_config.is_maintenance @ Team11Error::MaintenanceMode
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    /// Token mint for the pool
    pub token_mint: Account<'info, Mint>,

    /// Verify that the token exists on our platform and owner is creator
    #[account(
        seeds = [TOKEN_METADATA_SEED, token_mint.key().as_ref()],
        bump = token_metadata.bump,
        constraint = token_metadata.is_active @ Team11Error::TokenNotFound,
        constraint = token_metadata.creator == owner.key() @ Team11Error::Unauthorized
    )]
    pub token_metadata: Account<'info, TokenMetadata>,

    /// Owner's token account (source of pool tokens)
    #[account(
        mut,
        associated_token::mint = token_mint,
        associated_token::authority = owner
    )]
    pub owner_token_account: Account<'info, TokenAccount>,

    /// Pool token vault (holds pool's tokens)
    #[account(
        init,
        payer = owner,
        token::mint = token_mint,
        token::authority = liquidity_pool,
        seeds = [POOL_TOKEN_VAULT_SEED, token_mint.key().as_ref()],
        bump
    )]
    pub pool_token_vault: Account<'info, TokenAccount>,

    /// Liquidity lock account (tracks the lock period)
    #[account(
        init,
        payer = owner,
        space = LiquidityLock::LEN,
        seeds = [LIQUIDITY_LOCK_SEED, token_mint.key().as_ref(), owner.key().as_ref()],
        bump
    )]
    pub liquidity_lock: Account<'info, LiquidityLock>,

    /// Liquidity pool account (for trading)
    #[account(
        init,
        payer = owner,
        space = LiquidityPool::LEN,
        seeds = [LIQUIDITY_POOL_SEED, token_mint.key().as_ref()],
        bump
    )]
    pub liquidity_pool: Account<'info, LiquidityPool>,

    /// CHECK: Platform wallet to receive fees
    #[account(mut, address = platform_config.platform_wallet)]
    pub platform_wallet: AccountInfo<'info>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

pub fn handler(
    ctx: Context<LockLiquidityWithPool>,
    sol_amount: u64,
    token_amount: u64,
    lock_duration_days: u16,
) -> Result<()> {
    // Validate amounts
    require!(sol_amount > 0, Team11Error::InvalidLockAmount);
    require!(token_amount > 0, Team11Error::InvalidInitialSupply);

    let config = &ctx.accounts.platform_config;

    // Validate lock duration
    require!(
        lock_duration_days >= config.min_lock_period_days,
        Team11Error::LockPeriodTooShort
    );

    // Calculate platform fee from SOL
    let fee_amount = sol_amount
        .checked_mul(config.platform_fee_bps as u64)
        .ok_or(Team11Error::MathOverflow)?
        .checked_div(10000)
        .ok_or(Team11Error::MathOverflow)?;

    let pool_sol_amount = sol_amount
        .checked_sub(fee_amount)
        .ok_or(Team11Error::MathOverflow)?;

    // Transfer platform fee
    if fee_amount > 0 {
        let cpi_context = CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            anchor_lang::system_program::Transfer {
                from: ctx.accounts.owner.to_account_info(),
                to: ctx.accounts.platform_wallet.to_account_info(),
            },
        );
        anchor_lang::system_program::transfer(cpi_context, fee_amount)?;
    }

    // Transfer SOL to liquidity pool PDA
    let cpi_context = CpiContext::new(
        ctx.accounts.system_program.to_account_info(),
        anchor_lang::system_program::Transfer {
            from: ctx.accounts.owner.to_account_info(),
            to: ctx.accounts.liquidity_pool.to_account_info(),
        },
    );
    anchor_lang::system_program::transfer(cpi_context, pool_sol_amount)?;

    // Transfer tokens from owner to pool vault
    let cpi_accounts = Transfer {
        from: ctx.accounts.owner_token_account.to_account_info(),
        to: ctx.accounts.pool_token_vault.to_account_info(),
        authority: ctx.accounts.owner.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
    token::transfer(cpi_ctx, token_amount)?;

    // Set up the liquidity lock
    let clock = Clock::get()?;
    let lock = &mut ctx.accounts.liquidity_lock;

    lock.token_mint = ctx.accounts.token_mint.key();
    lock.owner = ctx.accounts.owner.key();
    lock.amount = pool_sol_amount; // Track SOL amount for unlock
    lock.lock_date = clock.unix_timestamp;
    lock.unlock_date = clock.unix_timestamp + (lock_duration_days as i64 * SECONDS_PER_DAY);
    lock.is_claimed = false;
    lock.bump = ctx.bumps.liquidity_lock;

    // Initialize liquidity pool
    let pool = &mut ctx.accounts.liquidity_pool;
    pool.token_mint = ctx.accounts.token_mint.key();
    pool.creator = ctx.accounts.owner.key();
    pool.token_vault = ctx.accounts.pool_token_vault.key();
    pool.sol_reserve = pool_sol_amount;
    pool.token_reserve = token_amount;
    pool.total_bought = 0;
    pool.total_sold = 0;
    pool.is_active = true;
    pool.bump = ctx.bumps.liquidity_pool;

    // Update platform stats
    let config = &mut ctx.accounts.platform_config;
    config.total_locked_sol = config.total_locked_sol
        .checked_add(pool_sol_amount)
        .ok_or(Team11Error::MathOverflow)?;

    msg!("🚀 Liquidity pool created with trading enabled!");
    msg!("💰 SOL locked: {} lamports (fee: {})", pool_sol_amount, fee_amount);
    msg!("🪙 Tokens in pool: {}", token_amount);
    msg!("🔒 Lock period: {} days", lock_duration_days);
    msg!("📊 Initial price: {} lamports per token", pool_sol_amount / token_amount);

    Ok(())
}
