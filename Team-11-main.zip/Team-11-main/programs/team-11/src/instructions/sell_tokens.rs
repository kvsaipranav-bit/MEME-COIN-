//! Sell tokens instruction
//! User swaps tokens for SOL from the liquidity pool

use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint, Transfer};
use crate::state::{PlatformConfig, LiquidityPool};
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct SellTokens<'info> {
    #[account(mut)]
    pub seller: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump,
        constraint = !platform_config.is_maintenance @ Team11Error::MaintenanceMode
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    /// CHECK: Platform wallet to receive fees
    #[account(mut, address = platform_config.platform_wallet)]
    pub platform_wallet: AccountInfo<'info>,

    /// The token mint
    pub token_mint: Account<'info, Mint>,

    /// Liquidity pool
    #[account(
        mut,
        seeds = [LIQUIDITY_POOL_SEED, token_mint.key().as_ref()],
        bump = liquidity_pool.bump,
        constraint = liquidity_pool.is_active @ Team11Error::PoolInactive
    )]
    pub liquidity_pool: Account<'info, LiquidityPool>,

    /// Pool token vault (destination for sold tokens)
    #[account(
        mut,
        seeds = [POOL_TOKEN_VAULT_SEED, token_mint.key().as_ref()],
        bump,
        constraint = pool_token_vault.key() == liquidity_pool.token_vault @ Team11Error::InvalidTokenVault
    )]
    pub pool_token_vault: Account<'info, TokenAccount>,

    /// Seller's token account (source of tokens)
    #[account(
        mut,
        associated_token::mint = token_mint,
        associated_token::authority = seller
    )]
    pub seller_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<SellTokens>, token_amount: u64) -> Result<()> {
    require!(token_amount > 0, Team11Error::InvalidInitialSupply);

    let pool = &ctx.accounts.liquidity_pool;
    
    // Check pool has liquidity
    require!(pool.sol_reserve > 0, Team11Error::InsufficientLiquidity);

    // Calculate SOL out using constant product formula: x * y = k
    // sol_out = sol_reserve - (k / (token_reserve + token_in))
    // Simplified: sol_out = (sol_reserve * token_in) / (token_reserve + token_in)
    let sol_out = (pool.sol_reserve as u128)
        .checked_mul(token_amount as u128)
        .ok_or(Team11Error::MathOverflow)?
        .checked_div(
            (pool.token_reserve as u128)
                .checked_add(token_amount as u128)
                .ok_or(Team11Error::MathOverflow)?
        )
        .ok_or(Team11Error::MathOverflow)? as u64;

    require!(sol_out > 0, Team11Error::InsufficientLiquidity);
    require!(sol_out <= pool.sol_reserve, Team11Error::InsufficientLiquidity);

    // Calculate platform fee from SOL output
    let platform_fee = sol_out
        .checked_mul(ctx.accounts.platform_config.platform_fee_bps as u64)
        .ok_or(Team11Error::MathOverflow)?
        .checked_div(10000)
        .ok_or(Team11Error::MathOverflow)?;

    let sol_to_seller = sol_out
        .checked_sub(platform_fee)
        .ok_or(Team11Error::MathOverflow)?;

    // Transfer tokens from seller to pool vault
    let cpi_accounts = Transfer {
        from: ctx.accounts.seller_token_account.to_account_info(),
        to: ctx.accounts.pool_token_vault.to_account_info(),
        authority: ctx.accounts.seller.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
    token::transfer(cpi_ctx, token_amount)?;

    // Transfer SOL from pool to seller
    // Pool PDA needs to transfer SOL directly from its account
    **ctx.accounts.liquidity_pool.to_account_info().try_borrow_mut_lamports()? -= sol_out;
    **ctx.accounts.seller.to_account_info().try_borrow_mut_lamports()? += sol_to_seller;
    
    // Transfer platform fee
    if platform_fee > 0 {
        **ctx.accounts.platform_wallet.to_account_info().try_borrow_mut_lamports()? += platform_fee;
    }

    // Update pool reserves
    let pool = &mut ctx.accounts.liquidity_pool;
    pool.sol_reserve = pool.sol_reserve
        .checked_sub(sol_out)
        .ok_or(Team11Error::MathOverflow)?;
    pool.token_reserve = pool.token_reserve
        .checked_add(token_amount)
        .ok_or(Team11Error::MathOverflow)?;
    pool.total_sold = pool.total_sold
        .checked_add(token_amount)
        .ok_or(Team11Error::MathOverflow)?;

    msg!("Sold {} tokens for {} lamports SOL (fee: {} lamports)", 
         token_amount, sol_to_seller, platform_fee);

    Ok(())
}
