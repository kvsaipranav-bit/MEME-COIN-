//! Set maintenance mode instruction

use anchor_lang::prelude::*;
use crate::state::PlatformConfig;
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct SetMaintenance<'info> {
    #[account(
        constraint = admin.key() == platform_config.admin @ Team11Error::Unauthorized
    )]
    pub admin: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump
    )]
    pub platform_config: Account<'info, PlatformConfig>,
}

pub fn handler(
    ctx: Context<SetMaintenance>,
    is_maintenance: bool,
) -> Result<()> {
    let config = &mut ctx.accounts.platform_config;
    let was_maintenance = config.is_maintenance;
    config.is_maintenance = is_maintenance;

    if is_maintenance && !was_maintenance {
        msg!("Platform is now in MAINTENANCE MODE - token creation and locking disabled");
    } else if !is_maintenance && was_maintenance {
        msg!("Platform is now ACTIVE - all operations enabled");
    }

    Ok(())
}
