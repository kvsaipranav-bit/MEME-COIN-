//! Claim liquidity instruction (unlock and withdraw)

use anchor_lang::prelude::*;
use crate::state::{PlatformConfig, LiquidityLock};
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct UnlockLiquidity<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump
    )]
    pub platform_config: Account<'info, PlatformConfig>,

    /// CHECK: Token mint for the liquidity lock
    pub token_mint: AccountInfo<'info>,

    #[account(
        mut,
        seeds = [LIQUIDITY_LOCK_SEED, token_mint.key().as_ref(), owner.key().as_ref()],
        bump = liquidity_lock.bump,
        constraint = liquidity_lock.owner == owner.key() @ Team11Error::Unauthorized,
        constraint = !liquidity_lock.is_claimed @ Team11Error::LiquidityAlreadyClaimed,
        close = owner  // ✅ OPTIMIZATION: Closes account and returns rent to owner
    )]
    pub liquidity_lock: Account<'info, LiquidityLock>,

    pub system_program: Program<'info, System>,
}

pub fn handler(ctx: Context<UnlockLiquidity>) -> Result<()> {
    let clock = Clock::get()?;
    let lock = &ctx.accounts.liquidity_lock;

    // Check if lock period has expired
    require!(
        clock.unix_timestamp >= lock.unlock_date,
        Team11Error::LiquidityStillLocked
    );

    // Get the amount to return (will be transferred when account closes)
    let amount = lock.amount;

    // Transfer locked SOL from the lock account back to owner
    // Note: Account rent will also be returned to owner via `close = owner`
    **ctx.accounts.liquidity_lock.to_account_info().try_borrow_mut_lamports()? -= amount;
    **ctx.accounts.owner.to_account_info().try_borrow_mut_lamports()? += amount;

    // Update platform total locked SOL
    let config = &mut ctx.accounts.platform_config;
    config.total_locked_sol = config.total_locked_sol
        .checked_sub(amount)
        .unwrap_or(0);

    msg!("Liquidity claimed: {} lamports + rent returned to owner", amount);
    msg!("Remaining total SOL locked on platform: {} lamports", config.total_locked_sol);

    // Account is automatically closed by Anchor's `close` constraint
    // returning ~0.00118 SOL rent to owner

    Ok(())
}

