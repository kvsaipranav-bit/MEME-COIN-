//! Update platform configuration instruction

use anchor_lang::prelude::*;
use crate::state::PlatformConfig;
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct UpdateConfig<'info> {
    #[account(
        constraint = admin.key() == platform_config.admin @ Team11Error::Unauthorized
    )]
    pub admin: Signer<'info>,

    #[account(
        mut,
        seeds = [PLATFORM_CONFIG_SEED],
        bump = platform_config.bump
    )]
    pub platform_config: Account<'info, PlatformConfig>,
}

pub fn handler(
    ctx: Context<UpdateConfig>,
    new_platform_wallet: Option<Pubkey>,
    new_platform_fee_bps: Option<u16>,
    new_min_lock_period_days: Option<u16>,
) -> Result<()> {
    let config = &mut ctx.accounts.platform_config;

    // Update platform wallet if provided
    if let Some(wallet) = new_platform_wallet {
        config.platform_wallet = wallet;
        msg!("Platform wallet updated");
    }

    // Update platform fee if provided
    if let Some(fee_bps) = new_platform_fee_bps {
        require!(
            fee_bps <= MAX_PLATFORM_FEE_BPS,
            Team11Error::InvalidPlatformFee
        );
        config.platform_fee_bps = fee_bps;
        msg!("Platform fee updated to {} bps", fee_bps);
    }

    // Update min lock period if provided
    if let Some(days) = new_min_lock_period_days {
        config.min_lock_period_days = days;
        msg!("Min lock period updated to {} days", days);
    }

    Ok(())
}
