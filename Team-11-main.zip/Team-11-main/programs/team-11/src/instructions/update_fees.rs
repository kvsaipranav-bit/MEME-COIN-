//! Update token creator fees instruction

use anchor_lang::prelude::*;
use crate::state::TokenMetadata;
use crate::constants::*;
use crate::errors::Team11Error;

#[derive(Accounts)]
pub struct UpdateFees<'info> {
    #[account(mut)]
    pub creator: Signer<'info>,

    /// CHECK: Token mint
    pub token_mint: AccountInfo<'info>,

    #[account(
        mut,
        seeds = [TOKEN_METADATA_SEED, token_mint.key().as_ref()],
        bump = token_metadata.bump,
        constraint = token_metadata.creator == creator.key() @ Team11Error::Unauthorized,
        constraint = token_metadata.is_active @ Team11Error::TokenNotFound
    )]
    pub token_metadata: Account<'info, TokenMetadata>,
}

pub fn handler(
    ctx: Context<UpdateFees>,
    new_creator_fee_bps: u16,
) -> Result<()> {
    // Validate new fee
    require!(
        new_creator_fee_bps <= MAX_CREATOR_FEE_BPS,
        Team11Error::InvalidCreatorFee
    );

    let metadata = &mut ctx.accounts.token_metadata;
    let old_fee = metadata.creator_fee_bps;
    metadata.creator_fee_bps = new_creator_fee_bps;

    msg!("Token {} ({}) creator fee updated from {} bps to {} bps", 
         metadata.name, metadata.symbol, old_fee, new_creator_fee_bps);

    Ok(())
}
