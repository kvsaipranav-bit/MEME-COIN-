//! # Team 11 - Meme Coin Creation Platform
//!
//! This Solana program enables users to create SPL tokens with built-in
//! liquidity lock mechanisms, ensuring transparency and trust in the
//! meme coin ecosystem.
//!
//! ## Features
//! - Create SPL tokens with customizable parameters
//! - Lock liquidity for a minimum of 90 days
//! - Platform fee collection (configurable)
//! - Secure unlock mechanism with time validation
//! - Admin maintenance mode control
//!
//! ## Instructions
//! - `initialize`: Initialize the platform configuration
//! - `create_token`: Create a new SPL token with minting
//! - `lock_liquidity`: Lock SOL liquidity for a token
//! - `unlock_liquidity`: Claim liquidity after lock period expires
//! - `update_config`: Update platform configuration (admin only)
//! - `update_fees`: Update token creator transaction fees
//! - `set_maintenance`: Toggle platform maintenance mode (admin only)

use anchor_lang::prelude::*;

declare_id!("63eKfsfRtuSjQXsrZKKQBqdDyFFwRYnLRPZ83MWDMg5u");

pub mod instructions;
pub mod state;
pub mod errors;
pub mod constants;

use instructions::*;

#[program]
pub mod team_11 {
    use super::*;

    /// Initialize the platform configuration
    /// 
    /// This instruction sets up the initial platform state including:
    /// - Platform wallet address for fee collection
    /// - Platform fee percentage (default 0.5%)
    /// - Minimum lock period in days (default 90)
    pub fn initialize(
        ctx: Context<Initialize>,
        platform_wallet: Pubkey,
        platform_fee_bps: u16,
        min_lock_period_days: u16,
    ) -> Result<()> {
        instructions::initialize::handler(ctx, platform_wallet, platform_fee_bps, min_lock_period_days)
    }

    /// Create a new SPL token
    ///
    /// Creates a new token mint with the specified parameters:
    /// - name: Token name (max 50 chars)
    /// - symbol: Token symbol (max 10 chars)
    /// - decimals: Token decimals (usually 9)
    /// - initial_supply: Initial token supply
    /// - creator_fee_bps: Creator fee in basis points
    pub fn create_token(
        ctx: Context<CreateToken>,
        name: String,
        symbol: String,
        decimals: u8,
        initial_supply: u64,
        creator_fee_bps: u16,
    ) -> Result<()> {
        instructions::create_token::handler(ctx, name, symbol, decimals, initial_supply, creator_fee_bps)
    }

    /// Lock liquidity for a token
    ///
    /// Locks SOL liquidity for the specified duration.
    /// Minimum lock period is enforced by platform configuration.
    pub fn lock_liquidity(
        ctx: Context<LockLiquidity>,
        amount: u64,
        lock_duration_days: u16,
    ) -> Result<()> {
        instructions::lock_liquidity::handler(ctx, amount, lock_duration_days)
    }

    /// Lock liquidity AND create trading pool in ONE step
    ///
    /// This combines liquidity locking with pool creation.
    /// After this transaction, trading begins immediately!
    /// - sol_amount: SOL to add to the pool (minus platform fee)
    /// - token_amount: Tokens to add to the pool
    /// - lock_duration_days: How long the liquidity is locked
    pub fn lock_liquidity_with_pool(
        ctx: Context<LockLiquidityWithPool>,
        sol_amount: u64,
        token_amount: u64,
        lock_duration_days: u16,
    ) -> Result<()> {
        instructions::lock_liquidity_with_pool::handler(ctx, sol_amount, token_amount, lock_duration_days)
    }

    /// Unlock liquidity after lock period expires
    ///
    /// Allows the liquidity provider to claim their locked funds
    /// after the lock period has ended.
    pub fn unlock_liquidity(ctx: Context<UnlockLiquidity>) -> Result<()> {
        instructions::unlock_liquidity::handler(ctx)
    }

    /// Update platform configuration (admin only)
    ///
    /// Allows the platform admin to update:
    /// - Platform fee percentage
    /// - Minimum lock period
    /// - Platform wallet address
    pub fn update_config(
        ctx: Context<UpdateConfig>,
        new_platform_wallet: Option<Pubkey>,
        new_platform_fee_bps: Option<u16>,
        new_min_lock_period_days: Option<u16>,
    ) -> Result<()> {
        instructions::update_config::handler(ctx, new_platform_wallet, new_platform_fee_bps, new_min_lock_period_days)
    }

    /// Update token creator fees
    ///
    /// Allows the token creator to update their transaction fee percentage.
    /// Maximum fee is 10% (1000 basis points).
    pub fn update_fees(
        ctx: Context<UpdateFees>,
        new_creator_fee_bps: u16,
    ) -> Result<()> {
        instructions::update_fees::handler(ctx, new_creator_fee_bps)
    }

    /// Set platform maintenance mode (admin only)
    ///
    /// When maintenance mode is enabled:
    /// - Token creation is disabled
    /// - Liquidity locking is disabled
    /// - Existing unlocks can still be claimed
    pub fn set_maintenance(
        ctx: Context<SetMaintenance>,
        is_maintenance: bool,
    ) -> Result<()> {
        instructions::set_maintenance::handler(ctx, is_maintenance)
    }

    /// Initialize a liquidity pool for trading
    ///
    /// Creates a pool with initial token and SOL reserves.
    /// Only the token creator can initialize the pool.
    pub fn init_pool(
        ctx: Context<InitPool>,
        token_amount: u64,
        sol_amount: u64,
    ) -> Result<()> {
        instructions::init_pool::handler(ctx, token_amount, sol_amount)
    }

    /// Buy tokens from the liquidity pool
    ///
    /// User swaps SOL for tokens using the constant product formula.
    /// Price increases as more tokens are bought.
    pub fn buy_tokens(
        ctx: Context<BuyTokens>,
        sol_amount: u64,
    ) -> Result<()> {
        instructions::buy_tokens::handler(ctx, sol_amount)
    }

    /// Sell tokens to the liquidity pool
    ///
    /// User swaps tokens for SOL using the constant product formula.
    /// Price decreases as more tokens are sold.
    pub fn sell_tokens(
        ctx: Context<SellTokens>,
        token_amount: u64,
    ) -> Result<()> {
        instructions::sell_tokens::handler(ctx, token_amount)
    }
}
