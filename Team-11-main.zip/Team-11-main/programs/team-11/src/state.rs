//! Program state account definitions

use anchor_lang::prelude::*;

/// Platform configuration account
/// Stores global settings for the platform
#[account]
#[derive(Default)]
pub struct PlatformConfig {
    /// Platform admin who can update configuration
    pub admin: Pubkey,
    /// Wallet that receives platform fees
    pub platform_wallet: Pubkey,
    /// Platform fee in basis points (e.g., 50 = 0.5%)
    pub platform_fee_bps: u16,
    /// Minimum lock period in days
    pub min_lock_period_days: u16,
    /// Total number of tokens created on the platform
    pub total_tokens: u64,
    /// Total SOL locked on the platform (in lamports)
    pub total_locked_sol: u64,
    /// Whether platform is in maintenance mode
    pub is_maintenance: bool,
    /// Bump seed for PDA
    pub bump: u8,
}

impl PlatformConfig {
    pub const LEN: usize = 8 + // discriminator
        32 + // admin
        32 + // platform_wallet
        2 +  // platform_fee_bps
        2 +  // min_lock_period_days
        8 +  // total_tokens
        8 +  // total_locked_sol
        1 +  // is_maintenance
        1;   // bump
}

/// Token metadata account
/// Stores information about created tokens
#[account]
#[derive(Default)]
pub struct TokenMetadata {
    /// Token mint address
    pub mint: Pubkey,
    /// Creator wallet address
    pub creator: Pubkey,
    /// Token name
    pub name: String,
    /// Token symbol
    pub symbol: String,
    /// Token decimals
    pub decimals: u8,
    /// Initial supply minted
    pub initial_supply: u64,
    /// Creator fee in basis points
    pub creator_fee_bps: u16,
    /// Creation timestamp
    pub created_at: i64,
    /// Whether token is active
    pub is_active: bool,
    /// Bump seed for PDA
    pub bump: u8,
}

impl TokenMetadata {
    pub const LEN: usize = 8 + // discriminator
        32 + // mint
        32 + // creator
        4 + 50 + // name (max 50 chars)
        4 + 10 + // symbol (max 10 chars)
        1 +  // decimals
        8 +  // initial_supply
        2 +  // creator_fee_bps
        8 +  // created_at
        1 +  // is_active
        1;   // bump
}

/// Liquidity lock account
/// Stores information about locked liquidity
#[account]
#[derive(Default)]
pub struct LiquidityLock {
    /// Associated token mint
    pub token_mint: Pubkey,
    /// Owner who locked the liquidity
    pub owner: Pubkey,
    /// Amount of SOL locked (in lamports)
    pub amount: u64,
    /// Lock start timestamp
    pub lock_date: i64,
    /// Unlock timestamp
    pub unlock_date: i64,
    /// Whether liquidity has been claimed
    pub is_claimed: bool,
    /// Bump seed for PDA
    pub bump: u8,
}

impl LiquidityLock {
    pub const LEN: usize = 8 + // discriminator
        32 + // token_mint
        32 + // owner
        8 +  // amount
        8 +  // lock_date
        8 +  // unlock_date
        1 +  // is_claimed
        1;   // bump
}

/// Liquidity pool account for trading
/// Holds tokens paired with SOL for buying/selling
#[account]
#[derive(Default)]
pub struct LiquidityPool {
    /// Associated token mint
    pub token_mint: Pubkey,
    /// Creator of the pool
    pub creator: Pubkey,
    /// Token account holding pool tokens
    pub token_vault: Pubkey,
    /// SOL reserve in the pool (lamports)
    pub sol_reserve: u64,
    /// Token reserve in the pool
    pub token_reserve: u64,
    /// Total tokens ever bought (for tracking)
    pub total_bought: u64,
    /// Total tokens ever sold (for tracking)
    pub total_sold: u64,
    /// Whether trading is active
    pub is_active: bool,
    /// Bump seed for PDA
    pub bump: u8,
}

impl LiquidityPool {
    pub const LEN: usize = 8 + // discriminator
        32 + // token_mint
        32 + // creator
        32 + // token_vault
        8 +  // sol_reserve
        8 +  // token_reserve
        8 +  // total_bought
        8 +  // total_sold
        1 +  // is_active
        1;   // bump
}
