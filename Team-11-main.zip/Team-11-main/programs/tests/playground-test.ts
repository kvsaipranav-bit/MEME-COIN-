// Solana Playground compatible test file
// Copy this content to the test file in Solana Playground

// In Solana Playground, 'pg' is a global object with program and wallet

describe("Team 11 - Meme Coin Platform Tests", () => {
    // Constants matching your Rust program
    const PLATFORM_CONFIG_SEED = "platform_config";
    const TOKEN_METADATA_SEED = "token_metadata";
    const LIQUIDITY_LOCK_SEED = "liquidity_lock";

    // Derive the platform config PDA
    const [platformConfigPda] = web3.PublicKey.findProgramAddressSync(
        [Buffer.from(PLATFORM_CONFIG_SEED)],
        pg.program.programId
    );

    // Test token mint (generate a new one for tests)
    const tokenMintKeypair = new web3.Keypair();

    // Derive token metadata PDA
    const [tokenMetadataPda] = web3.PublicKey.findProgramAddressSync(
        [Buffer.from(TOKEN_METADATA_SEED), tokenMintKeypair.publicKey.toBuffer()],
        pg.program.programId
    );

    // Derive liquidity lock PDA
    const [liquidityLockPda] = web3.PublicKey.findProgramAddressSync(
        [
            Buffer.from(LIQUIDITY_LOCK_SEED),
            tokenMintKeypair.publicKey.toBuffer(),
            pg.wallet.publicKey.toBuffer()
        ],
        pg.program.programId
    );

    // Platform wallet for receiving fees
    const platformWalletKeypair = new web3.Keypair();

    it("1. Initialize Platform", async () => {
        const platformFeeBps = 50;  // 0.5%
        const minLockDays = 90;     // 90 days minimum lock

        try {
            const tx = await pg.program.methods
                .initialize(
                    pg.wallet.publicKey,  // Use wallet as platform wallet
                    platformFeeBps,
                    minLockDays
                )
                .accounts({
                    admin: pg.wallet.publicKey,
                    platformConfig: platformConfigPda,
                    systemProgram: web3.SystemProgram.programId,
                })
                .rpc();

            console.log("✅ Initialize transaction:", tx);

            // Fetch and verify the created config
            const config = await pg.program.account.platformConfig.fetch(platformConfigPda);
            console.log("Platform Admin:", config.admin.toString());
            console.log("Platform Fee:", config.platformFeeBps, "bps");
            console.log("Min Lock Period:", config.minLockPeriodDays, "days");
            console.log("Total Tokens:", config.totalTokens.toString());
            console.log("Is Maintenance:", config.isMaintenance);

        } catch (error) {
            // If already initialized, fetch existing config
            console.log("Platform may already be initialized, fetching config...");
            const config = await pg.program.account.platformConfig.fetch(platformConfigPda);
            console.log("Existing Platform Config:", config);
        }
    });

    it("2. Create Token", async () => {
        const name = "Test Meme Coin";
        const symbol = "TMC";
        const decimals = 9;
        const initialSupply = new BN(1000000);  // 1 million tokens
        const creatorFeeBps = 100;  // 1%

        // Get the associated token account address
        const creatorTokenAccount = await anchor.utils.token.associatedAddress({
            mint: tokenMintKeypair.publicKey,
            owner: pg.wallet.publicKey
        });

        try {
            const tx = await pg.program.methods
                .createToken(name, symbol, decimals, initialSupply, creatorFeeBps)
                .accounts({
                    creator: pg.wallet.publicKey,
                    platformConfig: platformConfigPda,
                    tokenMint: tokenMintKeypair.publicKey,
                    creatorTokenAccount: creatorTokenAccount,
                    tokenMetadata: tokenMetadataPda,
                    tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
                    associatedTokenProgram: anchor.utils.token.ASSOCIATED_PROGRAM_ID,
                    systemProgram: web3.SystemProgram.programId,
                    rent: web3.SYSVAR_RENT_PUBKEY,
                })
                .signers([tokenMintKeypair])
                .rpc();

            console.log("✅ Create Token transaction:", tx);

            // Fetch and verify token metadata
            const metadata = await pg.program.account.tokenMetadata.fetch(tokenMetadataPda);
            console.log("Token Name:", metadata.name);
            console.log("Token Symbol:", metadata.symbol);
            console.log("Token Decimals:", metadata.decimals);
            console.log("Initial Supply:", metadata.initialSupply.toString());
            console.log("Creator Fee:", metadata.creatorFeeBps, "bps");
            console.log("Is Active:", metadata.isActive);

            // Check updated platform stats
            const config = await pg.program.account.platformConfig.fetch(platformConfigPda);
            console.log("Total Tokens on Platform:", config.totalTokens.toString());

        } catch (error) {
            console.error("❌ Create Token failed:", error);
            throw error;
        }
    });

    it("3. Lock Liquidity", async () => {
        const lockAmount = new BN(0.1 * web3.LAMPORTS_PER_SOL);  // 0.1 SOL
        const lockDurationDays = 90;  // 90 days

        try {
            const tx = await pg.program.methods
                .lockLiquidity(lockAmount, lockDurationDays)
                .accounts({
                    owner: pg.wallet.publicKey,
                    platformConfig: platformConfigPda,
                    tokenMint: tokenMintKeypair.publicKey,
                    tokenMetadata: tokenMetadataPda,
                    liquidityLock: liquidityLockPda,
                    platformWallet: pg.wallet.publicKey,  // Platform wallet receives fees
                    systemProgram: web3.SystemProgram.programId,
                })
                .rpc();

            console.log("✅ Lock Liquidity transaction:", tx);

            // Fetch and verify liquidity lock
            const lock = await pg.program.account.liquidityLock.fetch(liquidityLockPda);
            console.log("Lock Owner:", lock.owner.toString());
            console.log("Locked Amount:", lock.amount.toString(), "lamports");
            console.log("Lock Date:", new Date(lock.lockDate.toNumber() * 1000).toISOString());
            console.log("Unlock Date:", new Date(lock.unlockDate.toNumber() * 1000).toISOString());
            console.log("Is Claimed:", lock.isClaimed);

            // Check updated platform stats
            const config = await pg.program.account.platformConfig.fetch(platformConfigPda);
            console.log("Total SOL Locked:", config.totalLockedSol.toString(), "lamports");

        } catch (error) {
            console.error("❌ Lock Liquidity failed:", error);
            throw error;
        }
    });

    it("4. Update Token Fees", async () => {
        const newCreatorFeeBps = 200;  // 2%

        try {
            const tx = await pg.program.methods
                .updateFees(newCreatorFeeBps)
                .accounts({
                    creator: pg.wallet.publicKey,
                    tokenMint: tokenMintKeypair.publicKey,
                    tokenMetadata: tokenMetadataPda,
                })
                .rpc();

            console.log("✅ Update Fees transaction:", tx);

            // Verify updated fee
            const metadata = await pg.program.account.tokenMetadata.fetch(tokenMetadataPda);
            console.log("New Creator Fee:", metadata.creatorFeeBps, "bps");

        } catch (error) {
            console.error("❌ Update Fees failed:", error);
            throw error;
        }
    });

    it("5. Update Platform Config", async () => {
        const newPlatformFeeBps = 75;  // 0.75%
        const newMinLockDays = 120;    // 120 days

        try {
            const tx = await pg.program.methods
                .updateConfig(
                    null,               // Keep same platform wallet
                    newPlatformFeeBps,  // New fee
                    newMinLockDays      // New min lock days
                )
                .accounts({
                    admin: pg.wallet.publicKey,
                    platformConfig: platformConfigPda,
                })
                .rpc();

            console.log("✅ Update Config transaction:", tx);

            // Verify updated config
            const config = await pg.program.account.platformConfig.fetch(platformConfigPda);
            console.log("New Platform Fee:", config.platformFeeBps, "bps");
            console.log("New Min Lock Days:", config.minLockPeriodDays, "days");

        } catch (error) {
            console.error("❌ Update Config failed:", error);
            throw error;
        }
    });

    it("6. Set Maintenance Mode", async () => {
        try {
            // Enable maintenance mode
            const tx = await pg.program.methods
                .setMaintenance(true)
                .accounts({
                    admin: pg.wallet.publicKey,
                    platformConfig: platformConfigPda,
                })
                .rpc();

            console.log("✅ Set Maintenance transaction:", tx);

            // Verify maintenance mode
            let config = await pg.program.account.platformConfig.fetch(platformConfigPda);
            console.log("Is Maintenance Mode:", config.isMaintenance);

            // Disable maintenance mode
            await pg.program.methods
                .setMaintenance(false)
                .accounts({
                    admin: pg.wallet.publicKey,
                    platformConfig: platformConfigPda,
                })
                .rpc();

            config = await pg.program.account.platformConfig.fetch(platformConfigPda);
            console.log("Maintenance disabled:", !config.isMaintenance);

        } catch (error) {
            console.error("❌ Set Maintenance failed:", error);
            throw error;
        }
    });

    it("7. Try to Unlock (should fail - still locked)", async () => {
        try {
            await pg.program.methods
                .unlockLiquidity()
                .accounts({
                    owner: pg.wallet.publicKey,
                    platformConfig: platformConfigPda,
                    tokenMint: tokenMintKeypair.publicKey,
                    liquidityLock: liquidityLockPda,
                    systemProgram: web3.SystemProgram.programId,
                })
                .rpc();

            console.log("❌ This should have failed - liquidity is still locked!");

        } catch (error) {
            console.log("✅ Expected error: Liquidity is still locked");
            console.log("Error message:", error.message);
        }
    });
});
