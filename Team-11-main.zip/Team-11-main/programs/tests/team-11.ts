import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
// Types will be generated after running 'anchor build'
// import { Team11 } from "../target/types/team_11";
import {
    Keypair,
    SystemProgram,
    LAMPORTS_PER_SOL,
    PublicKey
} from "@solana/web3.js";
import {
    TOKEN_PROGRAM_ID,
    ASSOCIATED_TOKEN_PROGRAM_ID,
    getAssociatedTokenAddress
} from "@solana/spl-token";
import { expect } from "chai";

// Define error type for catch blocks
interface AnchorError {
    message: string;
    code?: number;
}

// Define account types (matching Rust state structs)
interface PlatformConfigAccount {
    admin: PublicKey;
    platformWallet: PublicKey;
    platformFeeBps: number;
    minLockPeriodDays: number;
    totalTokens: anchor.BN;
    totalLockedSol: anchor.BN;
    isMaintenance: boolean;
    bump: number;
}

interface TokenMetadataAccount {
    mint: PublicKey;
    creator: PublicKey;
    name: string;
    symbol: string;
    decimals: number;
    initialSupply: anchor.BN;
    creatorFeeBps: number;
    createdAt: anchor.BN;
    isActive: boolean;
    bump: number;
}

interface LiquidityLockAccount {
    tokenMint: PublicKey;
    owner: PublicKey;
    amount: anchor.BN;
    lockDate: anchor.BN;
    unlockDate: anchor.BN;
    isClaimed: boolean;
    bump: number;
}

describe("team-11", () => {
    // Configure the client to use the local cluster
    const provider = anchor.AnchorProvider.env();
    anchor.setProvider(provider);

    // Use 'any' type until 'anchor build' generates the types
    const program = anchor.workspace.Team11 as Program<any>;

    // Test accounts
    let admin: Keypair;
    let creator: Keypair;
    let platformWallet: Keypair;
    let platformConfigPda: PublicKey;
    let platformConfigBump: number;

    // Token accounts
    let tokenMint: Keypair;
    let tokenMetadataPda: PublicKey;
    let creatorTokenAccount: PublicKey;

    // Lock accounts
    let liquidityLockPda: PublicKey;

    // Constants
    const PLATFORM_CONFIG_SEED = "platform_config";
    const TOKEN_METADATA_SEED = "token_metadata";
    const LIQUIDITY_LOCK_SEED = "liquidity_lock";

    before(async () => {
        // Generate keypairs
        admin = Keypair.generate();
        creator = Keypair.generate();
        platformWallet = Keypair.generate();
        tokenMint = Keypair.generate();

        // Airdrop SOL to accounts
        await provider.connection.requestAirdrop(admin.publicKey, 10 * LAMPORTS_PER_SOL);
        await provider.connection.requestAirdrop(creator.publicKey, 10 * LAMPORTS_PER_SOL);

        // Wait for confirmation
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Derive PDAs
        [platformConfigPda, platformConfigBump] = PublicKey.findProgramAddressSync(
            [Buffer.from(PLATFORM_CONFIG_SEED)],
            program.programId
        );

        [tokenMetadataPda] = PublicKey.findProgramAddressSync(
            [Buffer.from(TOKEN_METADATA_SEED), tokenMint.publicKey.toBuffer()],
            program.programId
        );

        [liquidityLockPda] = PublicKey.findProgramAddressSync(
            [
                Buffer.from(LIQUIDITY_LOCK_SEED),
                tokenMint.publicKey.toBuffer(),
                creator.publicKey.toBuffer()
            ],
            program.programId
        );

        creatorTokenAccount = await getAssociatedTokenAddress(
            tokenMint.publicKey,
            creator.publicKey
        );
    });

    describe("Initialize Platform", () => {
        it("should initialize the platform with valid parameters", async () => {
            const platformFeeBps = 50; // 0.5%
            const minLockDays = 90;

            await program.methods
                .initialize(platformWallet.publicKey, platformFeeBps, minLockDays)
                .accounts({
                    admin: admin.publicKey,
                    platformConfig: platformConfigPda,
                    systemProgram: SystemProgram.programId,
                })
                .signers([admin])
                .rpc();

            // Verify the config was created correctly
            const config = await program.account.platformConfig.fetch(platformConfigPda) as unknown as PlatformConfigAccount;
            expect(config.admin.toString()).to.equal(admin.publicKey.toString());
            expect(config.platformWallet.toString()).to.equal(platformWallet.publicKey.toString());
            expect(config.platformFeeBps).to.equal(platformFeeBps);
            expect(config.minLockPeriodDays).to.equal(minLockDays);
            expect(config.totalTokens.toNumber()).to.equal(0);
            expect(config.totalLockedSol.toNumber()).to.equal(0);
            expect(config.isMaintenance).to.equal(false);
        });

        it("should fail with invalid platform fee (> 10%)", async () => {
            const newAdmin = Keypair.generate();
            await provider.connection.requestAirdrop(newAdmin.publicKey, LAMPORTS_PER_SOL);
            await new Promise(resolve => setTimeout(resolve, 500));

            const [newConfigPda] = PublicKey.findProgramAddressSync(
                [Buffer.from(PLATFORM_CONFIG_SEED)],
                program.programId
            );

            try {
                await program.methods
                    .initialize(platformWallet.publicKey, 1001, 90) // 10.01% - invalid
                    .accounts({
                        admin: newAdmin.publicKey,
                        platformConfig: newConfigPda,
                        systemProgram: SystemProgram.programId,
                    })
                    .signers([newAdmin])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (err) {
                const error = err as AnchorError;
                expect(error.message).to.include("InvalidPlatformFee");
            }
        });
    });

    describe("Create Token", () => {
        it("should create a token with valid parameters", async () => {
            const name = "Test Meme Coin";
            const symbol = "TMC";
            const decimals = 9;
            const initialSupply = new anchor.BN(1000000);
            const creatorFeeBps = 100; // 1%

            await program.methods
                .createToken(name, symbol, decimals, initialSupply, creatorFeeBps)
                .accounts({
                    creator: creator.publicKey,
                    platformConfig: platformConfigPda,
                    tokenMint: tokenMint.publicKey,
                    creatorTokenAccount: creatorTokenAccount,
                    tokenMetadata: tokenMetadataPda,
                    tokenProgram: TOKEN_PROGRAM_ID,
                    associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
                    systemProgram: SystemProgram.programId,
                    rent: anchor.web3.SYSVAR_RENT_PUBKEY,
                })
                .signers([creator, tokenMint])
                .rpc();

            // Verify token metadata
            const metadata = await program.account.tokenMetadata.fetch(tokenMetadataPda) as unknown as TokenMetadataAccount;
            expect(metadata.name).to.equal(name);
            expect(metadata.symbol).to.equal(symbol);
            expect(metadata.decimals).to.equal(decimals);
            expect(metadata.initialSupply.toNumber()).to.equal(initialSupply.toNumber());
            expect(metadata.creatorFeeBps).to.equal(creatorFeeBps);
            expect(metadata.isActive).to.equal(true);

            // Verify platform counter was incremented
            const config = await program.account.platformConfig.fetch(platformConfigPda) as unknown as PlatformConfigAccount;
            expect(config.totalTokens.toNumber()).to.equal(1);
        });

        it("should fail with empty token name", async () => {
            const newMint = Keypair.generate();

            try {
                await program.methods
                    .createToken("", "TMC", 9, new anchor.BN(1000), 100)
                    .accounts({
                        creator: creator.publicKey,
                        platformConfig: platformConfigPda,
                        tokenMint: newMint.publicKey,
                        creatorTokenAccount: await getAssociatedTokenAddress(newMint.publicKey, creator.publicKey),
                        tokenMetadata: PublicKey.findProgramAddressSync(
                            [Buffer.from(TOKEN_METADATA_SEED), newMint.publicKey.toBuffer()],
                            program.programId
                        )[0],
                        tokenProgram: TOKEN_PROGRAM_ID,
                        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
                        systemProgram: SystemProgram.programId,
                        rent: anchor.web3.SYSVAR_RENT_PUBKEY,
                    })
                    .signers([creator, newMint])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (err) {
                const error = err as AnchorError;
                expect(error.message).to.include("TokenNameEmpty");
            }
        });

        it("should fail with creator fee too high", async () => {
            const newMint = Keypair.generate();

            try {
                await program.methods
                    .createToken("Test", "TST", 9, new anchor.BN(1000), 1001) // 10.01% - too high
                    .accounts({
                        creator: creator.publicKey,
                        platformConfig: platformConfigPda,
                        tokenMint: newMint.publicKey,
                        creatorTokenAccount: await getAssociatedTokenAddress(newMint.publicKey, creator.publicKey),
                        tokenMetadata: PublicKey.findProgramAddressSync(
                            [Buffer.from(TOKEN_METADATA_SEED), newMint.publicKey.toBuffer()],
                            program.programId
                        )[0],
                        tokenProgram: TOKEN_PROGRAM_ID,
                        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
                        systemProgram: SystemProgram.programId,
                        rent: anchor.web3.SYSVAR_RENT_PUBKEY,
                    })
                    .signers([creator, newMint])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (err) {
                const error = err as AnchorError;
                expect(error.message).to.include("InvalidCreatorFee");
            }
        });
    });

    describe("Lock Liquidity", () => {
        it("should lock liquidity for 90 days", async () => {
            const lockAmount = new anchor.BN(LAMPORTS_PER_SOL); // 1 SOL
            const lockDurationDays = 90;

            const platformWalletBalanceBefore = await provider.connection.getBalance(platformWallet.publicKey);

            await program.methods
                .lockLiquidity(lockAmount, lockDurationDays)
                .accounts({
                    owner: creator.publicKey,
                    platformConfig: platformConfigPda,
                    tokenMint: tokenMint.publicKey,
                    tokenMetadata: tokenMetadataPda,
                    liquidityLock: liquidityLockPda,
                    platformWallet: platformWallet.publicKey,
                    systemProgram: SystemProgram.programId,
                })
                .signers([creator])
                .rpc();

            // Verify lock was created
            const lock = await program.account.liquidityLock.fetch(liquidityLockPda) as unknown as LiquidityLockAccount;
            expect(lock.owner.toString()).to.equal(creator.publicKey.toString());
            expect(lock.tokenMint.toString()).to.equal(tokenMint.publicKey.toString());
            expect(lock.isClaimed).to.equal(false);

            // Verify platform fee was collected (0.5% of 1 SOL)
            const platformWalletBalanceAfter = await provider.connection.getBalance(platformWallet.publicKey);
            const expectedFee = lockAmount.toNumber() * 50 / 10000; // 0.5%
            expect(platformWalletBalanceAfter - platformWalletBalanceBefore).to.equal(expectedFee);
        });

        it("should fail with lock period too short", async () => {
            const newMint = Keypair.generate();

            try {
                await program.methods
                    .lockLiquidity(new anchor.BN(LAMPORTS_PER_SOL), 30) // Only 30 days - too short
                    .accounts({
                        owner: creator.publicKey,
                        platformConfig: platformConfigPda,
                        tokenMint: tokenMint.publicKey,
                        tokenMetadata: tokenMetadataPda,
                        liquidityLock: liquidityLockPda,
                        platformWallet: platformWallet.publicKey,
                        systemProgram: SystemProgram.programId,
                    })
                    .signers([creator])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (err) {
                const error = err as AnchorError;
                expect(error.message).to.include("LockPeriodTooShort");
            }
        });
    });

    describe("Claim Liquidity", () => {
        it("should fail to claim before unlock date", async () => {
            try {
                await program.methods
                    .unlockLiquidity()
                    .accounts({
                        owner: creator.publicKey,
                        platformConfig: platformConfigPda,
                        tokenMint: tokenMint.publicKey,
                        liquidityLock: liquidityLockPda,
                        systemProgram: SystemProgram.programId,
                    })
                    .signers([creator])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (err) {
                const error = err as AnchorError;
                expect(error.message).to.include("LiquidityStillLocked");
            }
        });

        it("should fail for non-owner to claim", async () => {
            const nonOwner = Keypair.generate();
            await provider.connection.requestAirdrop(nonOwner.publicKey, LAMPORTS_PER_SOL);
            await new Promise(resolve => setTimeout(resolve, 500));

            try {
                await program.methods
                    .unlockLiquidity()
                    .accounts({
                        owner: nonOwner.publicKey,
                        platformConfig: platformConfigPda,
                        tokenMint: tokenMint.publicKey,
                        liquidityLock: liquidityLockPda,
                        systemProgram: SystemProgram.programId,
                    })
                    .signers([nonOwner])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (error) {
                // Should fail due to PDA derivation mismatch or authorization
                expect(error).to.exist;
            }
        });
    });

    describe("Update Fees", () => {
        it("should allow creator to update their token fees", async () => {
            const newFeeBps = 200; // 2%

            await program.methods
                .updateFees(newFeeBps)
                .accounts({
                    creator: creator.publicKey,
                    tokenMint: tokenMint.publicKey,
                    tokenMetadata: tokenMetadataPda,
                })
                .signers([creator])
                .rpc();

            // Verify fee was updated
            const metadata = await program.account.tokenMetadata.fetch(tokenMetadataPda) as unknown as TokenMetadataAccount;
            expect(metadata.creatorFeeBps).to.equal(newFeeBps);
        });

        it("should fail for non-creator to update fees", async () => {
            const nonCreator = Keypair.generate();
            await provider.connection.requestAirdrop(nonCreator.publicKey, LAMPORTS_PER_SOL);
            await new Promise(resolve => setTimeout(resolve, 500));

            try {
                await program.methods
                    .updateFees(300)
                    .accounts({
                        creator: nonCreator.publicKey,
                        tokenMint: tokenMint.publicKey,
                        tokenMetadata: tokenMetadataPda,
                    })
                    .signers([nonCreator])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (err) {
                const error = err as AnchorError;
                expect(error.message).to.include("Unauthorized");
            }
        });
    });

    describe("Update Platform Config", () => {
        it("should allow admin to update platform config", async () => {
            const newFeeBps = 75; // 0.75%
            const newMinLockDays = 120;

            await program.methods
                .updateConfig(null, newFeeBps, newMinLockDays)
                .accounts({
                    admin: admin.publicKey,
                    platformConfig: platformConfigPda,
                })
                .signers([admin])
                .rpc();

            // Verify config was updated
            const config = await program.account.platformConfig.fetch(platformConfigPda) as unknown as PlatformConfigAccount;
            expect(config.platformFeeBps).to.equal(newFeeBps);
            expect(config.minLockPeriodDays).to.equal(newMinLockDays);
        });

        it("should fail for non-admin to update config", async () => {
            const nonAdmin = Keypair.generate();
            await provider.connection.requestAirdrop(nonAdmin.publicKey, LAMPORTS_PER_SOL);
            await new Promise(resolve => setTimeout(resolve, 500));

            try {
                await program.methods
                    .updateConfig(null, 100, null)
                    .accounts({
                        admin: nonAdmin.publicKey,
                        platformConfig: platformConfigPda,
                    })
                    .signers([nonAdmin])
                    .rpc();
                expect.fail("Should have thrown an error");
            } catch (err) {
                const error = err as AnchorError;
                expect(error.message).to.include("Unauthorized");
            }
        });
    });
});
