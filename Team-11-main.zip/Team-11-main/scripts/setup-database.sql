-- ================================================
-- TEAM 11 - DATABASE SCHEMA
-- Run this in your Supabase SQL Editor
-- ================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ================================================
-- USERS TABLE
-- ================================================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    wallet_address VARCHAR(44) UNIQUE NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ================================================
-- TOKENS TABLE
-- ================================================
CREATE TABLE IF NOT EXISTS tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    mint_address VARCHAR(44) UNIQUE NOT NULL,
    name VARCHAR(50) NOT NULL,
    symbol VARCHAR(10) NOT NULL,
    description TEXT,
    logo_url TEXT,
    decimals INTEGER DEFAULT 9,
    initial_supply BIGINT NOT NULL,
    creator_wallet VARCHAR(44) NOT NULL,
    creator_fee_percentage DECIMAL(5,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ================================================
-- LIQUIDITY LOCKS TABLE
-- ================================================
CREATE TABLE IF NOT EXISTS liquidity_locks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_id UUID NOT NULL REFERENCES tokens(id) ON DELETE CASCADE,
    lock_address VARCHAR(44) UNIQUE NOT NULL,
    amount_sol DECIMAL(20,9) NOT NULL,
    creator_wallet VARCHAR(44) NOT NULL,
    lock_date TIMESTAMP WITH TIME ZONE NOT NULL,
    unlock_date TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(20) DEFAULT 'locked' CHECK (status IN ('locked', 'unlocked', 'claimed')),
    claimed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ================================================
-- PLATFORM CONFIGURATION TABLE
-- ================================================
CREATE TABLE IF NOT EXISTS platform_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    platform_fee_percentage DECIMAL(5,2) DEFAULT 0.5,
    platform_wallet VARCHAR(44) NOT NULL,
    min_lock_period_days INTEGER DEFAULT 90,
    is_maintenance BOOLEAN DEFAULT FALSE,
    updated_by VARCHAR(44),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ================================================
-- INDEXES
-- ================================================
CREATE INDEX IF NOT EXISTS idx_tokens_creator ON tokens(creator_wallet);
CREATE INDEX IF NOT EXISTS idx_tokens_active ON tokens(is_active);
CREATE INDEX IF NOT EXISTS idx_tokens_symbol ON tokens(symbol);
CREATE INDEX IF NOT EXISTS idx_tokens_created ON tokens(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_locks_token ON liquidity_locks(token_id);
CREATE INDEX IF NOT EXISTS idx_locks_status ON liquidity_locks(status);
CREATE INDEX IF NOT EXISTS idx_locks_unlock ON liquidity_locks(unlock_date);
CREATE INDEX IF NOT EXISTS idx_locks_creator ON liquidity_locks(creator_wallet);

CREATE INDEX IF NOT EXISTS idx_users_wallet ON users(wallet_address);

-- ================================================
-- ROW LEVEL SECURITY (RLS)
-- ================================================

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE liquidity_locks ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_config ENABLE ROW LEVEL SECURITY;

-- Users: Public read, authenticated write
CREATE POLICY "Users are viewable by everyone" ON users
    FOR SELECT USING (true);

CREATE POLICY "Users can insert their own record" ON users
    FOR INSERT WITH CHECK (true);

-- Tokens: Public read, creator write
CREATE POLICY "Tokens are viewable by everyone" ON tokens
    FOR SELECT USING (is_active = true);

CREATE POLICY "Anyone can create tokens" ON tokens
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Creators can update their tokens" ON tokens
    FOR UPDATE USING (true);

-- Liquidity Locks: Public read, creator write
CREATE POLICY "Locks are viewable by everyone" ON liquidity_locks
    FOR SELECT USING (true);

CREATE POLICY "Anyone can create locks" ON liquidity_locks
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Creators can update their locks" ON liquidity_locks
    FOR UPDATE USING (true);

-- Platform Config: Admin only
CREATE POLICY "Config is viewable by everyone" ON platform_config
    FOR SELECT USING (true);

-- ================================================
-- FUNCTIONS
-- ================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to all tables
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tokens_updated_at
    BEFORE UPDATE ON tokens
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_locks_updated_at
    BEFORE UPDATE ON liquidity_locks
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ================================================
-- INITIAL DATA
-- ================================================

-- Insert default platform config
INSERT INTO platform_config (
    id,
    platform_fee_percentage,
    platform_wallet,
    min_lock_period_days,
    is_maintenance
) VALUES (
    '00000000-0000-0000-0000-000000000001',
    0.5,
    'YOUR_PLATFORM_WALLET_ADDRESS_HERE',
    90,
    false
) ON CONFLICT (id) DO NOTHING;

-- ================================================
-- STORAGE BUCKET (Run separately in Supabase Dashboard)
-- ================================================
-- 1. Go to Storage in Supabase Dashboard
-- 2. Create a new bucket called 'token-logos'
-- 3. Set it to public
-- 4. Add policy: Allow public read access
-- 5. Add policy: Allow authenticated users to upload
